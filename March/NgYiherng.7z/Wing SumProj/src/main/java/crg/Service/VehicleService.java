package crg.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;


import crg.model.Vehicle;
import crg.repo.VehicleRepo;

@Service
public class VehicleService {
	@Autowired
	private VehicleRepo vehRepo;
	
	public Page<Vehicle> listAll(int pageNum, String sortfield, String sortDir) {
		
		Sort sort = Sort.by("vehId");
		sort = sortDir.equals("ASC")? sort.ascending() : sort.descending();
		Pageable pageable = PageRequest.of(pageNum - 1, 5, sort);
		return vehRepo.findAll(pageable);
		
		
	}

}
