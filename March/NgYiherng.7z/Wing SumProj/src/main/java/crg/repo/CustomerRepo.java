package crg.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import crg.model.Customer;

public interface CustomerRepo extends JpaRepository<Customer, Long>{

}
