package at.htlstp.aslan.carrent;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CarRentApplicationTests {

    @Test
    void contextLoads() {
    }

}
