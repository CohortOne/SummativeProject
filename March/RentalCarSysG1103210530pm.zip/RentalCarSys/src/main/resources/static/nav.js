/**
 * 
 */

$(document).ready(function(){
  $(".dropdown-toggle").dropdown();
});