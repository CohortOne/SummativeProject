package crg.repo;

import java.util.Date;

import org.springframework.data.jdbc.repository.query.Query;
import org.springframework.data.jpa.repository.JpaRepository;

import crg.model.Booking;

public interface BookingRepo extends JpaRepository<Booking, Long>{
	
	
}
