package crg.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;


import crg.model.Booking;
import crg.model.Customer;
import crg.model.Employee;
import crg.model.Vehicle;
import crg.repo.BookingRepo;
import crg.repo.CustomerRepo;
import crg.repo.EmployeeRepo;
import crg.repo.VehStatusRepo;
import crg.repo.VehicleRepo;

@Controller
public class BookingController {
@Autowired
private BookingRepo bookRepo;
@Autowired
private CustomerRepo custRepo;
@Autowired
private EmployeeRepo empRepo;
@Autowired
private VehicleRepo vehRepo;
@Autowired
private VehStatusRepo vehSttsRepo;


@GetMapping("/booking")
public String ShowBookingList(Model model) {
	List<Booking> listBook = bookRepo.findAll();
	model.addAttribute("listBook",listBook);
	return "booking";
}

@GetMapping("/newBookingReg")
public String newBookingReg(Model model) {
	List<Customer> listCust =  custRepo.findAll();
	List<Vehicle> listVeh =  vehRepo.findAll();
	List<Employee> listEmp =  empRepo.findAll();
	model.addAttribute("booking", new Booking());
	model.addAttribute("listCust",listCust);
	model.addAttribute("listVeh",listVeh);
	model.addAttribute("listEmp",listEmp);
	return "newBookingReg";
	}

@PostMapping("/booking/save")
public String saveBooking(Booking booking, HttpServletRequest request) {
	bookRepo.save(booking);
	return "redirect:/booking";
}

@GetMapping("/booking/edit/{bookId}")
public String ShowBookingEditForm(@PathVariable("bookId") Long bookId, Model model) {
	List<Customer> listCust =  custRepo.findAll();
	List<Vehicle> listVeh =  vehRepo.findAll();
	List<Employee> listEmp =  empRepo.findAll();
	model.addAttribute("listCust",listCust);
	model.addAttribute("listVeh",listVeh);
	model.addAttribute("listEmp",listEmp);
	Booking booking = bookRepo.findById(bookId).get();
	model.addAttribute("booking", booking);
	List<Booking> listBook = bookRepo.findAll();
	model.addAttribute("listBook", listBook);
	return "newBookingReg";
	}

@GetMapping("/booking/return/{bookId}")
public String ShowBookingReturnForm(@PathVariable("bookId") Long bookId, Model model) {
	List<Customer> listCust =  custRepo.findAll();
	List<Vehicle> listVeh =  vehRepo.findAll();
	List<Employee> listEmp =  empRepo.findAll();
	model.addAttribute("listCust",listCust);
	model.addAttribute("listVeh",listVeh);
	model.addAttribute("listEmp",listEmp);
	Booking booking = bookRepo.findById(bookId).get();
	model.addAttribute("Booking", booking);
	List<Booking> listBook = bookRepo.findAll();
	model.addAttribute("listBook", listBook);
	return "returnBookingReg";
	}


@GetMapping("/booking/delete/{bookId}")
public String ShowBookingDeleteForm(@PathVariable("bookId") Long bookId, Model model) {
	bookRepo.deleteById(bookId);
	return "redirect:/booking";
	}
}


