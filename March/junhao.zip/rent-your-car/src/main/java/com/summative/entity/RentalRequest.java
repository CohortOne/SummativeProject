package com.summative.entity;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

@Getter
@Setter
@Entity
public class RentalRequest {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    private Integer accountId;
    private String accountEmail;
    private String accountFirstName;
    private String accountLastName;
    private Integer carId;

    public RentalRequest() {
    }

    public RentalRequest(Integer accountId, String accountEmail, String accountFirstName, String accountLastName, Integer carId) {
        this.accountId = accountId;
        this.accountEmail = accountEmail;
        this.accountFirstName = accountFirstName;
        this.accountLastName = accountLastName;
        this.carId = carId;
}
}