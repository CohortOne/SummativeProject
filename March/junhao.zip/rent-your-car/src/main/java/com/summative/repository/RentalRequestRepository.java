package com.summative.repository;


import org.springframework.data.repository.CrudRepository;

import com.summative.entity.RentalRequest;

public interface RentalRequestRepository extends CrudRepository<RentalRequest, Integer> {
    void deleteRentalRequestsByAccountId(Integer id);
    long count();
}
