package com.summative.repository;


import org.springframework.data.repository.CrudRepository;

import com.summative.entity.Account;

import java.util.List;

public interface AccountRepository extends CrudRepository<Account, Integer> {
    List<Account> findAll();
    Account findAccountById(Integer id);
    Account findAccountByEmail(String email);
}
