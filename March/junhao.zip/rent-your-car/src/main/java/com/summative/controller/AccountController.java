package com.summative.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.neo4j.Neo4jProperties.Authentication;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;

import com.summative.entity.Account;
import com.summative.service.AccountService;
import com.summative.service.CarService;

import java.util.List;
import java.util.Set;

@RestController
@RequestMapping("/account")
public class AccountController {
	private final CarService carService;
    private final AccountService accountService;

    @Autowired
    public AccountController(AccountService accountService,CarService carService) {
        this.accountService = accountService;
        this.carService = carService;
    }

    @GetMapping("/show/all")
    public List<Account> showAllAccounts() {
        return accountService.showAllAccounts();
    }

    @GetMapping("/show/{id}")
    public Account showAccountById(@PathVariable("id") Integer id) {
        return accountService.showAccountById(id);
    }

    @GetMapping("/show/email")
    public Account showAccountByEmail(@RequestParam("email") String email) {
        return accountService.showAccountByEmail(email);
    }

    @PostMapping("/register")
    public ResponseEntity<String> registerAccount(@RequestBody Account account) {
        accountService.save(account);
        return new ResponseEntity<>("New account added", HttpStatus.CREATED);
    }

    @PutMapping("/update")
    public ResponseEntity<String> updateAccount(@RequestBody Account account) {
        accountService.updateAccount(account);
        return new ResponseEntity<>("Account has been updated", HttpStatus.OK);
    }

    @DeleteMapping("/delete/requests/{id}")
    public ResponseEntity<String> deleteRequestsByAccountId(@PathVariable("id") Integer id) {
        accountService.deleteRequestsByAccountId(id);
        return new ResponseEntity<>("Requests from account with id=" + id + " has been deleted ", HttpStatus.OK);
        
        @GetMapping("/")
        public String accountDetails(Authentication authentication, ModelMap modelMap) {
            String email = authentication.getName();

            Account account = accountService.findAccountByEmail(email);
            if(account.getRentedCarId() != null) {
                Car rentedCar = carService.findCarById(account.getRentedCarId());
                modelMap.addAttribute("rentedCar", rentedCar);
            }
            modelMap.addAttribute("account", account);

            return "account-detail";
        }

        @GetMapping("/rent")
        public String requestRent(@RequestParam("carId") Integer id, Authentication authentication) {
            Car car = carService.findCarById(id);
            Account account = accountService.findAccountByEmail(authentication.getName());
            Set<RentalRequest> carRequestList = car.getUserRequests();

            if(requestFromThatAccountAlreadyExists(carRequestList, account.getId())) {
                return "redirect:/";
            }

            carRequestList.add(new RentalRequest(account.getId(), account.getEmail(), account.getFirstName(), account.getLastName(), car.getId()));

            accountService.updateAccount(account);
            carService.updateCar(car);

            return "redirect:/";
        }

        private boolean requestFromThatAccountAlreadyExists(Set<RentalRequest> requests, Integer accountId) {
            for(RentalRequest request : requests) {
                if(request.getAccountId().equals(accountId)) {
                    return true;
                }
            }
            return false;
    }
}
