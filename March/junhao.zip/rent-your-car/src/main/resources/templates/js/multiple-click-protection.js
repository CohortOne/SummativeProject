$("#registration").submit(function(event) {
    $("#submi").prop("disabled", true).addClass("disabled");
});