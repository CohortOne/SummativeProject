package com.veh.configuration;

import java.nio.file.Path;
import java.nio.file.Paths;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class MvcConfig implements WebMvcConfigurer {

	@Override
	public void addResourceHandlers(ResourceHandlerRegistry registry) {
		
//		Resource location for car images
		Path imageUploadDir = Paths.get("/Volumes/Toshiba-4TB/sumPrj-photos/vehicle-photos");
		
		String imageUploadPath = imageUploadDir.toFile().getAbsolutePath();
		
		String carImages = "file://" + imageUploadPath + "/";
		
//		Resource location for customer-related images
		imageUploadDir = Paths.get("/Volumes/Toshiba-4TB/sumPrj-photos/customer-photos");
		
		imageUploadPath = imageUploadDir.toFile().getAbsolutePath();
		
		String customerProofImages = "file://" + imageUploadPath + "/";
		
		registry.addResourceHandler("/Volumes/Toshiba-4TB/sumPrj-photos/vehicle-photos/**",
				"/Volumes/Toshiba-4TB/sumPrj-photos/customer-photos/**")
			.addResourceLocations(carImages, customerProofImages);
						
	}
	
}
