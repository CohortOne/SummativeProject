package com.veh.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.veh.Customer;
import com.veh.UserRole;
import com.veh.Users;
import com.veh.dao.UserService;
import com.veh.repository.RoleRepository;

@Controller
public class UserController {
	
	@Autowired
	private UserService userService;
	
	@Autowired
	private RoleRepository roleRepo;
	
	@GetMapping("/list_users")
	public String listUsers(Model model) {
		
		model.addAttribute("listUsers", userService.findAll());
		
		System.out.println(model.toString());
		
		return "list_users";
	}
	

	@GetMapping("/new_user")
	public String newUserCreation(Model model) {
		List<UserRole> roles = roleRepo.findAll();
		model.addAttribute("roles", roles);
		
		Users theUser = new Users();
		model.addAttribute("user", theUser);
		return "new_user";
	}
	
	@PostMapping("/saveUser")
	public String saveUser(@Valid @ModelAttribute("user")Users theUser, BindingResult bindingResult) {
		
		if (bindingResult.hasErrors())
			return "new_user";
		
		userService.save(theUser);				
		return "redirect:/list_users";
	}
	
	@PostMapping("/updateUser")
	public String updateUser(@Valid @ModelAttribute("user")Users theUser, BindingResult bindingResult) {
		
		if (bindingResult.hasErrors())
			return "update_user";
		
		userService.save(theUser);				
		return "redirect:/list_users";
	}
	
	@GetMapping("/showFormToUpdateUser")
	public String showFormToUpdateUser(@RequestParam("userId") long id, Model model) {
		
		//Get list of roles
		List<UserRole> roles = roleRepo.findAll();
		model.addAttribute("roles", roles);
		
		// Get User from the Service 
		Users theUser = userService.findById(id);
		
		// set employee as a model attribute to pre-populate the form 
		model.addAttribute("user", theUser);
		
		System.out.println("In Update User - " + model);
		
		return "update_user";
	}
	
	@GetMapping("/deleteUser")
	public String deleteCustomer(@RequestParam("userId") long theId) {
	 // call delete employee method 
	 this.userService.deleteById(theId);
	 return "redirect:/list_users";
	}
}

//@GetMapping("/list_users")
//public String viewUserList(Model model) {
//	
////	model.addAttribute("listCustomers", customerDao.getAllCustomers());
//	return findPaginated(1, "id", "ASC", model);
//}
//
//@GetMapping("/page/{pageNo}")
//public String findPaginated(@PathVariable(value = "pageNo") int pageNo,
//								@RequestParam("sortField") String sortField,
//								@RequestParam("sortDirection") String sortDirection,
//								Model model) {
//	
//	int pageSize = 5; //5 records per page
//	Page <Customer> page = customerDao.findPaginated(pageNo, pageSize, sortField, sortDirection);
//	List <Customer> listCustomers = page.getContent();
//	model.addAttribute("listCustomers", listCustomers);
//	model.addAttribute("totalPages", page.getTotalPages());
//	model.addAttribute("totalItems", page.getTotalElements());
//	model.addAttribute("currentPage", pageNo);
//	model.addAttribute("sortField", sortField);
//	model.addAttribute("sortDirection", sortDirection);
//	model.addAttribute("reverseSortDirection", sortDirection.equalsIgnoreCase("ASC") ? "DESC" : "ASC");
//	
//	return "list_users";
//}
//
//
