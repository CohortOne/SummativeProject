package com.veh.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.veh.Users;

//public interface UserRepository extends CrudRepository<Users, Long> 

public interface UserRepository extends JpaRepository<Users, Long>{

}
