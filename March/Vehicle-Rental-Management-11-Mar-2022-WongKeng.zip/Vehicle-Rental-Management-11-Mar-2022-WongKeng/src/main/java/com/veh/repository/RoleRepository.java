package com.veh.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.veh.UserRole;

//public interface UserRepository extends CrudRepository<Users, Long> 

public interface RoleRepository extends JpaRepository<UserRole, Integer>{

}
