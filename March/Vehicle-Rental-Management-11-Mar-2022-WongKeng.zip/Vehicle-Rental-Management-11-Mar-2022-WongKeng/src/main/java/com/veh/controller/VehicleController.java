package com.veh.controller;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.StringUtils;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.veh.UserRole;
import com.veh.Users;
import com.veh.Vehicle;
import com.veh.dao.VehicleService;
import com.veh.utility.ImageFileUploadUtility;

@Controller
public class VehicleController {
	
	@Autowired
	private VehicleService vehicleService;
	
	@GetMapping("/list_vehicles")
	public String listVehicles(Model model) {
		
		model.addAttribute("listVehicles", vehicleService.findAll());
		
//		System.out.println(model.toString());
		
		return "list_vehicles";
	}
	
	@GetMapping("/new_vehicle")
	public String newVehicleCreation(Model model) {
		
		Vehicle theVehicle = new Vehicle();
		model.addAttribute("vehicle", theVehicle);
		return "new_vehicle";
	}
		
	@PostMapping("/saveVehicle")
	public String saveVehicle(@Valid @ModelAttribute("vehicle")Vehicle theVehicle, 
			BindingResult bindingResult,
			RedirectAttributes ra,
			@RequestParam("fileImage") MultipartFile multipartFile) throws IOException {
		
		if (bindingResult.hasErrors())
			return "new_vehicle";
		
//		Saving the Vehicle Object to get the vehId
		Vehicle savedVeh = vehicleService.saveTemp4ID(theVehicle);
		
//		If multipartFile is empty just save the vehicle object to DB
		
		if (!multipartFile.isEmpty()) {
//			Upload car image
			ImageFileUploadUtility imageFileUploadUtility = new ImageFileUploadUtility();
			
			savedVeh = imageFileUploadUtility.upLoadImageFile(savedVeh, multipartFile);
		}	
		
//		System.out.println("savedVeh : " + savedVeh);
		
		vehicleService.save(savedVeh);
		
        ra.addFlashAttribute("message", "Record sucessfully Saved/Updated.");
        
//		vehicleService.save(theVehicle);				
		return "redirect:/list_vehicles";
	}
		
	@GetMapping("/showFormToUpdateVehicle")
	public String showFormToUpdateVehicle(@RequestParam("vehId") long id, Model model) {
		
		// Get Vehicle from the Service 
		Vehicle theVehicle = vehicleService.findById(id);
		
		// set vehicle as a model attribute to pre-populate the form 
		model.addAttribute("vehicle", theVehicle);
		
//		System.out.println("In Update Vehicle - " + model);
		
		return "update_vehicle";
		
	}
		
	@GetMapping("/deleteVehicle")
	public String deleteVehicle(@RequestParam("vehId") long theId) {
	 
		// call delete vehicle method 
	 this.vehicleService.deleteById(theId);
	 return "redirect:/list_vehicles";
	}
	
}
