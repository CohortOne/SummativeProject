package com.veh.dao;

import java.util.List;

import com.veh.Users;
import com.veh.Vehicle;

public interface VehicleService {

		public List<Vehicle> findAll();
		
		public Vehicle findById(long theId);
		
		public void save(Vehicle theVehicle);
		
		public Vehicle saveTemp4ID(Vehicle theVehicle);
		
		public void deleteById(long theId);
}
