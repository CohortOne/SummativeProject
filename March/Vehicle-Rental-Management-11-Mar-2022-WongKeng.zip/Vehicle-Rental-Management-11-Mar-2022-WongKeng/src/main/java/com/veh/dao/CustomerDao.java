package com.veh.dao;

import java.util.List;

import org.springframework.data.domain.Page;

import com.veh.Customer;
import com.veh.Vehicle;

public interface CustomerDao {
	
	public List<Customer> getAllCustomers();
	public void saveCustomer(Customer customer);
	public void updateCustomer(Customer customer);
	public Customer getCustomerById(long custId);
	public void deleteCustomerById(long custId);
	public Customer saveTemp4ID(Customer customer);
	public Page <Customer> findPaginated(int pageNo, int pageSize, String sortField, String sortDirection);

}
