package com.veh;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;


@Entity		//Annotate Entity
@Table(name="vehicle") //Annotate Table
public class Vehicle {
	
	public Vehicle(Long vehId, String vehRegNum, String model, String brand, int engCap, int seatCap, String fuelType,
			double hireRate, String vehStatus, String vehImage, List<Booking> bookings) {
		super();
		this.vehId = vehId;
		this.vehRegNum = vehRegNum;
		this.model = model;
		this.brand = brand;
		this.engCap = engCap;
		this.seatCap = seatCap;
		this.fuelType = fuelType;
		this.hireRate = hireRate;
		this.vehStatus = vehStatus;
		this.vehImage = vehImage;
		this.bookings = bookings;
	}

	//Constructors
	public Vehicle() {}		
	
	public Vehicle(Long vehId, String vehRegNum, String model, String brand, int engCap, int seatCap, String fuelType,
			double hireRate, String vehStatus, String vehImage) {
		
		this.vehId = vehId;
		this.vehRegNum = vehRegNum;
		this.model = model;
		this.brand = brand;
		this.engCap = engCap;
		this.seatCap = seatCap;
		this.fuelType = fuelType;
		this.hireRate = hireRate;
		this.vehStatus = vehStatus;
		this.vehImage = vehImage;
	}
	
	@Id
	@Column(name = "veh_id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long vehId;
	private String vehRegNum;
	private String model;
	private String brand;
	private int engCap;  //engine capacity
	private int seatCap; //seating capacity
	private String fuelType;
	private double hireRate;
	private String vehStatus;
	private String vehImage;
	
	@OneToMany(mappedBy="theVehicle",
			   cascade = {CascadeType.MERGE, CascadeType.PERSIST, CascadeType.REFRESH, CascadeType.DETACH})
	private List<Booking> bookings;

	//Getters/Setters
	
	public List<Booking> getBookings() {
		return bookings;
	}

	public void setBookings(List<Booking> bookings) {
		this.bookings = bookings;
	}
	
	public Long getVehId() {
		return vehId;
	}
	public void setVehId(Long vehId) {
		this.vehId = vehId;
	}
	
	public String getVehRegNum() {
		return vehRegNum;
	}
	public void setVehRegNum(String vehRegNum) {
		this.vehRegNum = vehRegNum;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public String getBrand() {
		return brand;
	}
	public void setBrand(String brand) {
		this.brand = brand;
	}
	public int getEngCap() {
		return engCap;
	}
	public void setEngCap(int engCap) {
		this.engCap = engCap;
	}
	public int getSeatCap() {
		return seatCap;
	}
	public void setSeatCap(int seatCap) {
		this.seatCap = seatCap;
	}
	public String getFuelType() {
		return fuelType;
	}
	public void setFuelType(String fuelType) {
		this.fuelType = fuelType;
	}
	public double getHireRate() {
		return hireRate;
	}
	public void setHireRate(double hireRate) {
		this.hireRate = hireRate;
	}
	public String getVehStatus() {
		return vehStatus;
	}
	public void setVehStatus(String vehStatus) {
		this.vehStatus = vehStatus;
	}
	public String getVehImage() {
		return vehImage;
	}
	public void setVehImage(String vehImage) {
		this.vehImage = vehImage;
	}
	
	@Transient
	public String vehicleImagePath() {
		if (vehImage == null || vehId == null) return null;
		
		return "/Volumes/Toshiba-4TB/sumPrj-photos/vehicle-photos/" + vehId + "/" + vehImage;
		
	}

	@Override
	public String toString() {
		return "Vehicle [vehId=" + vehId + ", vehRegNum=" + vehRegNum + ", model=" + model + ", brand=" + brand
				+ ", engCap=" + engCap + ", seatCap=" + seatCap + ", fuelType=" + fuelType + ", hireRate=" + hireRate
				+ ", vehStatus=" + vehStatus + ", vehImage=" + vehImage + ", bookings=" + bookings + "]";
	}

}
