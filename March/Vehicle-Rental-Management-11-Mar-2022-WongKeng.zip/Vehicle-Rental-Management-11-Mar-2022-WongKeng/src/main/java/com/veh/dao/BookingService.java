package com.veh.dao;

import java.util.List;

import com.veh.Booking;

public interface BookingService {

		public List<Booking> findAll();
		
		public Booking findById(long theId);
		
		public void save(Booking theBooking);
		
		public void deleteById(long theId);
}
