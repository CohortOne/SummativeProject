package com.veh.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.veh.Users;
import com.veh.Vehicle;
import com.veh.repository.VehicleRepository;

@Service
public class VehicleServiceImpl implements VehicleService {

	private VehicleRepository vehicleRepository;
	
	@Autowired
	public VehicleServiceImpl(VehicleRepository vehicleRepository) {
		this.vehicleRepository = vehicleRepository;
	}

	@Override
	public List<Vehicle> findAll() {
		return vehicleRepository.findAll();
	}

	@Override
	public Vehicle findById(long theId) {
		Optional <Vehicle> optional = vehicleRepository.findById(theId);
		Vehicle theVehicle = null;
		
		if(optional.isPresent())
			theVehicle = optional.get();
		else
			throw new RuntimeException(" Customer not found for id :: " + theId);
		
		return theVehicle;
	}

	@Override
	public void save(Vehicle theVehicle) {
		vehicleRepository.save(theVehicle);
	}

	@Override
	public void deleteById(long theId) {
		vehicleRepository.deleteById(theId);

	}

	@Override
	public Vehicle saveTemp4ID(Vehicle theVehicle) {
		
		return vehicleRepository.save(theVehicle);
	}

}
