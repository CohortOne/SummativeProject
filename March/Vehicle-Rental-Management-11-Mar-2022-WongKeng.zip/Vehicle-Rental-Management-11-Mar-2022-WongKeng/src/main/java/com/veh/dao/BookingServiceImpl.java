package com.veh.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.veh.Booking;
import com.veh.Customer;
import com.veh.Users;
import com.veh.repository.BookingRepository;
import com.veh.repository.UserRepository;

@Service
public class BookingServiceImpl implements BookingService {

	@Autowired
	private BookingRepository bookingRepository;

	@Override
	public List<Booking> findAll() {
		return bookingRepository.findAll();
	}

	@Override
	public Booking findById(long theId) {
		Optional <Booking> optional = bookingRepository.findById(theId);
		Booking theBooking = null;
		
		if (optional.isPresent())
			theBooking = optional.get();
		else
			throw new RuntimeException(" Booking not found for id :: " + theId);
		
		return theBooking;
	}

	@Override
	public void save(Booking theBooking) {
		bookingRepository.save(theBooking);
	}

	@Override
	public void deleteById(long theId) {
		bookingRepository.deleteById(theId);
		
	}
	
}
