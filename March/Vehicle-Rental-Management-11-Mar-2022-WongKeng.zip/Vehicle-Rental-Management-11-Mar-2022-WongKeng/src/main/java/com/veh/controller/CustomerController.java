package com.veh.controller;

import java.io.IOException;
import java.security.Principal;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.veh.Customer;
import com.veh.dao.CustomerDao;
import com.veh.utility.IdentityFileUploadUtility;

@Controller
public class CustomerController {
	
	@Autowired
	private CustomerDao customerDao;	
	
	@GetMapping("/login")
	public String login() {
			return "login";
	}
	
	@RequestMapping("/logout-success")
	public String logout() {
			return "logout";

	}
	
	@RequestMapping("/testaop")
	public String TestAop(Principal principal) {
		return "Welcomeaop";
	}
	
	@GetMapping("/list_customer")
	public String viewHomePage(Model model) {
		
//		model.addAttribute("listCustomers", customerDao.getAllCustomers());
		return findPaginated(1, "custId", "ASC", model);
	}
	
	@GetMapping("/page/{pageNo}")
	public String findPaginated(@PathVariable(value = "pageNo") int pageNo,
									@RequestParam("sortField") String sortField,
									@RequestParam("sortDirection") String sortDirection,
									Model model) {
		
		int pageSize = 5; //5 records per page
		Page <Customer> page = customerDao.findPaginated(pageNo, pageSize, sortField, sortDirection);
		List <Customer> listCustomers = page.getContent();
		model.addAttribute("listCustomers", listCustomers);
		model.addAttribute("totalPages", page.getTotalPages());
		model.addAttribute("totalItems", page.getTotalElements());
		model.addAttribute("currentPage", pageNo);
		model.addAttribute("sortField", sortField);
		model.addAttribute("sortDirection", sortDirection);
		model.addAttribute("reverseSortDirection", sortDirection.equalsIgnoreCase("ASC") ? "DESC" : "ASC");
		
		return "list_customer";
	}
	
	@GetMapping("/new_customer")
	public String newUserCreation(Model model) {
		
		Customer theCustomer = new Customer();
		model.addAttribute("user", theCustomer);
		return "new_customer";
	}

	@GetMapping("/showNewCustomerForm")
	public String showNewCustomerForm(Model model) {
		
		Customer customer = new Customer();
		model.addAttribute("customer", customer);
		return "new_customer";
	}
	
	@PostMapping("/saveCustomer")
	public String saveCustomer(@Valid @ModelAttribute("customer")Customer customer, 
			BindingResult bindingResult,
			RedirectAttributes ra,
			@RequestParam("fileImage") MultipartFile multipartFile) throws IOException {
		
		if (bindingResult.hasErrors())
			return "new_customer";

//		Save the new Customer object to get custId
		Customer savedCust = customerDao.saveTemp4ID(customer);
		
//		If multipartFile is empty just save the customer object to DB
		
		if (!multipartFile.isEmpty()) {
//			Upload Customer identity proof
			IdentityFileUploadUtility identityFileUploadUtility = new IdentityFileUploadUtility();
			
			savedCust = identityFileUploadUtility.upLoadImageFile(savedCust, multipartFile);
		}

		customerDao.saveCustomer(savedCust);
		
		ra.addFlashAttribute("message", "Record sucessfully Saved/Updated.");
		
		return "redirect:/list_customer";
	}
	

	@GetMapping("/showFormForUpdate")
	public String showFormForUpdate(@RequestParam("custId") long custId, Model model) {
		// Get Employee from the Service 
		Customer customer = customerDao.getCustomerById(custId);
		
		// set employee as a model attribute to pre-populate the form 
		model.addAttribute("customer", customer);
		
		return "update_customer";
	}
	
	@GetMapping("/deleteCustomer")
	public String deleteCustomer(@RequestParam("custId") long custId) {
	 // call delete employee method 
	 this.customerDao.deleteCustomerById(custId);
	 return "redirect:/list_customer";
	}

}
