package com.veh;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "BOOKING")
public class Booking {
	
	public Booking(long bookId, LocalDate startDate, LocalDate returnDate, Customer theCustomer, Users theUser,
			Vehicle theVehicle, double rate, int duration, double discount, double total) {
		this.bookId = bookId;
		this.startDate = startDate;
		this.returnDate = returnDate;
		this.theCustomer = theCustomer;
		this.theUser = theUser;
		this.theVehicle = theVehicle;
		this.rate = rate;
		this.duration = duration;
		this.discount = discount;
		this.total = total;
	}

	public Booking() {}
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "book_id")
	private Long bookId;
	
	@Column
	private LocalDate startDate;
	
	@Column
	private LocalDate returnDate;
	
	@ManyToOne
	@JoinColumn(name = "customerId")
	private Customer theCustomer;
	
	@ManyToOne
	@JoinColumn(name = "employeeId")
	private Users theUser;
	
	@ManyToOne
	@JoinColumn(name = "vehicleId")
	private Vehicle theVehicle;
	
	@Column
	private double rate;
	
	@Column
	private int duration;
	
	@Column
	private double discount;
	
	@Column
	private double total;

	public long getBookId() {
		return bookId;
	}

	public void setBookId(long bookId) {
		this.bookId = bookId;
	}

	public LocalDate getStartDate() {
		return startDate;
	}

	public void setStartDate(LocalDate startDate) {
		this.startDate = startDate;
	}

	public LocalDate getReturnDate() {
		return returnDate;
	}

	public void setReturnDate(LocalDate returnDate) {
		this.returnDate = returnDate;
	}

	public Customer getTheCustomer() {
		return theCustomer;
	}

	public void setTheCustomer(Customer theCustomer) {
		this.theCustomer = theCustomer;
	}

	public Users getTheUser() {
		return theUser;
	}

	public void setTheUser(Users theUser) {
		this.theUser = theUser;
	}

	public Vehicle getTheVehicle() {
		return theVehicle;
	}

	public void setTheVehicle(Vehicle theVehicle) {
		this.theVehicle = theVehicle;
	}

	public double getRate() {
		return rate;
	}

	public void setRate(double rate) {
		this.rate = rate;
	}

	public int getDuration() {
		return duration;
	}

	public void setDuration(int duration) {
		this.duration = duration;
	}

	public double getDiscount() {
		return discount;
	}

	public void setDiscount(double discount) {
		this.discount = discount;
	}

	public double getTotal() {
		return total;
	}

	public void setTotal(double total) {
		this.total = total;
	}

	@Override
	public String toString() {
		return "Booking [bookId=" + bookId + ", startDate=" + startDate + ", returnDate=" + returnDate
				+ ", theCustomer=" + theCustomer + ", theUser=" + theUser + ", theVehicle=" + theVehicle + ", rate="
				+ rate + ", duration=" + duration + ", discount=" + discount + ", total=" + total + "]";
	}

		
}


















