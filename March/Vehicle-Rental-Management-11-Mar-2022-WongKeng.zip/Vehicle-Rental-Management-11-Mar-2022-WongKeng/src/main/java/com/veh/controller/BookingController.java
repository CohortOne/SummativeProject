package com.veh.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.veh.Booking;
import com.veh.Customer;
import com.veh.Users;
import com.veh.Vehicle;
import com.veh.dao.BookingService;
import com.veh.dao.CustomerDao;
import com.veh.dao.UserService;
import com.veh.dao.VehicleService;

@Controller
public class BookingController {
	
	@Autowired
	private BookingService bookingService;
	
	@Autowired
	private CustomerDao customerDao;
	
	@Autowired
	private VehicleService vehicleService;
	
	@Autowired
	private UserService userService;
		
	@GetMapping("/book_a_car")
	public String newCarBooking(Model model) {
		
		Booking theBooking = new Booking();
		model.addAttribute("newBooking", theBooking);
		
		Customer theCustomer = new Customer();
		model.addAttribute("customer", customerDao.getCustomerById(1));
		
		Vehicle theVehicle = new Vehicle();
		model.addAttribute("vehicle", theVehicle);
		
		Users theUser = new Users();
		model.addAttribute("user", theUser);
		
		return "new_booking_form";
	}
//
//	@GetMapping("/showNewBookingForm")
//	public String showNewBookingForm(Model model) {
//		
//		Customer customer = new Customer();
//		model.addAttribute("customer", customer);
//		return "new_customer";
//	}
//		

	
	@GetMapping("/showBooking")
	public void showBooking() {
		System.out.println("showBooking()");
	}
	
	@GetMapping("/showFormForBooking")
	public String showFormForBooking() {
//		// Get Employee from the Service 
//		Customer customer = customerDao.getCustomerById(custId);
//		
//		// set employee as a model attribute to pre-populate the form 
//		model.addAttribute("customer", customer);
		
		System.out.println("Here in showFormForBooking()");
//		
		return "new_booking";
	}
	
	@GetMapping("/showFormForBookingUpdate")
	public String showFormForBookingUpdate(@RequestParam("custId") long custId, Model model) {
//		// Get Employee from the Service 
//		Customer customer = customerDao.getCustomerById(custId);
//		
//		// set employee as a model attribute to pre-populate the form 
//		model.addAttribute("customer", customer);
//		
		return null;
	}
	
	@GetMapping("/deleteBooking")
	public String deleteBooking(@RequestParam("bookId") long bookId) {
	 // call delete Booking method 
	 this.bookingService.deleteById(bookId);
	 return "redirect:/list_booking";
	}

}
