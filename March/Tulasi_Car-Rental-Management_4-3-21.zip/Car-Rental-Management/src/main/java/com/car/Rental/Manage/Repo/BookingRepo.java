package com.car.Rental.Manage.Repo;

import org.springframework.data.jdbc.repository.query.Query;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.car.Rental.Manage.Model.Booking;
@Repository
public interface BookingRepo extends JpaRepository<Booking, Long> {

	

}
