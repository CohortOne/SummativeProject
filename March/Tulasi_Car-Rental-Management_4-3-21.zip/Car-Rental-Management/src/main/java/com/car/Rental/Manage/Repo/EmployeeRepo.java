package com.car.Rental.Manage.Repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.car.Rental.Manage.Model.Employee;

public interface EmployeeRepo extends JpaRepository<Employee, Long> {
	Employee findByEmpName(String empName);

	public Employee findByEmail(String email);

	public Employee findByResetPasswordToken(String token);
}
