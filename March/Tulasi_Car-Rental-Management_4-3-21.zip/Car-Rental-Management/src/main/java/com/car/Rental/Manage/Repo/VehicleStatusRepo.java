package com.car.Rental.Manage.Repo;

import java.util.List;

import org.springframework.data.jdbc.repository.query.Query;
import org.springframework.data.jpa.repository.JpaRepository;

import com.car.Rental.Manage.Model.VehStatus;

public interface VehicleStatusRepo extends JpaRepository<VehStatus, Integer> {
	
	


}
