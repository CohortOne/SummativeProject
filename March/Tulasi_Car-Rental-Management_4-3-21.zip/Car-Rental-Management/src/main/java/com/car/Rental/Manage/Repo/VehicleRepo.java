package com.car.Rental.Manage.Repo;




import org.springframework.data.jpa.repository.JpaRepository;


import com.car.Rental.Manage.Model.Vehicle;

public interface VehicleRepo extends JpaRepository<Vehicle, Long> {
	
	

}
