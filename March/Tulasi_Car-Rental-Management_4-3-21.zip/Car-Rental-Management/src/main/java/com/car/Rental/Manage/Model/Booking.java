package com.car.Rental.Manage.Model;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name="Bookings")
public class Booking {
	
	@Id // this is the primary key for this record
	@GeneratedValue(strategy = GenerationType.IDENTITY)  // defines how this id is to be generated....??
	@Column(name="BookingId")  // The following attribute is linked to this column in the db table
	private long bookId;	
	

    @NotNull
	@DateTimeFormat(pattern = "yyyy-MM-dd'T'HH:mm")
    private LocalDateTime startTime;//starting date time in seconds

    @NotNull
	@DateTimeFormat(pattern = "yyyy-MM-dd'T'HH:mm")
	private LocalDateTime endTime;
	
    @NotNull
	private double dailyRate;  // daily rate of this Vehicle as at time of hire,
    // rate will be used through out this Hire.
	
    @NotNull
	private double deposit;
	
    @NotNull
	private double bookingFee;

	@DateTimeFormat(pattern = "yyyy-MM-dd'T'HH:mm")
	private LocalDateTime actualEndTime;
	
	private double totalCost;

	public Booking() {
		super();
	}

	public long getBookId() {
		return bookId;
	}

	public void setBookId(long bookId) {
		this.bookId = bookId;
	}

	public LocalDateTime getStartTime() {
		return startTime;
	}

	public void setStartTime(LocalDateTime startTime) {
		this.startTime = startTime;
	}

	public LocalDateTime getEndTime() {
		return endTime;
	}

	public void setEndTime(LocalDateTime endTime) {
		this.endTime = endTime;
	}

	public double getDailyRate() {
		return dailyRate;
	}

	public void setDailyRate(double dailyRate) {
		this.dailyRate = dailyRate;
	}

	public double getDeposit() {
		return deposit;
	}

	public void setDeposit(double deposit) {
		this.deposit = deposit;
	}

	public double getBookingFee() {
		return bookingFee;
	}

	public void setBookingFee(double bookingFee) {
		this.bookingFee = bookingFee;
	}

	public LocalDateTime getActualEndTime() {
		return actualEndTime;
	}

	public void setActualEndTime(LocalDateTime actualEndTime) {
		this.actualEndTime = actualEndTime;
	}

	public double getTotalCost() {
		return totalCost;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public Vehicle getVehicle() {
		return vehicle;
	}

	public void setVehicle(Vehicle vehicle) {
		this.vehicle = vehicle;
	}

	public Employee getEmployee() {
		return employee;
	}

	public void setEmployee(Employee employee) {
		this.employee = employee;
	}

	public void setTotalCost(double totalCost) {
		this.totalCost = totalCost;
	}

	

	 @ManyToOne(fetch = FetchType.EAGER, optional = false)
	  @JoinColumn(name = "CUSTID",nullable = false)
	  private Customer customer;
	
	 
	 @ManyToOne(fetch = FetchType.EAGER, optional = false)
	    @JoinColumn(name = "VEHID", nullable = false)
		private Vehicle vehicle;
	
	  @ManyToOne(fetch = FetchType.EAGER, optional = false)
	  @JoinColumn(name = "EMPLOYEEID", nullable = false)
		private Employee employee;
//	  @OneToMany
//		@JoinColumn(name = "VEHBOOKID")
//		private List<Vehicle> vehicles = new ArrayList<>();
//	    
//	    @OneToMany
//	   	@JoinColumn(name = "CUSTBOOKID")
//	   	private List<Customer> customers = new ArrayList<>();
   

}
