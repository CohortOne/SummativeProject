package com.car.Rental.Manage.Repo;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.car.Rental.Manage.Model.Customer;

@Repository
public interface CustomerRepo extends JpaRepository<Customer, Long> {

		
}
