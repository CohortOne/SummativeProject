package com.car.Rental.Manage.Controller;

import java.awt.Color;
import java.io.IOException;
import java.text.NumberFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.car.Rental.Manage.Model.Booking;
import com.car.Rental.Manage.Model.Customer;
import com.car.Rental.Manage.Model.Employee;
import com.car.Rental.Manage.Model.VehStatus;
import com.car.Rental.Manage.Model.Vehicle;
import com.car.Rental.Manage.Repo.BookingRepo;
import com.car.Rental.Manage.Repo.CustomerRepo;
import com.car.Rental.Manage.Repo.EmployeeRepo;
import com.car.Rental.Manage.Repo.VehicleRepo;
import com.car.Rental.Manage.Repo.VehicleStatusRepo;
import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.Element;
import com.lowagie.text.Font;
import com.lowagie.text.FontFactory;
import com.lowagie.text.PageSize;
import com.lowagie.text.Paragraph;
import com.lowagie.text.Phrase;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;



@Controller
public class BookingController {

	@Autowired 
	private BookingRepo bookRepo;
	
	@Autowired
	private CustomerRepo custRepo;
	
	@Autowired
	private VehicleRepo vehRepo;
	
	@Autowired
	private EmployeeRepo empRepo;
	
	@Autowired
	private VehicleStatusRepo vehSttsRepo;
	
	
	
	
	NumberFormat defaultFormat = NumberFormat.getCurrencyInstance();
	DateTimeFormatter dtsFormat = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
	DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern("yyyy-MM-dd");
			
	@GetMapping("/booking")
	public String listProducts(Model model) {
		List<Booking> listBooking = bookRepo.findAll();
		model.addAttribute("listBooking",listBooking);
		return "booking";
	}
	
	@GetMapping("/NewBooking")
	public String showNewBookingForm(Model model) {
		List<Customer> listcust =  custRepo.findAll();
		List<Vehicle>  listVeh = vehRepo.findAll();
//		Vehicle listVeh = new Vehicle();
//		if (listVehId>0) {
//			listVeh =  vehRepo.getVehicleById(listVeh);
//		}
//		listVeh= listVeh.getVehId();
//		model.addAttribute("listVeh", listVeh);
//		model.addAttribute("listVehId", listVeh);
//          VehStatus vehicle = new VehStatus();
//          if(vehicle.getVehSttsId() == 1) {
//        	  
//        	  System.out.println("Vehicle Status :" +vehicle);   	 
//        	  
//          }
//		
//		for (int i = 0; i< detailNames.length; i++) {
//			if(detailIDs != null && detailIDs.length > 0)
//				product.setDetails(Integer.valueOf(detailIDs[i]), detailNames[i], detailValues[i]);
//			else {
//				product.addDetail(detailNames[i], detailValues[i]);
		
				
		
		List<Employee> listEmp = empRepo.findAll();
		model.addAttribute("booking", new Booking());
		model.addAttribute("listcust",listcust);
		model.addAttribute("listVeh",listVeh);
		model.addAttribute("listEmp", listEmp);
		return "NewBooking";
		
	}
		
	@PostMapping("/booking/save")
	public String saveBooking(Booking booking, HttpServletRequest request) {
		bookRepo.save(booking);
		return "redirect:/booking";
	}
	

	
	@GetMapping("/updateBooking/{bookId}")
	public String ShowBookingEditForm(@PathVariable("bookId") long bookId, Model model) {
		Booking booking = bookRepo.findById(bookId).get();
		model.addAttribute("booking", booking);
		List<Customer> listcust = custRepo.findAll();
		List<Vehicle>  listVeh = vehRepo.findAll();
		List<Employee> listEmp = empRepo.findAll();
		model.addAttribute("listcust",listcust);
		model.addAttribute("listVeh",listVeh);
		model.addAttribute("listEmp", listEmp);
		return "updateBooking";
		
	}
	
	@GetMapping("/booking/delete/{bookId}")
	public String ShowbookingDeleteForm(@PathVariable("bookId") long bookId, Model model) {
		bookRepo.deleteById(bookId);
		return "redirect:/booking";
	}
	
	
	
	//@ApiOperation(value="Brings high-lighted hire record to editing area for return", response=Iterable.class, tags="home")
	@GetMapping("/CarReturn/{bookId}")
	public String CarReturn(@PathVariable(value = "bookId") long bookId, 
			Model model, 
			HttpSession session) {

//		if ((!hasRole("MANAGER")) && (!hasRole("USER"))) {return "/403";}
//		if (!loadSessionAttributes(session)) {return "redirect:/";}

		// Get hire from the Service
		 Booking listBooking = new Booking();
		
		if (bookId == 0) {
			// this method is not expected to be invoked with hireId=0
		} else {
			if (bookId > 0) {  // bring details of existing hire into input area for hire return
				 Booking listBook = bookRepo.getOne(bookId);
				if (listBooking.getActualEndTime()!=null)//.getEmpReturn()!=null) {
					model.addAttribute("optMsg", "Booking (" + bookId + ") is already returned.");
					return "booking";//hirePaginated(0, model, session);
				}
			//newHire.setHireId(hire.getHireId());
			listBooking.setBookId(listBooking.getBookId());
			//newHire.setCustomer(hire.getCustomer());
			listBooking.setCustomer(listBooking.getCustomer());
			//newHire.setVehicle(hire.getVehicle());
			listBooking.setVehicle(listBooking.getVehicle());
		//	newHire.setEmpFulfill(hire.getEmpFulfill());
	    //newHire.setEmpReturn(employeeDao.getEmployeeByEmpName(empName));
			listBooking.setStartTime(listBooking.getStartTime());//.getDtsStart());
			listBooking.setEndTime(listBooking.getEndTime());
			listBooking.setDeposit(listBooking.getDeposit());
			listBooking.setDailyRate(listBooking.getDailyRate());
			listBooking.setBookingFee(listBooking.getBookingFee());
			listBooking.setActualEndTime(java.time.LocalDateTime.now());
			listBooking.setBookingFee(computeFee(listBooking.getDailyRate(), listBooking.getStartTime(), listBooking.getEndTime(), listBooking.getActualEndTime(), null, null, null));
				model.addAttribute("optMsg", "Enter the actual return date time, click <Save> to confirm return of vehicle.");
			}
		model.addAttribute("listBooking",listBooking);
		return "booking";
		}

	private double computeFee(double dailyRate, LocalDateTime startTime, LocalDateTime endTime,
			LocalDateTime actualEndTime, Object object, Object object2, Object object3) {
		// TODO Auto-generated method stub
		return 0;
	}

	@GetMapping("/InvoicePdf/{bookId}")
    public void hirePdf(@PathVariable(value = "bookId") long bookId,
    		HttpServletResponse response) throws DocumentException, IOException {

		response.setContentType("application/pdf");
         
        String headerKey = "Content-Disposition";
        String headerValue = "attachment; filename=Booking_" + bookId + ".pdf";
        response.setHeader(headerKey, headerValue);

       Booking listBooking = bookRepo.getOne(bookId);//getHireById(bookId);
         
        Document document = new Document(PageSize.A4);
        PdfWriter.getInstance(document, response.getOutputStream());
         
        document.open();
        Font font = FontFactory.getFont(FontFactory.HELVETICA_BOLD);
        font.setSize(18);
        font.setColor(Color.BLUE);

        Font fontData = FontFactory.getFont(FontFactory.HELVETICA);
        fontData.setSize(11);
        fontData.setColor(Color.BLACK);
        
        Paragraph p = new Paragraph("CarRental Leisure Vehicle Booking Company Limited", font);
        p.setAlignment(Paragraph.ALIGN_CENTER);
        document.add(p);
        p = new Paragraph("Vehicle Booking Invoice", font);
        p.setAlignment(Paragraph.ALIGN_CENTER);
        document.add(p);

        
        // print customer and vehicle details
        PdfPTable table = new PdfPTable(4);
        table.setWidthPercentage(100f);
        table.setWidths(new float[] {3.5f, 1.5f, 3.0f, 3.0f});
        table.setSpacingBefore(10);
         
        PdfPCell cell = new PdfPCell();
        cell.setBackgroundColor(Color.DARK_GRAY);
        cell.setPadding(5);
         
        font = FontFactory.getFont(FontFactory.HELVETICA);
        font.setColor(Color.WHITE);

        PdfPCell cellData = new PdfPCell();
        cellData.setPadding(5);
        
        cell.setPhrase(new Phrase("Customer ID", font));
        table.addCell(cell);

        String strId = "" + listBooking.getCustomer().getCustId();
        cellData.setPhrase(new Phrase(strId, fontData));
        table.addCell(cellData);
         
        cell.setPhrase(new Phrase("Name", font));
        table.addCell(cell);

        cellData.setPhrase(new Phrase(listBooking.getCustomer().getCustName(), fontData));
        table.addCell(cellData);
         
        // new row
//        cell.setPhrase(new Phrase("Alternate contact", font));
//        table.addCell(cell);

        strId = "" + listBooking.getCustomer().getAddress();//getCustLinked().getCustId();
        cellData.setPhrase(new Phrase(strId, fontData));
        table.addCell(cellData);
         
        cell.setPhrase(new Phrase("Name", font));
        table.addCell(cell);

//        cellData.setPhrase(new Phrase(listBooking.getCustomer().getCustLinked().getCustName(), fontData));
//        table.addCell(cellData);
         
        // new row
        cell.setPhrase(new Phrase("Vehicle Id", font));
        table.addCell(cell);

        strId = "" + listBooking.getVehicle().getVehId();
        cellData.setPhrase(new Phrase(strId, fontData));
        table.addCell(cellData);
         
        cell.setPhrase(new Phrase("Daily rate", font));
        table.addCell(cell);

        strId = defaultFormat.format(listBooking.getDailyRate());
        cellData.setPhrase(new Phrase(strId, fontData));
        table.addCell(cellData);

         
        // new row
        cell.setPhrase(new Phrase("Brand", font));
        table.addCell(cell);

        cellData.setPhrase(new Phrase(listBooking.getVehicle().getVehBrand(), fontData));
        table.addCell(cellData);
         
//        cell.setPhrase(new Phrase("License", font));
//        table.addCell(cell);
//
//        cellData.setPhrase(new Phrase(myHire.getVehicle().getVehLicPlate(), fontData));
//        table.addCell(cellData);
         
        // new row
        cell.setPhrase(new Phrase("Type", font));
        table.addCell(cell);

        cellData.setPhrase(new Phrase(listBooking.getVehicle().getVehType(), fontData));
        table.addCell(cellData);
         
        cellData.setPhrase(new Phrase(" ", font));
        table.addCell(cellData);
        table.addCell(cellData);
         
        document.add(table);
        
        
        // print hire agreement
        table = new PdfPTable(4);
        table.setWidthPercentage(100f);
        table.setWidths(new float[] {2.0f, 3.0f, 2.0f, 3.0f});
        table.setSpacingBefore(10);
         
        cell = new PdfPCell();
        cell.setBackgroundColor(Color.DARK_GRAY);
        cell.setPadding(5);
         
        font = FontFactory.getFont(FontFactory.HELVETICA);
        font.setColor(Color.WHITE);
         
        cell.setPhrase(new Phrase("Booking Starts", font));
        table.addCell(cell);

        strId = dtsFormat.format(listBooking.getStartTime());
        cellData.setPhrase(new Phrase(strId, fontData));
        table.addCell(cellData);
         
        cell.setPhrase(new Phrase("Booking Id", font));
        table.addCell(cell);

        strId = "" +listBooking.getBookId();//getHireId();
        cellData.setPhrase(new Phrase(strId, fontData));
        table.addCell(cellData);
         
        // new row
        cell.setPhrase(new Phrase("Booking End", font));
        table.addCell(cell);

        strId = dtsFormat.format(listBooking.getEndTime());
        cellData.setPhrase(new Phrase(strId, fontData));
        table.addCell(cellData);
        
        if (listBooking.getActualEndTime()==null) {
	        cellData.setPhrase(new Phrase(" ", fontData));
	        table.addCell(cellData);
	        table.addCell(cellData);
        } else {
	        cell.setPhrase(new Phrase("Actual Return", font));
	        table.addCell(cell);
	        strId = dtsFormat.format(listBooking.getActualEndTime());//.getDtsEndActual());
	        cellData.setPhrase(new Phrase(strId, fontData));
	        table.addCell(cellData);
        }
         
        document.add(table);
        
        
        
        // print hire billing details
        table = new PdfPTable(6);
        table.setWidthPercentage(100f);
        table.setWidths(new float[] {3.5f, 3f, 3f, 1.7f, 1.8f, 1.8f});
        table.setSpacingBefore(10);

        cell = new PdfPCell();
        cell.setBackgroundColor(Color.DARK_GRAY);
        cell.setPadding(5);
         
        font = FontFactory.getFont(FontFactory.HELVETICA);
        font.setColor(Color.WHITE);
         
        cell.setPhrase(new Phrase("Booking type", font));
        table.addCell(cell);
        cell.setPhrase(new Phrase("Start", font));
        table.addCell(cell);
        cell.setPhrase(new Phrase("End", font));
        table.addCell(cell);
        cell.setPhrase(new Phrase("Quantity", font));
        table.addCell(cell);
        cell.setPhrase(new Phrase("Rate", font));
        table.addCell(cell);
        cell.setPhrase(new Phrase("Amount", font));
        
        table.addCell(cell);

        // call fee computing method to generate billing details
        double feeIs = computeFee(listBooking.getDailyRate(), listBooking.getStartTime(),listBooking.getEndTime(),listBooking.getActualEndTime(), table, cellData, fontData);

        if (listBooking.getDeposit()>0) {
        	cellData.setPhrase(new Phrase("Deposit received", fontData));
	        table.addCell(cellData);
	        strId = dateFormat.format(listBooking.getStartTime());
        	cellData.setPhrase(new Phrase(strId, fontData));
	        table.addCell(cellData);
	        table.addCell("");
	        table.addCell("");
	        table.addCell("");
	        strId = defaultFormat.format(listBooking.getDeposit());
	        cellData.setPhrase(new Phrase(strId, fontData));
	        cellData.setHorizontalAlignment(Element.ALIGN_RIGHT);
	        table.addCell(cellData);

	        
	        table.addCell("");
	        table.addCell("");
	        table.addCell("");
	        table.addCell("");
        	cellData.setPhrase(new Phrase("Balance", fontData));
	        table.addCell(cellData);
	        strId = defaultFormat.format(feeIs - listBooking.getDeposit());
	        cellData.setPhrase(new Phrase(strId, fontData));
	        cellData.setHorizontalAlignment(Element.ALIGN_RIGHT);
	        table.addCell(cellData);
        }

         
        document.add(table);

        // Print customer acknowledge portion during vehicle pickup.
        if (listBooking.getActualEndTime()==null) {
	        p = new Paragraph("I acknowledge that the said Vehicle is received in satisfactory condition:");
	        document.add(p);
	        p = new Paragraph(" ");
	        document.add(p);
	        document.add(p);
	        document.add(p);
	        document.add(p);
	        p = new Paragraph("Customer Signature and Date");
	        p.setAlignment(Paragraph.ALIGN_RIGHT);
	        document.add(p);
        }
        

        
        document.close();
        

}
}
	

