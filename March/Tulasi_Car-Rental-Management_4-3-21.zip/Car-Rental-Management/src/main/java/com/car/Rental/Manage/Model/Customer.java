package com.car.Rental.Manage.Model;

import java.time.LocalDate;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.springframework.format.annotation.DateTimeFormat;



@Entity
@Table
public class Customer {
	
	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY)  
	@Column(name="CUSTID") 
	private long custId;
	
	
	@Column(name = "CUSTNAME")  
	@Size (min = 5, max = 45)
	@NotNull
	private String custName;

	@Column(unique=true)
	@Size (min = 9, max = 9, message="Enter a 9-char code")
	@NotNull
	private String nric;
	
	@Column(name = "EMAIL", unique=true)
	@Email
	@Size (min = 8, max = 30)
	@NotNull
	private String custEmail;
	
	@Column(name = "PHONENO", unique=true)
	@Size (min = 8, max = 15)
	@NotNull
	private String custPhoneNo;

	@Column(name = "ADDRESS")  
	@Size (min = 2, max = 30)
	@NotNull(message = "Should not be null")
	private String address;
	
	@Column(name = "CITY")  
	@Size (min = 2, max = 30)
	@NotNull
	private String city;
	
	@NotNull
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private LocalDate dob;

	@Column(name = "ISACTIVE")
	private boolean isActive;
	
	@NotNull
	@Column(name="LastUpdate")
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private LocalDate lastUpd; //Last Update
	
	
	
	public Customer() {
		
	}



	public long getCustId() {
		return custId;
	}



	public void setCustId(long custId) {
		this.custId = custId;
	}



	public String getCustName() {
		return custName;
	}



	public void setCustName(String custName) {
		this.custName = custName;
	}



	public String getNric() {
		return nric;
	}



	public void setNric(String nric) {
		this.nric = nric;
	}



	public String getCustEmail() {
		return custEmail;
	}



	public void setCustEmail(String custEmail) {
		this.custEmail = custEmail;
	}



	public String getCustPhoneNo() {
		return custPhoneNo;
	}



	public void setCustPhoneNo(String custPhoneNo) {
		this.custPhoneNo = custPhoneNo;
	}



	public String getAddress() {
		return address;
	}



	public void setAddress(String address) {
		this.address = address;
	}



	public String getCity() {
		return city;
	}



	public void setCity(String city) {
		this.city = city;
	}



	public LocalDate getDob() {
		return dob;
	}



	public void setDob(LocalDate dob) {
		this.dob = dob;
	}



	public boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(boolean isActive) {
		this.isActive = isActive;
	}


	public LocalDate getLastUpd() {
		return lastUpd;
	}



	public void setLastUpd(LocalDate lastUpd) {
		this.lastUpd = lastUpd;
	}



	@Override
	public String toString() {
		return "Customer [custId=" + custId + ", custName=" + custName + ", nric=" + nric + ", custEmail=" + custEmail
				+ ", custPhoneNo=" + custPhoneNo + ", address=" + address + ", city=" + city + ", dob=" + dob
				+ ", isActive=" + isActive + ", lastUpd=" + lastUpd + "]";
	}



	
   


//
//	  //links this.cutomer to current booking
//	 @ManyToOne(fetch = FetchType.EAGER, optional = true)
//     @JoinColumn(name = "bookId", nullable = true)
//	   private Booking reservation;
//
//		// links this.Customer to bookings
//	    @OneToMany(fetch = FetchType.EAGER)
//	    private Set<Booking> bookings;
//
//
//
//		public Booking getReservation() {
//			return reservation;
//		}
//
//
//
//		public void setReservation(Booking reservation) {
//			this.reservation = reservation;
//		}
//
//
//
//		public Set<Booking> getBookings() {
//			return bookings;
//		}
//
//
//
//		public void setBookings(Set<Booking> bookings) {
//			this.bookings = bookings;
//		}
//
//	
	
}
