package com.car.Rental.Manage.Model;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.springframework.format.annotation.DateTimeFormat;


@Entity
public class Employee implements Serializable {
	
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)  // defines how this id is to be generated....??
	@Column(name="EMPLOYEEID")  // The following attribute is linked to this column in the db table
	private long empId;

	@Column(name = "EMPNAME", nullable = false, unique = true)
	@Size (min = 4, max = 25)
	@NotNull
	private String empName;

	@NotNull
	@Size (min = 6, max = 8)
	@Column(name="PASSWORD")
	
	private String ePassword;

	@Size (min = 8, max = 13)
	@NotNull
	@Column(name="PHONENO")
	private String ePhoneNo;

	@Column(name = "EMAIL", unique=true)
	@Email(message = " Should be a valid Email Address")
	@Size (min = 8, max = 30)
	@NotNull
	private String email;
	
	@Column(name = "ISACTIVE") 
	private boolean eStatus;

	@NotNull
	@Column(name = "STARTDATE") 
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private LocalDate eStartDate;

	@Column(name="reset_password_token")
	private String resetPasswordToken;
	
	
	public String getResetPasswordToken() {
		return resetPasswordToken;
	}




	public void setResetPasswordToken(String resetPasswordToken) {
		this.resetPasswordToken = resetPasswordToken;
	}




	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName + ", ePassword=" + ePassword + ", ePhoneNo="
				+ ePhoneNo + ", email=" + email + ", eStatus=" + eStatus + ", eStartDate=" + eStartDate + ", roles="
				+ roles + "]";
	}




	public Employee() {}

	
	

	public Employee(@Size(min = 4, max = 8) @NotNull String empName, @NotNull String ePassword,
			@Size(min = 8, max = 150) @NotNull String ePhoneNo, @Email @Size(min = 8, max = 30) @NotNull String email,
			boolean eStatus, @NotNull LocalDate eStartDate) {
		super();
		this.empName = empName;
		this.ePassword = ePassword;
		this.ePhoneNo = ePhoneNo;
		this.email = email;
		this.eStatus = eStatus;
		this.eStartDate = eStartDate;
	}




	public long getEmpId() {
		return empId;
	}




	public void setEmpId(long empId) {
		this.empId = empId;
	}




	public String getEmpName() {
		return empName;
	}




	public void setEmpName(String empName) {
		this.empName = empName;
	}




	public String getePassword() {
		return ePassword;
	}




	public void setePassword(String ePassword) {
		this.ePassword = ePassword;
	}




	public String getePhoneNo() {
		return ePhoneNo;
	}




	public void setePhoneNo(String ePhoneNo) {
		this.ePhoneNo = ePhoneNo;
	}




	public String getEmail() {
		return email;
	}




	public void setEmail(String email) {
		this.email = email;
	}




	public boolean iseStatus() {
		return eStatus;
	}




	public void seteStatus(boolean eStatus) {
		this.eStatus = eStatus;
	}




	public LocalDate geteStartDate() {
		return eStartDate;
	}




	public void seteStartDate(LocalDate eStartDate) {
		this.eStartDate = eStartDate;
	}




	public Set<Role> getRoles() {
		return roles;
	}




	public void setRoles(Set<Role> roles) {
		this.roles = roles;
	}




	@ManyToMany(fetch = FetchType.EAGER)
	@JoinTable(
			name = "EMPLOYEES_ROLES",
			joinColumns = @JoinColumn(name = "EMPLOYEEID"),
			inverseJoinColumns = @JoinColumn(name = "ROLEID")
			)
	
	private Set<Role> roles = new HashSet<>();


	

	

	
	
}
