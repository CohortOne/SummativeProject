package com.car.Rental.Manage.Controller;

import java.util.List;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.car.Rental.Manage.Model.Employee;
import com.car.Rental.Manage.Model.Role;
import com.car.Rental.Manage.Repo.EmployeeRepo;
import com.car.Rental.Manage.Repo.RoleRepo;


@Controller
public class EmployeeController {

	@Autowired
	 private EmployeeRepo empRepo;
	
	@Autowired
	private RoleRepo rolerepo;
	
	
	@GetMapping("/")
	public String viewHomePage() {
		return "index";
	}
	
	@RequestMapping("/employee")
	public String ShowEmpList(Model model,HttpSession session) {
		List<Employee> listEmp = empRepo.findAll(); 
		model.addAttribute("listEmp", listEmp);
		return "employee";

}

	@GetMapping("/newEmployeeReg")
	public String newEmployeeReg(Model model) {
		List<Role> roles = rolerepo.findAll();
		model.addAttribute("roles",roles);
		model.addAttribute("Employee" , new Employee());
		
		return "newEmployeeReg";
	}
	@PostMapping("/employee/save")
	public String saveEmployee(@Valid @ModelAttribute("Employee")Employee employee, BindingResult bindingResult) {
		if(bindingResult.hasErrors()) {
			//System.out.println(bindingResult.getAllErrors());
		return "newEmployeeReg";
		}
		empRepo.save(employee);
		return "redirect:/employee";
	}
	
	
	@GetMapping("/UpdateEmp/{empId}")
	public String ShowEditForm(@PathVariable("empId") Long empId, Model model) {
		Employee employee =   empRepo.findById(empId).get();
		model.addAttribute("Employee", employee);
		
		List<Role> roles = rolerepo.findAll();
		model.addAttribute("roles", roles);
		
		return "UpdateEmp";
	}
	
	@GetMapping("/delete/{empId}")
	public String deleteUser(@PathVariable("empId") Long empId, Model model) {
		empRepo.deleteById(empId);
		
		return "redirect:/employee";
		
	}
	

}
