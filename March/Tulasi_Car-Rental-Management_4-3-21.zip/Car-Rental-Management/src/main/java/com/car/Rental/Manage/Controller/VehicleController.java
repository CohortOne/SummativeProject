package com.car.Rental.Manage.Controller;

import java.awt.PageAttributes.MediaType;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.security.Principal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.car.Rental.Manage.Model.Booking;
import com.car.Rental.Manage.Model.VehStatus;
import com.car.Rental.Manage.Model.Vehicle;
import com.car.Rental.Manage.Repo.BookingRepo;
import com.car.Rental.Manage.Repo.VehicleRepo;
import com.car.Rental.Manage.Repo.VehicleStatusRepo;



@Controller
public class VehicleController {
	
	@Autowired
	private VehicleRepo vehRepo;
	
	@Autowired 
	private VehicleStatusRepo vehSttsRepo;
	
	@Autowired
	private BookingRepo bookRepo;
	

	
	
	
	@RequestMapping("/vehicle")
	public String ShowVehList(Model model) {
		List<Vehicle> listVeh = vehRepo.findAll();
		
		model.addAttribute("listVeh", listVeh);
		
		return "vehicle";
	}

	
	@GetMapping("/newVehicleReg")
	public String newVehicleReg(Model model) {
		List<VehStatus> vehStatus =  vehSttsRepo.findAll();
	
		model.addAttribute("vehStatus",vehStatus);
		
		model.addAttribute("Vehicle" , new Vehicle());		
		return "newVehicleReg";
	}
//	@PostMapping("/vehicle/save")
//	public String saveVehicle(Vehicle vehicle,
//			@RequestParam("Image") MultipartFile mulitipartFile) throws IOException{
//	String filename = StringUtils.cleanPath(mulitipartFile.getOriginalFilename()) ;
//		vehicle.setPhotos(filename);
//		 Vehicle saveVehicle = vehRepo.save(vehicle);
//		String uploadDir="vehicle-photos/ "+ saveVehicle.getVehId();
//		FileUploadUtil.saveFile(uploadDir, filename, mulitipartFile);
//		return "redirect:/vehicle";
//	}
//	
	@PostMapping("/vehicle/save")
	public String  saveVehicle(Vehicle vehicle)
			{ 
		vehRepo.save(vehicle);
		return "redirect:/vehicle";
	}
	@RequestMapping(value="/vehicle/uploadPhoto", method=RequestMethod.POST)
	public ResponseEntity<Object> uploadFile(@RequestParam("file") MultipartFile file) throws IOException {
		File newFile = new File("C:\\SUMMATIVE CAPSTONE PROJECT-9thFeb-17thMar\\Car-Rental-Management\\src\\main\\resources\\static\\images\\portfolio" + file.getOriginalFilename());
		newFile.createNewFile();
		FileOutputStream fout = new FileOutputStream(newFile);
		fout.write(file.getBytes());
		fout.close();
		return new ResponseEntity<>("File uploaded successfully", HttpStatus.OK);
	}	
	
	
	@PostMapping("/vehicle/uploadPhoto2")
	public String uploadFile2(@RequestParam("file") MultipartFile file, Principal principal) 
			throws IllegalStateException, IOException {
			String baseDirectory = "C:\\SUMMATIVE CAPSTONE PROJECT-9thFeb-17thMar\\Car-Rental-Management\\src\\main\\resources\\static\\images\\portfolio";
			file.transferTo(new File(baseDirectory + principal.getName() + ".jpg"));
			return "redirect:/vehicle";
	}
	
	
	@GetMapping("/UpdateVehicle/{vehId}")
	public String ShowEditForm(@PathVariable("vehId") Long vehId, Model model) {
		Vehicle vehicle =   vehRepo.findById(vehId).get();
		model.addAttribute("Vehicle", vehicle);
		
		List<VehStatus> vehStatus =  vehSttsRepo.findAll();
		model.addAttribute("vehStatus",vehStatus);
		
		return "UpdateVehicle";
	}
	
	@GetMapping("/deleteRecord/{vehId}")
	public String deleteVehicle(@PathVariable(value = "vehId") long vehId,
			Model model){
		vehRepo.deleteById(vehId);
		
		return "redirect:/vehicle";
		
	}
	
	}


