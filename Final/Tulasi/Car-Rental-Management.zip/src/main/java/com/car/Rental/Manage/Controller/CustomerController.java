package com.car.Rental.Manage.Controller;

import java.util.List;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.car.Rental.Manage.Model.Booking;
import com.car.Rental.Manage.Model.Customer;
import com.car.Rental.Manage.Model.Vehicle;
import com.car.Rental.Manage.Repo.BookingRepo;
import com.car.Rental.Manage.Repo.CustomerRepo;
import com.car.Rental.Manage.service.CustomerService;

 

@Controller
public class CustomerController {
	
	@Autowired
	private CustomerService custService;
	
	@Autowired
	private CustomerRepo custRepo;
	
	@Autowired	
	private BookingRepo bookRepo;
	
		
	
	@RequestMapping("/customer")
	public String viewHomePage(Model model,@Param("keyword")String keyword) {
		//model.addAttribute("listCustomers", customerDao.getAllCustomers());
		return findPageinated(1,  model, "custId", "ASC",  keyword);
	}
	
	@GetMapping("/page/{pageNo}")
	public String findPageinated(@PathVariable(value = "pageNo") int pageNo,
			                                     Model model, 
											@Param("sortField") String sortField, 
											@Param("sortDirection") String sortDirection, 
											@Param("keyword") String keyword
											) {
		
		int pageSize = 5;
		Page <Customer> page = custService.findPageinated(pageNo, pageSize, sortField, sortDirection, keyword);
		List <Customer> listcust = page.getContent();
		model.addAttribute("listcust", listcust);
		model.addAttribute("totalPages", page.getTotalPages());
		model.addAttribute("totalItems", page.getTotalElements());
		model.addAttribute("currentPage", pageNo);
		model.addAttribute("sortField", sortField);
		model.addAttribute("sortDirection", sortDirection);
		model.addAttribute("reverseSortDirection", sortDirection.equalsIgnoreCase("ASC") ? "DESC" : "ASC");
		model.addAttribute("keyword", keyword);
		return "customer";
	}

	@GetMapping("/newCustomerReg")
	public String newCustomerReg(Model model) {
		//List<Booking> bookings =  bookRepo.findAll();
		//model.addAttribute("bookings",bookings);
		model.addAttribute("Customer" , new Customer());
		
		return "newCustomerReg";
	}
	@PostMapping("/customer/save")
	public String  saveCustomer(@Valid @ModelAttribute("Customer")Customer customer, BindingResult bindingResult) {
		
		if(bindingResult.hasErrors()) {
			System.out.println(bindingResult.getAllErrors());
			return "newCustomerReg";
		}else
		
		custRepo.save(customer);
		return "redirect:/customer";
	}
	
	@GetMapping("/UpdateCustomer/{custId}")
	public String ShowEditForm(@PathVariable("custId") Long custId, Model model) {
		Customer customer=   custRepo.findById(custId).get();
		model.addAttribute("Customer", customer);		
			
		return "UpdateCustomer";
	}
	
	@GetMapping("/deleteCust/{custId}")
	public String deleteCustomer(@PathVariable("custId") Long custId, Model model) {
		custRepo.deleteById(custId);
		
		return "redirect:/customer";

		
}
}
