package com.car.Rental.Manage.Controller;

import java.io.File;
import java.io.IOException;
import java.text.NumberFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.InputStreamResource;
import org.springframework.data.domain.Page;
import org.springframework.data.repository.query.Param;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.car.Rental.Manage.Model.Booking;
import com.car.Rental.Manage.Model.Customer;
import com.car.Rental.Manage.Model.Employee;
import com.car.Rental.Manage.Model.Vehicle;
import com.car.Rental.Manage.Repo.BookingRepo;
import com.car.Rental.Manage.Repo.CustomerRepo;
import com.car.Rental.Manage.Repo.EmployeeRepo;
import com.car.Rental.Manage.Repo.VehicleRepo;
import com.car.Rental.Manage.Repo.VehicleStatusRepo;
import com.car.Rental.Manage.service.BookingService;
import com.car.Rental.Manage.service.MessagesBean;
import com.spire.doc.Document;
import com.spire.doc.FileFormat;
import com.spire.doc.Table;
import com.spire.doc.fields.Field;

@Controller
public class BookingController {

	@Autowired
	private BookingRepo bookRepo;

	@Autowired
	private CustomerRepo custRepo;

	@Autowired
	private VehicleRepo vehRepo;

	@Autowired
	private EmployeeRepo empRepo;

	@Autowired
	private VehicleStatusRepo vehSttsRepo;

	@Autowired
	private MessagesBean messages;

	@Autowired
	private BookingService bookService;

	NumberFormat defaultFormat = NumberFormat.getCurrencyInstance();
	DateTimeFormatter dtsFormat = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
	DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern("yyyy-MM-dd");


	@RequestMapping("/booking")
	public String listBooking(Model model, @Param("keyword") String keyword) {
		// List<Booking> listBooking = bookRepo.findAll();
		// model.addAttribute("listBooking",listBooking);
		return findPageinated3(1, model, "bookId", "ASC", keyword);
	}

	@GetMapping("/page3/{pageNo}")
	private String findPageinated3(@PathVariable(value = "pageNo") int pageNo, Model model,
			@Param("sortField") String sortField, @Param("sortDirection") String sortDirection,
			@Param("keyword") String keyword) {
		int pageSize = 10;
		Page<Booking> page = bookService.findPageinated3(pageNo, pageSize, sortField, sortDirection, keyword);
		List<Booking> listBooking = page.getContent();
		model.addAttribute("listBooking", listBooking);
		model.addAttribute("totalPages", page.getTotalPages());
		model.addAttribute("totalItems", page.getTotalElements());
		model.addAttribute("currentPage", pageNo);
		model.addAttribute("sortField", sortField);
		model.addAttribute("sortDirection", sortDirection);
		model.addAttribute("reverseSortDirection", sortDirection.equalsIgnoreCase("ASC") ? "DESC" : "ASC");
		model.addAttribute("keyword", keyword);

		return "booking";
	}

	@GetMapping("/NewBooking")
	public String showNewBookingForm(Model model) {
		List<Customer> listcust = custRepo.findAll();
		List<Vehicle> listVeh = vehRepo.findAll();

		List<Employee> listEmp = empRepo.findAll();
		model.addAttribute("booking", new Booking());
		model.addAttribute("listcust", listcust);
		model.addAttribute("listVeh", listVeh);
		model.addAttribute("listEmp", listEmp);
		return "NewBooking";

	}

	@PostMapping("/booking/save")
	public String saveBooking(Booking booking, HttpServletRequest request) {
		bookRepo.save(booking);
		return "redirect:/booking";
	}

	@PostMapping("/booking/saveReturn")
	public String saveReturn(Booking listBooking, HttpServletRequest request, Model model) {
		System.out.println("in save return");
		if (listBooking.getActualEndTime() == null) {
			model.addAttribute("optMsg",
					"Enter the actual return date time, click <save> to confirm return of vehicle.");
			return "redirect:/ReturnBooking/" + listBooking.getBookId();
		} else {
			Booking booking = bookRepo.getOne(listBooking.getBookId());
			booking.setActualEndTime(listBooking.getActualEndTime());
			bookRepo.save(booking);
		
			model.addAttribute("optMsg", "Vehicle Returned successfully..Thank You...");
		
			return "msg";
		}
	}

	@GetMapping("/updateBooking/{bookId}")
	public String ShowBookingEditForm(@PathVariable("bookId") long bookId, Model model) {
		Booking booking = bookRepo.findById(bookId).get();
		model.addAttribute("booking", booking);
		List<Customer> listcust = custRepo.findAll();
		List<Vehicle> listVeh = vehRepo.findAll();
		List<Employee> listEmp = empRepo.findAll();
		model.addAttribute("listcust", listcust);
		model.addAttribute("listVeh", listVeh);
		model.addAttribute("listEmp", listEmp);
		return "updateBooking";

	}

	@GetMapping("/booking/delete/{bookId}")
	public String ShowbookingDeleteForm(@PathVariable("bookId") long bookId, Model model) {
		bookRepo.deleteById(bookId);
		return "redirect:/booking";
	}

	// @ApiOperation(value="Brings high-lighted hire record to editing area for
	// return", response=Iterable.class, tags="home")
	@GetMapping("/ReturnBooking/{bookId}")
	public String CarReturn(@PathVariable(value = "bookId") long bookId, Model model, HttpSession session) {

		// Get hire from the Service
		Booking listBooking = new Booking();

		if (bookId == 0) {
			// this method is not expected to be invoked with hireId=0
		} else {
			if (bookId > 0) { // bring details of existing hire into input area for hire return
				listBooking = bookRepo.getBookingDetails(bookId);
				if (listBooking.getActualEndTime() != null)// .getEmpReturn()!=null) {
				{
					model.addAttribute("optMsg", "Booking (" + bookId + ") is already returned.");
					
					return "msg";
				} else {
					model.addAttribute("optMsg",
							"Enter the actual return date time, click <Save> to confirm return of vehicle.");
				}
			}
		}
		model.addAttribute("listBooking", listBooking);
		return "ReturnBooking";
	}

	
	
	@RequestMapping(value = "/InvoicePdf/{bookId}.pdf", method = RequestMethod.GET, produces = "application/pdf")
	// public void hirePdf(@PathVariable(value = "bookId") long
	// bookId,HttpServletResponse response) throws BindException, IOException {
	public ResponseEntity<InputStreamResource> downloads(@PathVariable(value = "bookId") long bookId)
			throws IOException {

		// String fileName = "C:\\SUMMATIVE CAPSTONE
		// PROJECT-9thFeb-17thMar\\Car-Rental-Management.zip_expanded\\Car-Rental-Management\\src\\main\\resources\\templates\\Invoice-Template.docx";

		Document doc = new Document();

		// Document document = new Document();

		// load the template file
		doc.loadFromFile(
				"C:\\SUMMATIVE CAPSTONE PROJECT-9thFeb-17thMar\\Car-Rental-Management.zip_expanded\\Car-Rental-Management\\src\\main\\resources\\templates\\Invoice-Template.docx");

		Booking booking = bookRepo.findById(bookId).get();

		// replace text in the document
		doc.replace("#InvoiceNum", String.valueOf(booking.getBookId()), true, true);
		doc.replace("#Date", dateFormat.format(LocalDate.now()), true, true);
		doc.replace("#Customer Name", booking.getCustomer().getCustName(), true, true);
		doc.replace("#Customer Address", booking.getCustomer().getAddress(), true, true);
		doc.replace("#City", booking.getCustomer().getCity(), true, true);
		doc.replace("#Email", booking.getCustomer().getCustEmail(), true, true);
		doc.replace("#Tel1", booking.getCustomer().getCustPhoneNo(), true, true);

		doc.replace("#StartDate", dateFormat.format(booking.getStartTime()), true, true);
		doc.replace("#EndDate", dateFormat.format(booking.getActualEndTime()), true, true);

		//int noofdays = Period.between(booking.getStartTime().toLocalDate(), booking.getActualEndTime().toLocalDate())
		//		.getDays();
		long noofdays = ChronoUnit.DAYS.between(booking.getStartTime().toLocalDate(), booking.getActualEndTime().toLocalDate());
		doc.replace("#SubTotal", String.valueOf(booking.getDailyRate() * noofdays), true, true);
		doc.replace("#TaxTotal", String.valueOf(booking.getDailyRate() * noofdays * 0.05), true, true);
		doc.replace("#Deposit", String.valueOf(booking.getDeposit()), true, true);
		doc.replace("#Balance", String.valueOf((booking.getDailyRate() * noofdays)
				+ (booking.getDailyRate() * noofdays * 0.05) - booking.getDeposit()), true, true);

		// define purchase data
		String[][] purchaseData = { new String[] { String.valueOf(booking.getVehicle().getVehId()),
				booking.getVehicle().getVehBrand(), booking.getVehicle().getVehRegNo(), String.valueOf(noofdays),
				String.valueOf(booking.getDailyRate()), String.valueOf(booking.getDailyRate() * noofdays) } };

		// write the purchase data to the document
		writeDataToDocument(doc, purchaseData);

		// update fields
		doc.isUpdateFields(true);

		System.out.println("save file in pdf format");
		// save file in pdf format
		System.out.println(bookId);
		
	
		doc.saveToFile(
				"C:\\SUMMATIVE CAPSTONE PROJECT-9thFeb-17thMar\\Car-Rental-Management.zip_expanded\\Car-Rental-Management\\src\\main\\resources\\templates\\InvoicePdf\\"
						+ bookId + ".pdf",
				FileFormat.PDF);

		doc.saveToFile(
				"C:\\SUMMATIVE CAPSTONE PROJECT-9thFeb-17thMar\\Car-Rental-Management.zip_expanded\\Car-Rental-Management\\src\\main\\resources\\downloads\\"
						+ bookId + ".pdf",
				FileFormat.PDF);
		
		 File filename = new File(bookId+".pdf");
		  System.out.println("Calling Download:- " + filename); 
		  ClassPathResource pdfFile = new ClassPathResource("downloads/" + filename);
		  
		  System.out.println(pdfFile);
		  HttpHeaders headers = new HttpHeaders();
		  headers.setContentType(MediaType.parseMediaType("application/pdf"));
		  
		
		  headers.setContentLength(pdfFile.contentLength());
		  headers.add("content-disposition", "attachment; filename=" + filename);
		
			ResponseEntity<InputStreamResource> response = new
			  ResponseEntity<InputStreamResource>( new
			  InputStreamResource(pdfFile.getInputStream()), headers, HttpStatus.OK);
			  return response;
			
		 
	}

	private static void writeDataToDocument(Document doc, String[][] purchaseData) {
		// get the third table
		Table table = doc.getSections().get(0).getTables().get(2);
		// determine if it needs to add rows
		if (purchaseData.length > 1) {
			// add rows
			addRows(table, purchaseData.length - 1);
		}
		// fill the table cells with value
		fillTableWithData(table, purchaseData);
	}

	private static void fillTableWithData(Table table, String[][] data) {
		for (int r = 0; r < data.length; r++) {
			for (int c = 0; c < data[r].length; c++) {
				// fill data in cells
				table.getRows().get(r + 1).getCells().get(c).getParagraphs().get(0).setText(data[r][c]);
			}
		}
	}

	private static void addRows(Table table, int rowNum) {
		for (int i = 0; i < rowNum; i++) {
			// insert specific number of rows by cloning the second row
			table.getRows().insert(2 + i, table.getRows().get(1).deepClone());
			// update formulas for Total
			for (Object object : table.getRows().get(2 + i).getCells().get(5).getParagraphs().get(0)
					.getChildObjects()) {
				if (object instanceof Field) {
					Field field = (Field) object;
					field.setCode(String.format("=B%d*C%d\\# \"0.00\"", 3 + i, 3 + i));
				}
				break;
			}
		}
		// update formula for Total Tax
		for (Object object : table.getRows().get(4 + rowNum).getCells().get(5).getParagraphs().get(0)
				.getChildObjects()) {
			if (object instanceof Field) {
				Field field = (Field) object;
				field.setCode(String.format("=D%d*0.05\\# \"0.00\"", 3 + rowNum));
			}
			break;
		}
		// update formula for Balance Due
		for (Object object : table.getRows().get(5 + rowNum).getCells().get(3).getParagraphs().get(0)
				.getChildObjects()) {
			if (object instanceof Field) {
				Field field = (Field) object;
				field.setCode(String.format("=D%d+D%d\\# \"$#,##0.00\"", 3 + rowNum, 5 + rowNum));
			}
			break;
		}

	}

	


}
