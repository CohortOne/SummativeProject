package com.car.Rental.Manage.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.car.Rental.Manage.Model.Employee;
import com.car.Rental.Manage.Repo.CustomerRepo;
import com.car.Rental.Manage.Repo.EmployeeRepo;

@Service
public class EmployeeService {
	
	@Autowired
	private EmployeeRepo empRepo;
	



	public Employee getEmployeerById(long empId) {
		Optional <Employee> optional = empRepo.findById(empId);
		Employee employee = null;
		
		if(optional.isPresent())
			employee = optional.get();
		else
			throw new RuntimeException(" Employee not found for id :: " + empId);
		
		return employee;		

	}

	

public Page<Employee> findPageinated1(int pageNo, int pageSize, String sortField, String sortDirection,String keyword) {
		Sort sort = sortDirection.equalsIgnoreCase(Sort.Direction.ASC.name()) ? Sort.by(sortField).ascending()
		               :Sort.by(sortField).descending();
				PageRequest pageble = PageRequest.of(pageNo - 1, pageSize, sort);
		
		if (keyword !=null) {
			
			return empRepo.search(keyword,pageble);
		}
				return empRepo.findAll(pageble);
	}




	
}
 



