package com.car.Rental.Manage.Repo;


import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.car.Rental.Manage.Model.Customer;

@Repository
public interface CustomerRepo extends JpaRepository<Customer, Long> {
	
	
	@Query("SELECT cus from Customer cus where CONCAT(cus.custId, ' ',cus.custName, ' ', cus.nric, ' ',cus.dob )Like %?1%")
	public Page<Customer> search(String keyword, Pageable pageable);
	
}
