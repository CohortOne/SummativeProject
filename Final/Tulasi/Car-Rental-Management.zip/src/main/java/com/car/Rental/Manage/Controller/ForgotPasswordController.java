package com.car.Rental.Manage.Controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import com.car.Rental.Manage.security.EmployeeNotFoundException;
import com.car.Rental.Manage.security.MyUserDetailService;

import net.bytebuddy.utility.RandomString;

@Controller
public class ForgotPasswordController {

	
	@Autowired
	private MyUserDetailService myuserdetailService;
	
	@GetMapping("/forgot_password")
	public String showForgotPasswordForm(Model model) {
		
	 model.addAttribute("pageTitle", "forgot_password")	;
	 return "forgot_password ";
	}
	
	@PostMapping("/forgot_password")

	public String processForgotPasswordForm(HttpServletRequest request ,
			Model model) {
		
		String email = request.getParameter("email");
		String token = RandomString.make(45);
		
		try {
			myuserdetailService.updateResetPasswordToken(token, email);
		//generate reset password link
		
		} catch (EmployeeNotFoundException ex) {
			model.addAttribute("error",ex.getMessage());
		}
		return "forgot_password";
	}
}
