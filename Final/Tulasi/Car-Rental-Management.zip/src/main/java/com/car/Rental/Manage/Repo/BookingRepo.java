package com.car.Rental.Manage.Repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.car.Rental.Manage.Model.Booking;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;


@Repository
public interface BookingRepo extends JpaRepository<Booking, Long> {

	//@Query("Select b from Booking b where CONCAT(b.bookId, ' ',b.startTime) LIKE %?1%")
	
	
	//@Query(value="select * from ( select bookings.booking_Id,customer.custname from bookings join Customer on bookings.custId = customer.custId)", nativeQuery = true) 
	
	
	@Query(value="select bookings.booking_Id,customer.custname,vehicle.veh_Brand \r\n"
			+ "from bookings \r\n"
			+ " join Customer on bookings.custId = customer.custid \r\n"
			+ " join vehicle on vehicle.VEHID = bookings.VEHID"
		    ,nativeQuery = true)
	public Page<Booking> search(String keyword, Pageable pageble);


	@Query(value="select bookings.* from bookings  \r\n"
			+ "where bookings.booking_id = :bookId \r\n"
			, nativeQuery = true)
	public Booking getBookingDetails(@Param("bookId") Long bookId);
}
