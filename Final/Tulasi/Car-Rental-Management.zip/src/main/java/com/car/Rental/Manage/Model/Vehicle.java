package com.car.Rental.Manage.Model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.Transient;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Entity
public class Vehicle {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)  
	@Column(name="VEHID")  
	private Long vehId;

	@Size (min = 1, max = 20)
	@NotNull
	private String vehType;

	@Size (min = 3, max = 15)
	@NotNull
	private String vehBrand;

	@Column(unique=true)
	@Size (min = 3, max = 8)
	@NotNull
	private String vehRegNo;
	
	
	@Min(value=10)
	@Max(value=30)
	@NotNull
	private float hourlyRate;
	
	@Min(value=100)
	@Max(value=300)
	@NotNull
	private float dailyRate;
	
	
	@Lob
    @Column(name = "Image", length = Integer.MAX_VALUE, nullable = true)
	private String picByte;
	
	
//    @ManyToOne(fetch = FetchType.EAGER, optional = true)
//    @JoinColumn(name = "bookId", nullable = true)
//    private Booking booking;

	

	public String getPicByte() {
		return picByte;
	}


	public void setPicByte(String picByte) {
		this.picByte = picByte;
	}


	@ManyToOne(fetch = FetchType.EAGER, optional = false)
    @JoinColumn(name = "VEHSTTSID", nullable = false)
    private VehStatus vehStatus;


	
    
	/**
	 * 
	 */
	public Vehicle() {
		super();
	}


	public Long getVehId() {
		return vehId;
	}


	public void setVehId(Long vehId) {
		this.vehId = vehId;
	}


	
	public String getVehType() {
		return vehType;
	}


	public void setVehType(String vehType) {
		this.vehType = vehType;
	}


	public float getHourlyRate() {
		return hourlyRate;
	}


	public void setHourlyRate(float hourlyRate) {
		this.hourlyRate = hourlyRate;
	}


	public String getVehBrand() {
		return vehBrand;
	}


	public void setVehBrand(String vehBrand) {
		this.vehBrand = vehBrand;
	}


	


	public String getVehRegNo() {
		return vehRegNo;
	}


	public void setVehRegNo(String vehRegNo) {
		this.vehRegNo = vehRegNo;
	}


	public float getDailyRate() {
		return dailyRate;
	}


	public void setDailyRate(float dailyRate) {
		this.dailyRate = dailyRate;
	}


	public VehStatus getVehStatus() {
		return vehStatus;
	}


	public void setVehStatus(VehStatus vehStatus) {
		this.vehStatus = vehStatus;
	}


	@Override
	public String toString() {
		return "Vehicle [vehId=" + vehId + ", vehType=" + vehType + ", vehBrand=" + vehBrand + ", vehRegNo=" + vehRegNo
				+ ", hourlyRate=" + hourlyRate + ", dailyRate=" + dailyRate + ", picByte=" + picByte + ", vehStatus="
				+ vehStatus + "]";
	}


	@Transient
	public String getPhotosImagePath() {
		if (picByte == null || vehId == null)
			return null;

		return "/vehicle-photos/" + vehId + "/" + picByte;
	}

	


}
