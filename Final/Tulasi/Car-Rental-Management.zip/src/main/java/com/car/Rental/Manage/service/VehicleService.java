package com.car.Rental.Manage.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;


import com.car.Rental.Manage.Model.Vehicle;
import com.car.Rental.Manage.Repo.VehicleRepo;

@Service
public class VehicleService {
	
	@Autowired
	private VehicleRepo vehRepo;
	
	public Vehicle getVehicleById(long vehId) {
		Optional <Vehicle> optional = vehRepo.findById(vehId);
		Vehicle vehicle = null;
		
		if(optional.isPresent())
			vehicle = optional.get();
		else
			throw new RuntimeException(" Vehicle not found for id :: " + vehId);
		
		return vehicle;		

	}

	

public Page<Vehicle> findPageinated2(int pageNo, int pageSize, String sortField, String sortDirection,String keyword) {
		Sort sort = sortDirection.equalsIgnoreCase(Sort.Direction.ASC.name()) ? Sort.by(sortField).ascending()
		               :Sort.by(sortField).descending();
				PageRequest pageble = PageRequest.of(pageNo - 1, pageSize, sort);
		
		if (keyword !=null) {
			
			return vehRepo.search(keyword,pageble);
		}
				return vehRepo.findAll(pageble);
	}



}
