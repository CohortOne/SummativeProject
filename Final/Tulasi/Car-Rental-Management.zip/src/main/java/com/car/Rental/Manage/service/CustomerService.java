package com.car.Rental.Manage.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;

import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.car.Rental.Manage.Model.Customer;
import com.car.Rental.Manage.Repo.CustomerRepo;


@Service
public class CustomerService {
	
	@Autowired
	private CustomerRepo custRepo;
	



	public Customer getCustomerById(long custId) {
		Optional <Customer> optional = custRepo.findById(custId);
		Customer customer = null;
		
		if(optional.isPresent())
			customer = optional.get();
		else
			throw new RuntimeException(" Customer not found for id :: " + custId);
		
		return customer;		

	}

	

public Page<Customer> findPageinated(int pageNo, int pageSize, String sortField, String sortDirection,String keyword) {
		Sort sort = sortDirection.equalsIgnoreCase(Sort.Direction.ASC.name()) ? Sort.by(sortField).ascending()
		               :Sort.by(sortField).descending();
				PageRequest pageble = PageRequest.of(pageNo - 1, pageSize, sort);
		
		if (keyword !=null) {
			
			return custRepo.search(keyword,pageble);
		}
				return custRepo.findAll(pageble);
	}




	
}
 

