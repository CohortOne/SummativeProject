package com.car.Rental.Manage.security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.car.Rental.Manage.Model.Employee;
import com.car.Rental.Manage.Repo.EmployeeRepo;




@Service
public class MyUserDetailService implements UserDetailsService {

	@Autowired
	private EmployeeRepo empRepo;
	
	@Override
	public UserDetails loadUserByUsername(String empName) throws UsernameNotFoundException {
		
		Employee employee = empRepo.findByEmpName(empName);
		if(employee==null)
			throw new UsernameNotFoundException(empName);
		
		return new UserDetailImpl(employee);
		}
	

	public void updateResetPasswordToken(String token, String email) throws EmployeeNotFoundException {
	Employee employee = empRepo.findByEmail(email);
	
	if (employee != null ) {
		
		employee.setResetPasswordToken(token);
	       empRepo.save(employee);
		
	}else {
		throw new EmployeeNotFoundException("Could nt find any Customer with email" + email);
		
	  }
	}
	public Employee get(String resetPasswordToken) {
	return empRepo.findByResetPasswordToken(resetPasswordToken);
		
	}
	
 public void updatePassword(Employee employee, String newPassword ) {
	 
	 BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
	 String encodedPassword = passwordEncoder.encode(newPassword);
	 
	 employee.setePassword(encodedPassword);
	 employee.setResetPasswordToken(null);
	 
	 empRepo.save(employee);
	 
 }
}
