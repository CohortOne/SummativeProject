package com.car.Rental.Manage.Repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.car.Rental.Manage.Model.Role;

public interface RoleRepo extends JpaRepository<Role, Integer> {

}
