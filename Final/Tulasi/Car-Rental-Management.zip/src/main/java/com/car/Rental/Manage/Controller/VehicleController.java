package com.car.Rental.Manage.Controller;

import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.view.RedirectView;


import com.car.Rental.Manage.Model.VehStatus;
import com.car.Rental.Manage.Model.Vehicle;

import com.car.Rental.Manage.Repo.VehicleRepo;
import com.car.Rental.Manage.Repo.VehicleStatusRepo;
import com.car.Rental.Manage.service.VehicleService;




@Controller
public class VehicleController {
	
	@Autowired
	private VehicleRepo vehRepo;
	
	@Autowired 
	private VehicleStatusRepo vehSttsRepo;
	
	@Autowired
	private VehicleService vehService;
	
	@RequestMapping("/vehicle")
	public String ShowVehList(Model model,@Param("keyword")String keyword) {
		//List<Vehicle> listVeh = vehRepo.findAll();		
		//model.addAttribute("listVeh", listVeh);
		
		return findPageinated2(1,  model, "vehId", "ASC",  keyword);
	}
	@GetMapping("/page2/{pageNo}")
	private String findPageinated2(@PathVariable(value = "pageNo")int pageNo, Model model, 
			@Param("sortField") String sortField, 
			@Param("sortDirection") String sortDirection,
			@Param("keyword") String keyword) {
		int pageSize = 5;
		Page<Vehicle> page = vehService.findPageinated2(pageNo, pageSize, sortField, sortDirection, keyword);
		List<Vehicle> listVeh= page.getContent();
		model.addAttribute("listVeh", listVeh);
		model.addAttribute("totalPages", page.getTotalPages());
		model.addAttribute("totalItems", page.getTotalElements());
		model.addAttribute("currentPage", pageNo);
		model.addAttribute("sortField", sortField);
		model.addAttribute("sortDirection", sortDirection);
		model.addAttribute("reverseSortDirection", sortDirection.equalsIgnoreCase("ASC") ? "DESC" : "ASC");
		model.addAttribute("keyword", keyword);
		
		return "vehicle";
	}


	
	
	@GetMapping("/newVehicleReg")
	public String newVehicleReg(Model model) {
		List<VehStatus> vehStatus =  vehSttsRepo.findAll();
	
		model.addAttribute("vehStatus",vehStatus);
		
		model.addAttribute("Vehicle" , new Vehicle());		
		return "newVehicleReg";
	}

	@PostMapping("/vehicle/save")
	public RedirectView saveVehicle(Vehicle vehicle, @RequestParam("image") MultipartFile multipartFile) throws IOException {
		String fileName = StringUtils.cleanPath(multipartFile.getOriginalFilename());
		
		vehicle.setPicByte(fileName);
       
        Vehicle savedPic = vehRepo.save(vehicle);

        String uploadDir = "vehicle-photos/" + savedPic.getVehId();
 
        FileUploadUtil.saveFile(uploadDir, fileName, multipartFile);
        
        return new RedirectView("/vehicle", true);
	}
//	@PostMapping("/vehicle/save")
//	public String  saveVehicle(Vehicle vehicle)
//			{ 
//		vehRepo.save(vehicle);
//		return "redirect:/vehicle";
//	}
//	@RequestMapping(value="/vehicle/uploadPhoto", method=RequestMethod.POST)
//	public ResponseEntity<Object> uploadFile(@RequestParam("file") MultipartFile file) throws IOException {
//		File newFile = new File("C:\\SUMMATIVE CAPSTONE PROJECT-9thFeb-17thMar\\Car-Rental-Management\\src\\main\\resources\\static\\images\\portfolio" + file.getOriginalFilename());
//		newFile.createNewFile();
//		FileOutputStream fout = new FileOutputStream(newFile);
//		fout.write(file.getBytes());
//		fout.close();
//		return new ResponseEntity<>("File uploaded successfully", HttpStatus.OK);
//	}	
//	
//	
//	@PostMapping("/vehicle/uploadPhoto2")
//	public String uploadFile2(@RequestParam("file") MultipartFile file, Principal principal) 
//			throws IllegalStateException, IOException {
//			String baseDirectory = "C:\\SUMMATIVE CAPSTONE PROJECT-9thFeb-17thMar\\Car-Rental-Management\\src\\main\\resources\\static\\images\\portfolio";
//			file.transferTo(new File(baseDirectory + principal.getName() + ".jpg"));
//			return "redirect:/vehicle";
//	}
//	
	
	@GetMapping("/UpdateVehicle/{vehId}")
	public String ShowEditForm(@PathVariable("vehId") Long vehId, Model model) {
		Vehicle vehicle =   vehRepo.findById(vehId).get();
		model.addAttribute("Vehicle", vehicle);
		
		List<VehStatus> vehStatus =  vehSttsRepo.findAll();
		model.addAttribute("vehStatus",vehStatus);
		
		return "UpdateVehicle";
	}
	
	@GetMapping("/deleteRecord/{vehId}")
	public String deleteVehicle(@PathVariable(value = "vehId") long vehId,
			Model model){
		vehRepo.deleteById(vehId);
		
		return "redirect:/vehicle";
		
	}
	
	}


