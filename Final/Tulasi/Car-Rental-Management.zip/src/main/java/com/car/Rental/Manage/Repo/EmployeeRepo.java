package com.car.Rental.Manage.Repo;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;


import com.car.Rental.Manage.Model.Employee;



@Repository
public interface EmployeeRepo extends JpaRepository<Employee, Long> {
	Employee findByEmpName(String empName);

	public Employee findByEmail(String email);

	public Employee findByResetPasswordToken(String token);
	
	@Query("SELECT e from Employee e where CONCAT(e.empId, ' ',e.empName, ' ', e.ePhoneNo, ' ' , e.email )Like %?1%")
	public Page<Employee> search(String keyword, Pageable pageable);
}
