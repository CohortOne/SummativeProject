package com.car.Rental.Manage.Controller;

import java.io.*;
import java.nio.file.*;

import javax.servlet.ServletContext;

import org.springframework.http.MediaType;
import org.springframework.web.multipart.MultipartFile;

public class FileUploadUtil {
	 public static void saveFile(String uploadDir, String fileName,
	            MultipartFile multipartFile) throws IOException {
	        Path uploadPath = Paths.get(uploadDir);
	         
	        if (!Files.exists(uploadPath)) {
	            Files.createDirectories(uploadPath);
	        }
	         
	        try (InputStream inputStream = multipartFile.getInputStream()) {
	            Path filePath = uploadPath.resolve(fileName);
	            Files.copy(inputStream, filePath, StandardCopyOption.REPLACE_EXISTING);
	        } catch (IOException ioe) {        
	            throw new IOException("Could not save image file: " + fileName, ioe);
	        }      
	    }
	 public static MediaType getMediaTypeForFileName(ServletContext servletContext, String filename) {
	     
	        String mineType = servletContext.getMimeType(filename);
	        try {
	            MediaType mediaType = MediaType.parseMediaType(mineType);
	            return mediaType;
	        } catch (Exception e) {
	            return MediaType.APPLICATION_OCTET_STREAM;
	        }

	}
	}


