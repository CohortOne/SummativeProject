package com.car.Rental.Manage.Controller;

import java.util.List;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;


import com.car.Rental.Manage.Model.Employee;
import com.car.Rental.Manage.Model.Role;
import com.car.Rental.Manage.Repo.EmployeeRepo;
import com.car.Rental.Manage.Repo.RoleRepo;
import com.car.Rental.Manage.service.EmployeeService;


@Controller
public class EmployeeController {

	@Autowired
	 private EmployeeRepo empRepo;
	
	@Autowired
	private RoleRepo rolerepo;
	
	
	
	@Autowired
	private EmployeeService empService;
	
	
	
	@GetMapping("/Main")
	public String viewHomePage() {
		return "Main";
	}
	
	@RequestMapping("/employee")
	public String ShowEmpList(Model model,@Param("keyword")String keyword,HttpSession session) {
		//List<Employee> listEmp = empRepo.findAll(); 
		//model.addAttribute("listEmp", listEmp);
		//return "employee";
		return findPageinated1(1,  model, "empId", "ASC",  keyword);

}
	@GetMapping("/page1/{pageNo}")
	public String findPageinated1(@PathVariable(value = "pageNo") int pageNo,
			                                     Model model, 
											@Param("sortField") String sortField, 
											@Param("sortDirection") String sortDirection, 
											@Param("keyword") String keyword) {
									
		
		int pageSize = 5;
		Page<Employee> page = empService.findPageinated1(pageNo, pageSize, sortField, sortDirection, keyword);
		List <Employee> listEmp = page.getContent();
		model.addAttribute("listEmp", listEmp);
		model.addAttribute("totalPages", page.getTotalPages());
		model.addAttribute("totalItems", page.getTotalElements());
		model.addAttribute("currentPage", pageNo);
		model.addAttribute("sortField", sortField);
		model.addAttribute("sortDirection", sortDirection);
		model.addAttribute("reverseSortDirection", sortDirection.equalsIgnoreCase("ASC") ? "DESC" : "ASC");
		model.addAttribute("keyword", keyword);
		return "employee";
	}

	@GetMapping("/newEmployeeReg")
	public String newEmployeeReg(Model model) {
		List<Role> roles = rolerepo.findAll();
		model.addAttribute("roles",roles);
		model.addAttribute("Employee" , new Employee());
		
		return "newEmployeeReg";
	}
	@PostMapping("/employee/save")
	public String saveEmployee(@Valid @ModelAttribute("Employee")Employee employee, BindingResult bindingResult) {
		if(bindingResult.hasErrors()) {
			//System.out.println(bindingResult.getAllErrors());
		return "newEmployeeReg";
		}
		empRepo.save(employee);
		return "redirect:/employee";
	}
	
	@GetMapping("/UpdateEmp/{empId}")
	public String ShowEditForm(@PathVariable("empId") Long empId, Model model) {
		Employee employee =   empRepo.findById(empId).get();
		model.addAttribute("Employee", employee);
		
		List<Role> roles = rolerepo.findAll();
		model.addAttribute("roles", roles);
		
		return "UpdateEmp";
	}
	
	@GetMapping("/delete/{empId}")
	public String deleteUser(@PathVariable("empId") Long empId, Model model) {
		empRepo.deleteById(empId);;
		
		return "redirect:/employee";
		
	}
	
	@RequestMapping("/login")
	public String login() {
			return "login";
	}

	@RequestMapping("/logout-success")
	public String logout() {
			return "logout";

	}
	
	@GetMapping("/Sign Up")
	String signUp() {

		return "Sign Up";
	}

}
