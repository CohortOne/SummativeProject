package com.car.Rental.Manage.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.car.Rental.Manage.Model.Booking;
import com.car.Rental.Manage.Repo.BookingRepo;


@Service
public class BookingService {
	
	@Autowired
	private BookingRepo bookRepo;
	

	

public Page<Booking> findPageinated3(int pageNo, int pageSize, String sortField, String sortDirection,String keyword) {
		Sort sort = sortDirection.equalsIgnoreCase(Sort.Direction.ASC.name()) ? Sort.by(sortField).ascending()
		               :Sort.by(sortField).descending();
				PageRequest pageble = PageRequest.of(pageNo - 1, pageSize, sort);
		
		if (keyword !=null) {
			
			return bookRepo.search(keyword,pageble);
		}
				return bookRepo.findAll(pageble);
	}

public Booking getBookingDetails(Long bookId) {
	Booking book =new Booking();
	
	if (bookId !=null) {
		
		return bookRepo.getBookingDetails(bookId);
	}
	else {
		return book;
	}
	

}

      
    
}