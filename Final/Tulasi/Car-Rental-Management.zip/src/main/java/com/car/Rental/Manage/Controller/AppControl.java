package com.car.Rental.Manage.Controller;



import java.util.Map;
import java.util.TreeMap;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.car.Rental.Manage.Repo.BookingRepo;
import com.car.Rental.Manage.Repo.CustomerRepo;
import com.car.Rental.Manage.Repo.EmployeeRepo;
import com.car.Rental.Manage.Repo.VehicleRepo;




@Controller
public class AppControl {
	
	
	@Autowired
	private CustomerRepo custRepo;
	
	@Autowired
	private VehicleRepo vehRepo;
	
	@Autowired
	private EmployeeRepo empRepo;

	@Autowired
	private BookingRepo bookRepo;
	
	@RequestMapping("/contact")
	public String contact() {
			return "contact";
	}
	
	
	@RequestMapping("/index")
	public String Home() {
			return "index";
	}
	
	@RequestMapping("/about-us")
	public String Aboutus() {
			return "about-us";
	}

	@RequestMapping("/fleet")
	public String Fleet() {
			return "fleet";
	}
	@RequestMapping("/downloads/{bookId}.pdf")
	public String pdf() {
			return "InvoicePdf";
	}
	

	@RequestMapping("/Dashboard")
	public String Dashboard(Model model,HttpSession session) {
		  Map<String, Integer> graphData = new TreeMap<>();
		model.addAttribute("countcustomers", custRepo.count());	
		model.addAttribute("countEmployees", empRepo.count());	
		model.addAttribute("countVehicles", vehRepo.count());
		model.addAttribute("countBookings", bookRepo.count());
		System.out.println(custRepo.count());
		graphData.put("Customers",(int) custRepo.count());		
		graphData.put("Vehicles", (int) vehRepo.count());
		graphData.put("Bookings", (int) bookRepo.count());
		 model.addAttribute("chartData", graphData);
			return "Dashboard";
	}

	
}
