package com.car.Rental.Manage.Repo;

import org.springframework.data.domain.Page;

import org.springframework.data.domain.Pageable;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;


import com.car.Rental.Manage.Model.Vehicle;


@Repository
public interface VehicleRepo extends JpaRepository<Vehicle, Long > {
	
	
	@Query("SELECT v from Vehicle v where CONCAT(v.vehId, ' ',v.vehType, ' ', v.vehBrand, ' ',v.vehRegNo )Like %?1%")
	public Page<Vehicle> search (String keyword, Pageable pageable);

   

}
