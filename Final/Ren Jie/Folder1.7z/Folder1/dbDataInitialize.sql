-- Data Initialization for DB

--An Easy Way to Drop All Tables in Your Tablespace in Oracle
--select 'drop table ', table_name, 'cascade constraints;' from user_tables;
--Then copy the output and run that as a sql script.

--drop table 	CAR	cascade constraints;
--drop table 	CUSTOMER	cascade constraints;
--drop table 	HIRE_DETAIL	cascade constraints;
--drop table 	INVOICE	cascade constraints;
--drop table 	USERS	cascade constraints;
--drop table 	USERS_ROLES	cascade constraints;
--drop table 	ROLES	cascade constraints;

-- Role table
delete from roles;

insert into roles (role_name) values ('employee');
insert into roles (role_name) values ('manager');
insert into roles (role_name) values ('admin');

-- User table


-- Customer table
delete from customer;

INSERT INTO Customer (ADDRESS,DOB,EMAIL,FULL_NAME,NRIC,PHONE_NO,STATUS) VALUES ('351-4980 Phasellus Rd.','12-Apr-2022','cursus.diam.at@amifringilla.co.uk','Bernard','S7838742U','90431555','0');
INSERT INTO Customer (ADDRESS,DOB,EMAIL,FULL_NAME,NRIC,PHONE_NO,STATUS) VALUES ('Ap #115-9429 Sollicitudin Av.','16-Dec-2021','felis@pedeultrices.org','Rigel','S6194888A','96782611','0');
INSERT INTO Customer (ADDRESS,DOB,EMAIL,FULL_NAME,NRIC,PHONE_NO,STATUS) VALUES ('4703 Auctor Road','04-Dec-2020','tincidunt.nibh@mi.net','Carol','S0695630X','82963092','0');
INSERT INTO Customer (ADDRESS,DOB,EMAIL,FULL_NAME,NRIC,PHONE_NO,STATUS) VALUES ('9898 Tristique St.','13-Feb-2022','felis@egestasSedpharetra.org','Kadeem','S0126701C','85311622','0');
INSERT INTO Customer (ADDRESS,DOB,EMAIL,FULL_NAME,NRIC,PHONE_NO,STATUS) VALUES ('3627 Elit, Rd.','22-Jan-2022','in.magna@necimperdiet.org','Hashim','S2569134I','93431689','0');
INSERT INTO Customer (ADDRESS,DOB,EMAIL,FULL_NAME,NRIC,PHONE_NO,STATUS) VALUES ('2232 Parturient Rd.','05-Jan-2021','a.enim@vitae.net','Neve','S9026790G','88138023','0');
INSERT INTO Customer (ADDRESS,DOB,EMAIL,FULL_NAME,NRIC,PHONE_NO,STATUS) VALUES ('P.O. Box 915, 1897 Morbi Av.','04-Aug-2020','diam.Sed.diam@vestibulum.org','Wylie','S1657775F','87410060','0');
INSERT INTO Customer (ADDRESS,DOB,EMAIL,FULL_NAME,NRIC,PHONE_NO,STATUS) VALUES ('789-4276 Sodales Av.','30-Mar-2022','Praesent.eu.nulla@Seddiamlorem.edu','Risgel','S0282864R','97089030','0');
INSERT INTO Customer (ADDRESS,DOB,EMAIL,FULL_NAME,NRIC,PHONE_NO,STATUS) VALUES ('181-1554 Eros Avenue','14-Sep-2021','eros.Nam@senectusetnetus.org','Simon','S8635279B','98098049','0');
INSERT INTO Customer (ADDRESS,DOB,EMAIL,FULL_NAME,NRIC,PHONE_NO,STATUS) VALUES ('P.O. Box 912, 5088 At, St.','20-Dec-2020','egestas.rhoncus.Proin@ametmassaQuisque.org','Oprah','S5919582U','93653235','0');
INSERT INTO Customer (ADDRESS,DOB,EMAIL,FULL_NAME,NRIC,PHONE_NO,STATUS) VALUES ('4482 Imperdiet Road','12-Jan-2021','quis@Namporttitor.edu','Reece','S0860780P','83428294','0');
INSERT INTO Customer (ADDRESS,DOB,EMAIL,FULL_NAME,NRIC,PHONE_NO,STATUS) VALUES ('Ap #832-3086 Adipiscing Rd.','27-May-2021','nunc@vel.org','Xerxes','S9208046D','86521925','0');
INSERT INTO Customer (ADDRESS,DOB,EMAIL,FULL_NAME,NRIC,PHONE_NO,STATUS) VALUES ('Ap #882-2207 Urna. St.','01-Mar-2021','diam.Pellentesque@tempus.co.uk','Sean','S5594329U','97934237','0');
INSERT INTO Customer (ADDRESS,DOB,EMAIL,FULL_NAME,NRIC,PHONE_NO,STATUS) VALUES ('Ap #486-5442 Primis St.','04-Oct-2021','magna.Praesent.interdum@necurnasuscipit.ca','Zeus','S9158659H','99587418','0');
INSERT INTO Customer (ADDRESS,DOB,EMAIL,FULL_NAME,NRIC,PHONE_NO,STATUS) VALUES ('8157 Proin St.','01-Dec-2021','mollis.Phasellus.libero@egetodioAliquam.net','Driscoll','S8154808M','86868379','0');

-- Car table
delete from Car;

INSERT INTO Car (BRAND,ENABLED,HIRE_RATE,MODEL,REG_NO, STATUS) VALUES ('Semper Tellus Id PC','1','2.51','lorem ac','VDR1891A','0');
INSERT INTO Car (BRAND,ENABLED,HIRE_RATE,MODEL,REG_NO, STATUS) VALUES ('Vestibulum Ante Limited','1','4.23','Aenean eget','YRS1161C','0');
INSERT INTO Car (BRAND,ENABLED,HIRE_RATE,MODEL,REG_NO, STATUS) VALUES ('Sed Pharetra Felis PC','1','1.35','pharetra. Quisque','TXM5132Q','0');
INSERT INTO Car (BRAND,ENABLED,HIRE_RATE,MODEL,REG_NO, STATUS) VALUES ('Hendrerit Id Company','1','5.67','adipiscing elit.','HHA9155Z','0');
INSERT INTO Car (BRAND,ENABLED,HIRE_RATE,MODEL,REG_NO, STATUS) VALUES ('Porttitor Ltd','1','7.90','euismod et,','PVX7628N','0');
INSERT INTO Car (BRAND,ENABLED,HIRE_RATE,MODEL,REG_NO, STATUS) VALUES ('Luctus Inc.','1','6.57','eleifend vitae,','YSZ3209X','0');
INSERT INTO Car (BRAND,ENABLED,HIRE_RATE,MODEL,REG_NO, STATUS) VALUES ('Vel Consulting','1','3.40','risus. Nunc','KII9306G','0');
INSERT INTO Car (BRAND,ENABLED,HIRE_RATE,MODEL,REG_NO, STATUS) VALUES ('Arcu Nunc Ltd','1','6.79','Integer sem','TUE6839S','0');
INSERT INTO Car (BRAND,ENABLED,HIRE_RATE,MODEL,REG_NO, STATUS) VALUES ('Sem Mollis Dui Institute','1','8.78','Curabitur massa.','GZI6730C','0');
INSERT INTO Car (BRAND,ENABLED,HIRE_RATE,MODEL,REG_NO, STATUS) VALUES ('Mauris Morbi LLP','1','0.24','Cras dictum','AXZ0036R','0');
INSERT INTO Car (BRAND,ENABLED,HIRE_RATE,MODEL,REG_NO, STATUS) VALUES ('Eget Volutpat Company','1','6.64','dignissim tempor','YPQ0237G','0');
INSERT INTO Car (BRAND,ENABLED,HIRE_RATE,MODEL,REG_NO, STATUS) VALUES ('Facilisis Vitae Corporation','1','8.48','nec metus','EKE8434G','0');
INSERT INTO Car (BRAND,ENABLED,HIRE_RATE,MODEL,REG_NO, STATUS) VALUES ('Enim Consulting','1','5.02','cursus in,','VYJ2127E','0');
INSERT INTO Car (BRAND,ENABLED,HIRE_RATE,MODEL,REG_NO, STATUS) VALUES ('Penatibus Et Limited','1','4.49','Phasellus ornare.','MTJ7100S','0');
INSERT INTO Car (BRAND,ENABLED,HIRE_RATE,MODEL,REG_NO, STATUS) VALUES ('Cum Consulting','1','1.15','arcu. Sed','RSN1430O','0');
