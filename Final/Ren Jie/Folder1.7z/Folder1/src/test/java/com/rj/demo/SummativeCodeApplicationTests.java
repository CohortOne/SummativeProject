package com.rj.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SummativeCodeApplicationTests {

	@Test
	void contextLoads() {
	}

}
