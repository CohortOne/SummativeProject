package com.rj.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.rj.models.Customer;
import com.rj.repositories.CustomerRepository;


@Service
public class CustomerService {
	@Autowired
    private CustomerRepository customerRepository;
     
    public List<Customer> listAll() {
        return customerRepository.findAll();
    }
    
    public List<Customer> listRented(){
    	return customerRepository.findRented();
    }
     
    public void save(Customer customer) {
    	customerRepository.save(customer);
    }
     
    public Customer get(int id) {
        return customerRepository.findById(id).get();
    }
     
    public void delete(int id) {
    	customerRepository.deleteById(id);
    }
    
    public Customer update(int id) {
		Optional<Customer> optional = customerRepository.findById(id);
		Customer customer = null;
		
		if(optional.isPresent())
			customer = optional.get();
		else
			throw new RuntimeException(" Customer not found for id :: " + customer);
		
		return customer;
	}
    public Customer findById(int id) {
    	Optional<Customer> optional = customerRepository.findById(id);
		Customer customer = null;
		
		if(optional.isPresent())
			customer = optional.get();
		else
			throw new RuntimeException(" Customer not found for id :: " + customer);
		
    	return customer;
    }
    
}
