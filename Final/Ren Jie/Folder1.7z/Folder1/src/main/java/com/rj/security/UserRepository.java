package com.rj.security;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;


@Repository
public interface UserRepository extends JpaRepository<User, Integer>{
	@Query("SELECT u FROM User u WHERE u.username = :username")
    public User getUserByUsername(@Param("username") String username);
	
	List<User> findByEmail(String email);
	List<User> findByUsername(String username);
	List<User> findByPhoneNo(String phoneNo);
	
	@Query("SELECT c FROM User c WHERE c.email = ?1")
	public User findByEmail2(String email);

	public User findByResetPasswordToken(String token);
}
