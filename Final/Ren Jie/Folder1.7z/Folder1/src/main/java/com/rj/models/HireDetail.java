package com.rj.models;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.validation.constraints.NotNull;

import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.rj.security.User;

@Entity
public class HireDetail {
	@Id
    @Column(name = "hireDetailId")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
	
	@NotNull
    @Column(name = "dateRented")
    @DateTimeFormat(pattern = "yyyy-MM-dd")
	private LocalDate dateRented;
	
	
    @Column(name = "dateReceived")
    @DateTimeFormat(pattern = "yyyy-MM-dd")
	private LocalDate dateReceived;
    
    @NotNull
    @ManyToOne
    @JoinColumn(name = "carId")
    @JsonBackReference
    private Car car;
    
    @NotNull
    @ManyToOne
    @JoinColumn(name = "custId")
    @JsonBackReference
    private Customer customer;
    
    @NotNull
    @ManyToOne
    @JoinColumn(name = "userRentId")
    @JsonBackReference
    private User userRent;
    
    
    @ManyToOne
    @JoinColumn(name = "userReceiveId")
    @JsonBackReference
    private User userReceive;
    
    
    @ManyToOne
    @JoinColumn(name = "invoiceId")
    @JsonBackReference
    private Invoice invoice;


	public HireDetail(Integer id, @NotNull LocalDate dateRented, LocalDate dateReceived, @NotNull Car car,
			@NotNull Customer customer, @NotNull User userRent, User userReceive, Invoice invoice) {
		super();
		this.id = id;
		this.dateRented = dateRented;
		this.dateReceived = dateReceived;
		this.car = car;
		this.customer = customer;
		this.userRent = userRent;
		this.userReceive = userReceive;
		this.invoice = invoice;
	}


	public HireDetail() {
		super();
	}


	@Override
	public String toString() {
			if (this.userReceive != null && this.invoice != null && this.car!=null && this.userRent != null && this.customer != null) {
				return "HireDetail [id=" + id + ", dateRented=" + dateRented + ", dateReceived=" + dateReceived + ", car=" + car.getRegNo()
				+ ", customer=" + customer.getFullName() + ", userRent=" + userRent.getFullName() + ", userReceive=" + userReceive.getFullName() + ", invoice="
				+ invoice.getTotalCost() + "]";
			}else {
				return "HireDetail [id=" + id + ", dateRented=" + dateRented + ", dateReceived=" + dateReceived + ", car=" + car
				+ ", customer=" + customer+ ", userRent=" + userRent + ", userReceive=" + userReceive + ", invoice="
				+ invoice + "]";
			}
			
	}


	public Integer getId() { 
		return id;
	}


	public void setId(Integer id) {
		this.id = id;
	}


	public LocalDate getDateRented() {
		return dateRented;
	}


	public void setDateRented(LocalDate dateRented) {
		this.dateRented = dateRented;
	}


	public LocalDate getDateReceived() {
		return dateReceived;
	}


	public void setDateReceived(LocalDate dateReceived) {
		this.dateReceived = dateReceived;
	}


	public Car getCar() {
		return car;
	}


	public void setCar(Car car) {
		this.car = car;
	}


	public Customer getCustomer() {
		return customer;
	}


	public void setCustomer(Customer customer) {
		this.customer = customer;
	}


	public User getUserRent() {
		return userRent;
	}


	public void setUserRent(User userRent) {
		this.userRent = userRent;
	}


	public User getUserReceive() {
		return userReceive;
	}


	public void setUserReceive(User userReceive) {
		this.userReceive = userReceive;
	}


	public Invoice getInvoice() {
		return invoice;
	}


	public void setInvoice(Invoice invoice) {
		this.invoice = invoice;
	}


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((car == null) ? 0 : car.hashCode());
		result = prime * result + ((customer == null) ? 0 : customer.hashCode());
		result = prime * result + ((dateReceived == null) ? 0 : dateReceived.hashCode());
		result = prime * result + ((dateRented == null) ? 0 : dateRented.hashCode());
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + ((invoice == null) ? 0 : invoice.hashCode());
		result = prime * result + ((userReceive == null) ? 0 : userReceive.hashCode());
		result = prime * result + ((userRent == null) ? 0 : userRent.hashCode());
		return result;
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		HireDetail other = (HireDetail) obj;
		if (car == null) {
			if (other.car != null)
				return false;
		} else if (!car.equals(other.car))
			return false;
		if (customer == null) {
			if (other.customer != null)
				return false;
		} else if (!customer.equals(other.customer))
			return false;
		if (dateReceived == null) {
			if (other.dateReceived != null)
				return false;
		} else if (!dateReceived.equals(other.dateReceived))
			return false;
		if (dateRented == null) {
			if (other.dateRented != null)
				return false;
		} else if (!dateRented.equals(other.dateRented))
			return false;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		if (invoice == null) {
			if (other.invoice != null)
				return false;
		} else if (!invoice.equals(other.invoice))
			return false;
		if (userReceive == null) {
			if (other.userReceive != null)
				return false;
		} else if (!userReceive.equals(other.userReceive))
			return false;
		if (userRent == null) {
			if (other.userRent != null)
				return false;
		} else if (!userRent.equals(other.userRent))
			return false;
		return true;
	}
    
    
    
}
