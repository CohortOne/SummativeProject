package com.rj.controllers;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.rj.models.Customer;
import com.rj.models.HireDetail;
import com.rj.models.Invoice;
import com.rj.services.InvoiceService;

@Controller
public class InvoiceController {

	@Autowired
	private InvoiceService invoiceService;

	@GetMapping("/invoiceList")
	public String invoiceList(Model model) {
		List<Invoice> listInvoices = invoiceService.listAll();
		model.addAttribute("listInvoices", listInvoices);

		return "invoiceList";
	}

	@GetMapping("/createInvoice")
	public String createInvoice(Model model) {
		Invoice invoice = new Invoice();
		model.addAttribute("invoice", invoice);
		return "createInvoice";
	}

	@PostMapping("/saveInvoice")
	public String saveInvoice(@Valid @ModelAttribute("invoice") Invoice invoice, BindingResult bindingResult,
			String viewType, Model model) {
		
//		if (customer.getEmail() == "") {
//			bindingResult.rejectValue("email", "error.user", "must not be null");	
//		}
//		
//		if (customer.getFullName() == "") {
//			bindingResult.rejectValue("fullName", "error.user", "must not be null");	
//		}
//		
//		if (customer.getAddress() == "") {
//			bindingResult.rejectValue("address", "error.user", "must not be null");	
//		}
		
		// error checking
		bindingResult.getFieldErrors().stream()
				.forEach(f -> System.out.println(f.getField() + ": " + f.getDefaultMessage()));

		if (bindingResult.hasErrors() && viewType.equals("createInvoice")) {
			return "createInvoice";
		} else if (bindingResult.hasErrors() && viewType.equals("updateInvoice")) {
			return "updateInvoice";
		}
		invoiceService.save(invoice);

		return "redirect:/invoiceList";
	}
	
	@GetMapping("/updateInvoice/{invoiceId}")
	public String updateInvoice(@PathVariable (value = "invoiceId") int invoiceId, Model model) {
	 
	Invoice invoice = invoiceService.update(invoiceId); 
	model.addAttribute("invoice", invoice);
	
	
	return "updateInvoice";
	}
	
	@GetMapping("/deleteInvoice/{invoiceId}")
	public String deleteInvoice(@PathVariable (value = "invoiceId") int invoiceId) {
	 
	 // call delete employee method 
	 invoiceService.delete(invoiceId);
	 return "redirect:/invoiceList";
	}
	
	@GetMapping("/payInvoice/{invoiceId}")
	public String payInvoice(@PathVariable (value = "invoiceId") int invoiceId, Model model) {
		Invoice invoice = invoiceService.update(invoiceId);
		model.addAttribute("invoice", invoice);
		List<HireDetail> listHireDetails =  invoice.getHireDetails();
		model.addAttribute("listHireDetails", listHireDetails);
//		
//		invoice.setPaidStatus(true);
		return "payInvoice";
	}
	
	@PostMapping("/payInvoice")
	public String payInvoicePost(Model model, @ModelAttribute("invoice") Invoice invoice) {
		Invoice invoiceHolder = invoiceService.update(invoice.getId());
		invoiceHolder.setPaidStatus(true);
		System.out.println(invoiceHolder + "noot");
		invoiceService.save(invoiceHolder);
		return "redirect:/invoiceList";
	}
	
}
