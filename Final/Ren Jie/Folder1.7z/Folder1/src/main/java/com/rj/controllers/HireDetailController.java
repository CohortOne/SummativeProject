package com.rj.controllers;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.rj.models.Customer;
import com.rj.models.HireDetail;
import com.rj.services.HireDetailService;

@Controller
public class HireDetailController {

	@Autowired
	private HireDetailService hireDetailService;

	@GetMapping("/hireDetailList")
	public String hireDetailList(Model model) {
		List<HireDetail> listHireDetails = hireDetailService.listAll();
		model.addAttribute("listHireDetails", listHireDetails);

		return "hireDetailList";
	}

	@GetMapping("/createHireDetail")
	public String createHireDetail(Model model) {
		HireDetail hiredetail = new HireDetail();
		model.addAttribute("hiredetail", hiredetail);
		return "createHireDetail";
	}

	@PostMapping("/saveHireDetail")
	public String saveHireDetail(@Valid @ModelAttribute("hiredetail") HireDetail hiredetail, BindingResult bindingResult,
			String viewType, Model model) {
		
//		if (customer.getEmail() == "") {
//			bindingResult.rejectValue("email", "error.user", "must not be null");	
//		}
//		
//		if (customer.getFullName() == "") {
//			bindingResult.rejectValue("fullName", "error.user", "must not be null");	
//		}
//		
//		if (customer.getAddress() == "") {
//			bindingResult.rejectValue("address", "error.user", "must not be null");	
//		}
		
		// error checking
		bindingResult.getFieldErrors().stream()
				.forEach(f -> System.out.println(f.getField() + ": " + f.getDefaultMessage()));

		if (bindingResult.hasErrors() && viewType.equals("createHireDetail")) {
			return "createHireDetail";
		} else if (bindingResult.hasErrors() && viewType.equals("updateHireDetail")) {
			return "updateHireDetail";
		}
		hireDetailService.save(hiredetail);

		return "redirect:/hireDetailList";
	}
	
	@GetMapping("/updateHireDetail/{hireDetailId}")
	public String updateCustomer(@PathVariable (value = "hireDetailId") int hireDetailId, Model model) {
	 
	HireDetail hiredetail = hireDetailService.update(hireDetailId); 
	model.addAttribute("hiredetail", hiredetail);
	
	
	return "updateHireDetail";
	}
	
	@GetMapping("/deleteHireDetail/{hireDetailId}")
	public String deleteHireDetail(@PathVariable (value = "hireDetailId") int hireDetailId) {
	 
	 // call delete employee method 
	 hireDetailService.delete(hireDetailId);
	 return "redirect:/hireDetailList";
	}
	
	
}
