package com.rj.models;

import java.math.BigDecimal;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.validation.constraints.DecimalMax;
import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonManagedReference;

@Entity
public class Car {
	@Id
    @Column(name = "carId")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
	
	@NotBlank
	@Column(name="regNo")
	@Pattern(regexp= "[A-z]{3}\\d{4}[A-z]{1}", message="must start with 3 letters, followed by 4 digits and another letter")
	private String regNo;
	
	@NotBlank
	@Size(max=50)
	@Column(name="brand")
	private String brand;
	
	@NotBlank
	@Size(max=50)
	@Column(name="model")
	private String model;
	
	@NotNull
	@DecimalMin(value = "0.0", inclusive = false)
	@DecimalMax(value = "999999.0", inclusive = true)
	@Column(name = "hireRate", precision = 8, scale = 2)
	private BigDecimal hireRate;
	
	@Column(name="status")
	private boolean status;
	
	@NotNull
	@Column(name="enabled")
	private boolean enabled;

	


	public Car(Integer id,
			@NotBlank @Pattern(regexp = "[A-z]{3}\\d{4}[A-z]{1}", message = "must start with 3 letters, followed by 4 digits and another letter") String regNo,
			@NotBlank @Size(max = 50) String brand, @NotBlank @Size(max = 50) String model,
			@NotNull @DecimalMin(value = "0.0", inclusive = false) @DecimalMax(value = "999999.0", inclusive = true) BigDecimal hireRate,
			boolean status, @NotNull boolean enabled, List<HireDetail> hireDetails) {
		super();
		this.id = id;
		this.regNo = regNo;
		this.brand = brand;
		this.model = model;
		this.hireRate = hireRate;
		this.status = status;
		this.enabled = enabled;
		this.hireDetails = hireDetails;
	}

	public Car() {
		super();
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getRegNo() {
		return regNo;
	}

	public void setRegNo(String regNo) {
		this.regNo = regNo;
	}

	public String getBrand() {
		return brand;
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public BigDecimal getHireRate() {
		return hireRate;
	}

	public void setHireRate(BigDecimal hireRate) {
		this.hireRate = hireRate;
	}

	public boolean isStatus() {
		return status;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}

	public boolean isEnabled() {
		return enabled;
	}

	public void setEnabled(boolean enabled) {
		this.enabled = enabled;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((brand == null) ? 0 : brand.hashCode());
		result = prime * result + (enabled ? 1231 : 1237);
		result = prime * result + ((hireRate == null) ? 0 : hireRate.hashCode());
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + ((model == null) ? 0 : model.hashCode());
		result = prime * result + ((regNo == null) ? 0 : regNo.hashCode());
		result = prime * result + (status ? 1231 : 1237);
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Car other = (Car) obj;
		if (brand == null) {
			if (other.brand != null)
				return false;
		} else if (!brand.equals(other.brand))
			return false;
		if (enabled != other.enabled)
			return false;
		if (hireRate == null) {
			if (other.hireRate != null)
				return false;
		} else if (!hireRate.equals(other.hireRate))
			return false;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		if (model == null) {
			if (other.model != null)
				return false;
		} else if (!model.equals(other.model))
			return false;
		if (regNo == null) {
			if (other.regNo != null)
				return false;
		} else if (!regNo.equals(other.regNo))
			return false;
		if (status != other.status)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Car [id=" + id + ", regNo=" + regNo + ", brand=" + brand + ", model=" + model + ", hireRate=" + hireRate
				+ ", status=" + status + ", enabled=" + enabled + "]";
	}
	
	
	@OneToMany(mappedBy="car")
	@JsonManagedReference
	private List<HireDetail> hireDetails;
	
	
	
}
