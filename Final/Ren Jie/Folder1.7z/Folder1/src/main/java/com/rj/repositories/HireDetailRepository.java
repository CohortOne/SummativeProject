package com.rj.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.rj.models.Customer;
import com.rj.models.HireDetail;
import com.rj.models.Invoice;

public interface HireDetailRepository extends JpaRepository<HireDetail, Integer>{
	
	
	public List<HireDetail> findByCustomer(Customer customer);
	
	public List<HireDetail> findByCustomerAndInvoice(Customer customer, Invoice invoice);
}
