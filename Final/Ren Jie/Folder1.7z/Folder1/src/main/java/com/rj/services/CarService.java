package com.rj.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.rj.models.Car;
import com.rj.repositories.CarRepository;


@Service
public class CarService {
	@Autowired
    private CarRepository carRepository;
     
    public List<Car> listAll() {
        return carRepository.findAll();
    }
    
    public List<Car> listAvailable(){
    	return carRepository.listAvailable();
    }
    
    public void save(Car customer) {
    	carRepository.save(customer);
    }
     
    public Car get(int id) {
        return carRepository.findById(id).get();
    }
     
    public void delete(int id) {
    	carRepository.deleteById(id);
    }
    
    public Car update(int id) {
		Optional<Car> optional = carRepository.findById(id);
		Car car = null;
		
		if(optional.isPresent())
			car = optional.get();
		else
			throw new RuntimeException(" Car not found for id :: " + car);
		
		return car;
	}
}
