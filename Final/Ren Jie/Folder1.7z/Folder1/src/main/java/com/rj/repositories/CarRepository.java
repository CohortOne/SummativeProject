package com.rj.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.rj.models.Car;

public interface CarRepository extends JpaRepository<Car, Integer>{
	
//	@Query("SELECT u FROM Car u WHERE u.status = 0 AND u.enabled = 1")
	@Query("SELECT u FROM Car u WHERE u.status = false AND u.enabled = true")
	List<Car> listAvailable();
	
}
