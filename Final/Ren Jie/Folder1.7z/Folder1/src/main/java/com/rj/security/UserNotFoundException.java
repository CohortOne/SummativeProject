package com.rj.security;

public class UserNotFoundException extends Exception {
	public UserNotFoundException(String errorMessage) {
        super(errorMessage);
    }
}
