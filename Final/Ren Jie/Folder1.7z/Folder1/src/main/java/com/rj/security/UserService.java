package com.rj.security;

import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;


@Service
@Transactional
public class UserService {
	
	@Autowired
	private UserRepository userRepository;
	
	@Autowired
	private RoleRepository roleRepository;
	
	
	public User saveUser(User user) {
		
		//this role setting is for convenience, later admin have to be able to set it
		Role role1 = roleRepository.findByRoleName("employee");
		System.out.println(role1 + " this is role 1");
		Role role2 = roleRepository.findByRoleName("manager");
		Role role3 = roleRepository.findByRoleName("admin");
		Set<Role> roles = new HashSet<>();
		roles.add(role1);
		roles.add(role2);
		roles.add(role3);
		user.setRoles(roles);
		System.out.println("here is printing user" + roles + "\n");
		user.setEnabled(true);
		return userRepository.save(user);
	}
	
	public List<User> findByEmail(String email) {
		return userRepository.findByEmail(email);
	}
	
	public List<User> findByUsername(String username) {
		return userRepository.findByUsername(username);
	}
	
	public List<User> findByPhoneNumber(String phoneNo) {
		return userRepository.findByPhoneNo(phoneNo);
	}
	
	 public void updateResetPasswordToken(String token, String email) throws UserNotFoundException {
	        User user = userRepository.findByEmail2(email);
	        if (user != null) {
	            user.setResetPasswordToken(token);
	            userRepository.save(user);
	        } else {
	        	System.out.println("knnn!!\n");
	            throw new UserNotFoundException("Could not find any user with the email " + email);
	        }
    }
     
    public User getByResetPasswordToken(String token) {
        return userRepository.findByResetPasswordToken(token);
    }
     
    public void updatePassword(User user, String newPassword) {
    	System.out.println("password: " + newPassword);
        BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
        String encodedPassword = passwordEncoder.encode(newPassword);
        user.setPassword(encodedPassword);
         
        user.setResetPasswordToken(null);
        userRepository.save(user);
    }
    
    public List<User> listAll(){
    	return userRepository.findAll();
    }
    
    public List<Role> findAll(){
    	return roleRepository.findAll();
    }
	
	public void delete(int id) {
		userRepository.deleteById(id);
	}
	
	public User update(int id) {
		Optional<User> optional = userRepository.findById(id);
		User user = null;
		
		if(optional.isPresent())
			user = optional.get();
		else
			throw new RuntimeException(" User not found for id :: " + user);
		
		return user;
	}
}
