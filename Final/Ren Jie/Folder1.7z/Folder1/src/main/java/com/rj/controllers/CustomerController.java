package com.rj.controllers;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.rj.models.Customer;
import com.rj.security.Role;
import com.rj.security.User;
import com.rj.services.CustomerService;

@Controller
public class CustomerController {

	@Autowired
	private CustomerService customerService;

	@GetMapping("/customerList")
	public String customerList(Model model) {
		List<Customer> listCustomers = customerService.listAll();
		model.addAttribute("listCustomers", listCustomers);

		return "customerList";
	}

	@GetMapping("/createCustomer")
	public String createCustomer(Model model) {
		Customer customer = new Customer();
		model.addAttribute("customer", customer);
		return "createCustomer";
	}

	@PostMapping("/saveCustomer")
	public String saveCustomer(@Valid @ModelAttribute("customer") Customer customer, BindingResult bindingResult,
			String viewType, Model model) {
		
//		if (customer.getEmail() == "") {
//			bindingResult.rejectValue("email", "error.user", "must not be null");	
//		}
//		
//		if (customer.getFullName() == "") {
//			bindingResult.rejectValue("fullName", "error.user", "must not be null");	
//		}
//		
//		if (customer.getAddress() == "") {
//			bindingResult.rejectValue("address", "error.user", "must not be null");	
//		}
		
		// error checking
		bindingResult.getFieldErrors().stream()
				.forEach(f -> System.out.println(f.getField() + ": " + f.getDefaultMessage()));

		if (bindingResult.hasErrors() && viewType.equals("createCustomer")) {
			return "createCustomer";
		} else if (bindingResult.hasErrors() && viewType.equals("updateCustomer")) {
			return "updateCustomer";
		}
		customerService.save(customer);

		return "redirect:/customerList";
	}
	
	@GetMapping("/updateCustomer/{custId}")
	public String updateCustomer(@PathVariable (value = "custId") int custId, Model model) {
	 
	Customer customer = customerService.update(custId); 
	model.addAttribute("customer", customer);
	
	
	return "updateCustomer";
	}
	
	@GetMapping("/deleteCustomer/{custId}")
	public String deleteCustomer(@PathVariable (value = "custId") int custId) {
	 
	 // call delete employee method 
	 customerService.delete(custId);
	 return "redirect:/customerList";
	}
	
	
}
