package com.rj.controllers;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.rj.models.Car;
import com.rj.models.Customer;
import com.rj.security.Role;
import com.rj.security.User;
import com.rj.services.CarService;
import com.rj.services.CustomerService;

@Controller
public class CarController {

	@Autowired
	private CarService carService;

	@GetMapping("/carList")
	public String carList(Model model) {
		List<Car> listCars = carService.listAll();
		model.addAttribute("listCars", listCars);

		return "carList";
	}

	@GetMapping("/createCar")
	public String createCar(Model model) {
		Car car = new Car();
		model.addAttribute("car", car);
		return "createCar";
	}

	@PostMapping("/saveCar")
	public String saveCar(@Valid @ModelAttribute("car") Car car, BindingResult bindingResult,
			String viewType, Model model) {
		
//		if (customer.getEmail() == "") {
//			bindingResult.rejectValue("email", "error.user", "must not be null");	
//		}
//		
//		if (customer.getFullName() == "") {
//			bindingResult.rejectValue("fullName", "error.user", "must not be null");	
//		}
//		
//		if (customer.getAddress() == "") {
//			bindingResult.rejectValue("address", "error.user", "must not be null");	
//		}
		
		// error checking
		bindingResult.getFieldErrors().stream()
				.forEach(f -> System.out.println(f.getField() + ": " + f.getDefaultMessage()));

		if (bindingResult.hasErrors() && viewType.equals("createCar")) {
			return "createCar";
		} else if (bindingResult.hasErrors() && viewType.equals("updateCar")) {
			return "updateCar";
		}
		carService.save(car);

		return "redirect:/carList";
	}
	
	@GetMapping("/updateCar/{carId}")
	public String updateCustomer(@PathVariable (value = "carId") int carId, Model model) {
	 
	Car car = carService.update(carId); 
	model.addAttribute("car", car);
	
	
	return "updateCar";
	}
	
	@GetMapping("/deleteCar/{carId}")
	public String deleteCar(@PathVariable (value = "carId") int carId) {
	 
	 // call delete employee method 
	 carService.delete(carId);
	 return "redirect:/carList";
	}
	
	
}
