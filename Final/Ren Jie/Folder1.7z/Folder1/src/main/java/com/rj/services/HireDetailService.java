package com.rj.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.rj.models.Customer;
import com.rj.models.HireDetail;
import com.rj.models.Invoice;
import com.rj.repositories.CustomerRepository;
import com.rj.repositories.HireDetailRepository;


@Service
public class HireDetailService {
	@Autowired
    private HireDetailRepository hireDetailRepository;
	
	@Autowired
    private CustomerRepository customerRepository;
	
     
    public List<HireDetail> listAll() {
        return hireDetailRepository.findAll();
    }
     
    public void save(HireDetail hireDetail) {
    	hireDetailRepository.save(hireDetail);
    }
     
    public HireDetail get(int id) {
        return hireDetailRepository.findById(id).get();
    }
     
    public void delete(int id) {
    	hireDetailRepository.deleteById(id);
    }
    
    public HireDetail update(int id) {
		Optional<HireDetail> optional = hireDetailRepository.findById(id);
		HireDetail hireDetail = null;
		
		if(optional.isPresent())
			hireDetail = optional.get();
		else
			throw new RuntimeException(" Hire Detail not found for id :: " + hireDetail);
		
		return hireDetail;
	}
    
    public List<HireDetail> listByCustomerId(Customer customer){
    	
    	return hireDetailRepository.findByCustomer(customer);
    }
    
    public List<HireDetail> listByCustomerAndInvoice(Customer customer, Invoice invoice){
    	
    	return hireDetailRepository.findByCustomerAndInvoice(customer, invoice);
    }
    
    
    
}
