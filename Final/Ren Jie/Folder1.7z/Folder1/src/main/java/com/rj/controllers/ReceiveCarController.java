package com.rj.controllers;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.rj.models.Car;
import com.rj.models.Customer;
import com.rj.models.HireDetail;
import com.rj.models.Invoice;
import com.rj.services.CarService;
import com.rj.services.CustomerService;
import com.rj.services.HireDetailService;
import com.rj.services.InvoiceService;

@Controller
public class ReceiveCarController {
	
	@Autowired
	private InvoiceService invoiceService;
	
	@Autowired
	private HireDetailService hireDetailService;
	
	@Autowired
	private CarService carService;
	
	@Autowired
	private CustomerService customerService;
	
//	@GetMapping("/hireDetailList")
//	public String hireDetailList(Model model) {
//		List<HireDetail> listHireDetails = hireDetailService.listAll();
//		model.addAttribute("listHireDetails", listHireDetails);
//
//		return "hireDetailList";
//	}

	@GetMapping("/receiveCar")
	public String receiveCar (Model model) {
		model.addAttribute("hiredetail", new HireDetail());
//		model.addAttribute("listCars", carService.listAll());
//		model.addAttribute("listCustomers", customerService.listAll());
		model.addAttribute("listCustomers", customerService.listRented());
		return "receiveCar";
	}
	
	@PostMapping("/receiveCar")
	public String receiveCarPost (@Valid @ModelAttribute("hiredetail") HireDetail hiredetail, BindingResult bindingResult, Model model) {
		System.out.println("eat eat: " + hiredetail+"/n");
		// error checking
		bindingResult.getFieldErrors().stream()
				.forEach(f -> System.out.println(f.getField() + ": " + f.getDefaultMessage()));
		
		if (hiredetail.getId() == null ) {
//		if (bindingResult.hasErrors() ) {
////			model.addAttribute("hiredetail", new HireDetail());
//			model.addAttribute("listCars", carService.listAll());
//			model.addAttribute("listCustomers", customerService.listAll());
			model.addAttribute("listCustomers", customerService.listRented());
			return "receiveCar";
		}
		
		
		//transferring info from form hiredetail into original hire detail
		HireDetail ogHireDetail = hireDetailService.get(hiredetail.getId());
		ogHireDetail.setDateReceived(hiredetail.getDateReceived());
		ogHireDetail.setUserReceive(hiredetail.getUserReceive());
		
		Invoice invoice = new Invoice();
		invoice.setDateCreated(LocalDate.now());
		invoice.setCustomer(hiredetail.getCustomer());
		List<HireDetail> hdlist = new ArrayList<>();;
		hdlist.add(ogHireDetail);
		invoice.setHireDetails(hdlist);
		
		long daysBetween = ChronoUnit.DAYS.between(ogHireDetail.getDateRented(), ogHireDetail.getDateReceived());
		BigDecimal d = new BigDecimal(daysBetween);
		BigDecimal totalCost = ogHireDetail.getCar().getHireRate().multiply(d) ;
		invoice.setTotalCost(totalCost); 
		invoiceService.save(invoice);
		Invoice savedInvoice = invoiceService.get(invoice.getId());
		ogHireDetail.setInvoice(savedInvoice);
//
//		System.out.println(invoiceService.get(invoice.getId()) + " non ");
		
		System.out.println(ogHireDetail + "\n");
		hireDetailService.save(ogHireDetail);
	
		//set car to available again
		Car car = ogHireDetail.getCar();
		car.setStatus(false);
		carService.save(car);
		
		//set customer status to false if no more outstanding hiredetails from him
		Customer customer = ogHireDetail.getCustomer();
		if (hireDetailService.listByCustomerAndInvoice(customer, null).isEmpty()) {
			customer.setStatus(false);
			customerService.save(customer);
		}
		
		return "redirect:/invoiceList";
	}
	
	@ResponseBody
	@RequestMapping(value = "receiveCar/loadHireDetails/{customerId}", method = RequestMethod.GET)
	public String loadHireDetailsByCustomerId(@PathVariable("customerId") Integer customerId) throws JsonProcessingException {
		System.out.println("hihihi");
		ObjectMapper mapper = new ObjectMapper();
//		Gson gson = new Gson();
		System.out.println("check customerId :" + customerId);
		Customer customer = customerService.findById(customerId);
		String jsonString = mapper.writeValueAsString(hireDetailService.listByCustomerAndInvoice(customer, null));
//		System.out.println("giggles" + hireDetailService.listByCustomerId(customerId));
//		return  gson.toJson(hireDetailService.listByCustomerId(customerId));
//		return  gson.toJson(customerService.listAll());
		System.out.println("the jsonstring is : " + jsonString);
		return jsonString;
//		return "asd";
		
	}
	
	
//	@GetMapping("/createHireDetail")
//	public String createHireDetail(Model model) {
//		HireDetail hiredetail = new HireDetail();
//		model.addAttribute("hiredetail", hiredetail);
//		return "createHireDetail";
//	}
//
//	@PostMapping("/saveHireDetail")
//	public String saveHireDetail(@Valid @ModelAttribute("hiredetail") HireDetail hiredetail, BindingResult bindingResult,
//			String viewType, Model model) {
//
//		
//		// error checking
//		bindingResult.getFieldErrors().stream()
//				.forEach(f -> System.out.println(f.getField() + ": " + f.getDefaultMessage()));
//
//		if (bindingResult.hasErrors() && viewType.equals("createHireDetail")) {
//			return "/createHireDetail";
//		} else if (bindingResult.hasErrors() && viewType.equals("updateHireDetail")) {
//			return "/updateHireDetail";
//		}
//		hireDetailService.save(hiredetail);
//
//		return "redirect:/hireDetailList";
//	}
//	
//	@GetMapping("/updateHireDetail/{hireDetailId}")
//	public String updateCustomer(@PathVariable (value = "hireDetailId") int hireDetailId, Model model) {
//	 
//	HireDetail hiredetail = hireDetailService.update(hireDetailId); 
//	model.addAttribute("hiredetail", hiredetail);
//	
//	
//	return "updateHireDetail";
//	}
//	
//	@GetMapping("/deleteHireDetail/{hireDetailId}")
//	public String deleteHireDetail(@PathVariable (value = "hireDetailId") int hireDetailId) {
//	 
//	 // call delete employee method 
//	 hireDetailService.delete(hireDetailId);
//	 return "redirect:/hireDetailList";
//	}
	
	
}
