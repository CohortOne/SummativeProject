package com.rj.models;

import java.time.LocalDate;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonManagedReference;

@Entity
public class Customer {
	@Id
    @Column(name = "custId")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
	
	@NotBlank
	@Size(max=50)
    @Column(name = "fullName")
    private String fullName;
	
	@NotBlank
	@Size(max=50)
    @Column(name = "email")
	private String email;
	
	@NotBlank
	@Size(max=150)
    @Column(name = "address")
	private String address;
	
	@NotBlank
	@Size(min = 8, max = 8, message="size must be 8")
    @Column(name = "phoneNo")
	private String phoneNo;
	
	@NotNull
    @Column(name = "dob")
    @DateTimeFormat(pattern = "yyyy-MM-dd")
	private LocalDate dob;
	
	@NotBlank
	@Column(name="nric")
	@Pattern(regexp = "^[STFG]\\d{7}[A-Z]$", message = "must start with S,T,F or G, followed by 7 digits and any capitalized letter")
	private String nric;
	
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}

	public LocalDate getDob() {
		return dob;
	}

	public void setDob(LocalDate dob) {
		this.dob = dob;
	}

	public String getNric() {
		return nric;
	}

	public void setNric(String nric) {
		this.nric = nric;
	}

	public boolean isStatus() {
		return status;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}

	@Column(name = "status")
	private boolean status;

	public Customer() {
		super();
	}

	

	public Customer(Integer id, @Size(max = 50) @NotNull String fullName, @Size(max = 50) @NotNull @Email String email,
			@Size(max = 150) @NotNull String address,
			@Size(min = 8, max = 8, message = "size must be 8") @NotNull String phoneNo, @NotNull LocalDate dob,
			@NotNull @Pattern(regexp = "^[STFG]\\d{7}[A-Z]$") String nric, boolean status) {
		super();
		this.id = id;
		this.fullName = fullName;
		this.email = email;
		this.address = address;
		this.phoneNo = phoneNo;
		this.dob = dob;
		this.nric = nric;
		this.status = status;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((address == null) ? 0 : address.hashCode());
		result = prime * result + ((dob == null) ? 0 : dob.hashCode());
		result = prime * result + ((email == null) ? 0 : email.hashCode());
		result = prime * result + ((fullName == null) ? 0 : fullName.hashCode());
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + ((nric == null) ? 0 : nric.hashCode());
		result = prime * result + ((phoneNo == null) ? 0 : phoneNo.hashCode());
		result = prime * result + (status ? 1231 : 1237);
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Customer other = (Customer) obj;
		if (address == null) {
			if (other.address != null)
				return false;
		} else if (!address.equals(other.address))
			return false;
		if (dob == null) {
			if (other.dob != null)
				return false;
		} else if (!dob.equals(other.dob))
			return false;
		if (email == null) {
			if (other.email != null)
				return false;
		} else if (!email.equals(other.email))
			return false;
		if (fullName == null) {
			if (other.fullName != null)
				return false;
		} else if (!fullName.equals(other.fullName))
			return false;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		if (nric == null) {
			if (other.nric != null)
				return false;
		} else if (!nric.equals(other.nric))
			return false;
		if (phoneNo == null) {
			if (other.phoneNo != null)
				return false;
		} else if (!phoneNo.equals(other.phoneNo))
			return false;
		if (status != other.status)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Customer [id=" + id + ", fullName=" + fullName + ", email=" + email + ", address=" + address
				+ ", phoneNo=" + phoneNo + ", dob=" + dob + ", nric=" + nric + ", status=" + status + "]";
	}
	
	
	@OneToMany(mappedBy="customer")
	@JsonManagedReference
	private List<HireDetail> hireDetails;
	
	@OneToMany(mappedBy="customer")
	@JsonManagedReference
	private List<Invoice> invoices;
	
	
	
}
