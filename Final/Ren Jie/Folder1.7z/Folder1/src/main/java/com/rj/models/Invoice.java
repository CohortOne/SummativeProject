package com.rj.models;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;


@Entity
public class Invoice {
	@Id
    @Column(name = "invoiceId")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
	
	@NotNull
    @Column(name = "dateCreated")
    @DateTimeFormat(pattern = "yyyy-MM-dd")
	private LocalDate dateCreated;
	
	@Column(name = "paidStatus")
	private boolean paidStatus;
	
	@NotNull
	@Column(name = "totalCost", precision = 8, scale = 2)
	private BigDecimal totalCost;
	
	@OneToMany(mappedBy="invoice")
	@JsonManagedReference
	private List<HireDetail> hireDetails;
	
	@NotNull
    @ManyToOne
    @JsonBackReference
    @JoinColumn(name = "custId")
    private Customer customer;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public LocalDate getDateCreated() {
		return dateCreated;
	}

	public void setDateCreated(LocalDate dateCreated) {
		this.dateCreated = dateCreated;
	}

	public boolean isPaidStatus() {
		return paidStatus;
	}

	public void setPaidStatus(boolean paidStatus) {
		this.paidStatus = paidStatus;
	}

	public BigDecimal getTotalCost() {
		return totalCost;
	}

	public void setTotalCost(BigDecimal totalCost) {
		this.totalCost = totalCost;
	}

	public List<HireDetail> getHireDetails() {
		return hireDetails;
	}

	public void setHireDetails(List<HireDetail> hireDetails) {
		this.hireDetails = hireDetails;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public Invoice(Integer id, @NotNull LocalDate dateCreated, boolean paidStatus, @NotNull BigDecimal totalCost,
			List<HireDetail> hireDetails, @NotNull Customer customer) {
		super();
		this.id = id;
		this.dateCreated = dateCreated;
		this.paidStatus = paidStatus;
		this.totalCost = totalCost;
		this.hireDetails = hireDetails;
		this.customer = customer;
	}

	public Invoice() {
		super();
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((customer == null) ? 0 : customer.hashCode());
		result = prime * result + ((dateCreated == null) ? 0 : dateCreated.hashCode());
		result = prime * result + ((hireDetails == null) ? 0 : hireDetails.hashCode());
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + (paidStatus ? 1231 : 1237);
		result = prime * result + ((totalCost == null) ? 0 : totalCost.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Invoice other = (Invoice) obj;
		if (customer == null) {
			if (other.customer != null)
				return false;
		} else if (!customer.equals(other.customer))
			return false;
		if (dateCreated == null) {
			if (other.dateCreated != null)
				return false;
		} else if (!dateCreated.equals(other.dateCreated))
			return false;
		if (hireDetails == null) {
			if (other.hireDetails != null)
				return false;
		} else if (!hireDetails.equals(other.hireDetails))
			return false;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		if (paidStatus != other.paidStatus)
			return false;
		if (totalCost == null) {
			if (other.totalCost != null)
				return false;
		} else if (!totalCost.equals(other.totalCost))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Invoice [id=" + id + ", dateCreated=" + dateCreated + ", paidStatus=" + paidStatus + ", totalCost="
				+ totalCost + ", hireDetails=" + hireDetails + ", customer=" + customer + "]";
	}
	
	
	
}
