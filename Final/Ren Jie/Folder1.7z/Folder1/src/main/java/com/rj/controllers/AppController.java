package com.rj.controllers;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;

import com.rj.security.User;
import com.rj.security.UserService;

@Controller
public class AppController {
	
	@GetMapping("/")
	public String viewHomePage() {
		return "index";
	}
	
//	@GetMapping("/testing")
//	public String testingPage() {
//		return "testing";
//	}
	
//	//from here onwards all need delete off, trial only
//	@Autowired
//	private UserService userService;
//	
//	@GetMapping("/")
//	public String viewHomePage(Model model) {
//		List<User> listUsers = userService.listAll();
//		model.addAttribute("listUsers", listUsers);
//		return "index2";
//	}
//	
//	//till here
	
	@GetMapping("/login")
	public String viewLoginPage(Model model, @ModelAttribute("registerStatus") String registerStatus) { //, @ModelAttribute("message") String message, @ModelAttribute("error") String error
		User user = new User();
		model.addAttribute("user", user);
		model.addAttribute("registerStatus", registerStatus);
//		model.addAttribute("message", message);
//		model.addAttribute("error", error);
		return "login-5";
	}
	
	
	@GetMapping("/accessDenied")
	public String accessdenied(Model model, HttpServletRequest request) {
		
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
	
		if (auth != null) {
			model.addAttribute("authName", auth.getName());
			model.addAttribute("authIsAuth", auth.isAuthenticated());
			model.addAttribute("authGetAuth", auth.getAuthorities());
		}
		
		return "accessDenied";
	}
	
}