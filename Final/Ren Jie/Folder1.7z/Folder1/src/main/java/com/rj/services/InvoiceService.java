package com.rj.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.rj.models.Customer;
import com.rj.models.Invoice;
import com.rj.repositories.CustomerRepository;
import com.rj.repositories.InvoiceRepository;


@Service
public class InvoiceService {
	@Autowired
    private InvoiceRepository invoiceRepository;
     
    public List<Invoice> listAll() {
        return invoiceRepository.findAll();
    }
     
    public void save(Invoice invoice) {
    	invoiceRepository.save(invoice);
    }
     
    public Invoice get(int id) {
        return invoiceRepository.findById(id).get();
    }
     
    public void delete(int id) {
    	invoiceRepository.deleteById(id);
    }
    
    public Invoice update(int id) {
		Optional<Invoice> optional = invoiceRepository.findById(id);
		Invoice invoice= null;
		
		if(optional.isPresent())
			invoice = optional.get();
		else
			throw new RuntimeException(" Invoice not found for id :: " + invoice);
		
		return invoice;
	}
}
