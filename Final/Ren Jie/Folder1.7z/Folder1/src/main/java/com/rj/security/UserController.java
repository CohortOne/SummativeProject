package com.rj.security;


import java.io.IOException;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.StringUtils;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;



@Controller
public class UserController {

	// put this in user service, not good to be in controller
	@Autowired
	private BCryptPasswordEncoder bCryptPasswordEncoder;
	
	@Autowired
	private UserService userService;
	
	@GetMapping("/saveUser")
	public String getSaveUser() {
	        return "redirect:/login";
	}

	
	@PostMapping("/saveUser")
	public String saveUser(@Valid @ModelAttribute("user") User user, BindingResult bindingResult, RedirectAttributes ra, Model model,
			@RequestParam("image") MultipartFile multipartFile, String viewType
			) throws IOException {
		
		
		// save employee to database
		if(viewType.equals("newUser")) {
			if (!userService.findByEmail(user.getEmail()).isEmpty()) {
				bindingResult.rejectValue("email", "error.user", "An account already exists for this Email.");
			}

			if (!userService.findByUsername(user.getUsername()).isEmpty()) {
				bindingResult.rejectValue("username", "error.user", "An account already exists for this Username.");
			}
			
			if (!userService.findByPhoneNumber(user.getPhoneNo()).isEmpty()) {
				bindingResult.rejectValue("phoneNo", "error.user", "An account already exists for this Phone Number.");
			}
		}
		
		
		
		//error checking
		bindingResult
		.getFieldErrors()
		.stream()
		.forEach(f -> System.out.println(f.getField() + ": " + f.getDefaultMessage()));
		
		
		
		
		if (bindingResult.hasErrors() && viewType.equals("newUser")) {
			model.addAttribute("showForm", "showForm");
			return "login-5";
		} else if (bindingResult.hasErrors() && viewType.equals("updateUser")) {
			List<Role> roles = (List<Role>) userService.findAll();
			model.addAttribute("allRoles", roles);
			return "updateUserList";
		}
		
		String fileName="";
		//attempt at photo
		if(!multipartFile.isEmpty()) {
			fileName = StringUtils.cleanPath(multipartFile.getOriginalFilename());
			user.setPhoto(fileName);
			
		}
		
		
		if(viewType.equals("newUser")) {
			user.setPassword(bCryptPasswordEncoder.encode(user.getPassword()));
		}
		User savedUser = userService.saveUser(user);
		
		if(!multipartFile.isEmpty()) {
			//attempt at photo
			String uploadDir = "user-photos/" + savedUser.getId();
	        FileUploadUtil.saveFile(uploadDir, fileName, multipartFile);
		}
		
		
		
		
		ra.addFlashAttribute("registerStatus", "success");
		
		if(viewType.equals("newUser")){
		    return "redirect:/login";
		}else{
		      return "redirect:/userList";
		}
		
//		
//		return "redirect:/login";
	}
	
	@GetMapping("/userList")
	public String readUserList(Model model) {
		List<User> listUsers = userService.listAll();
		model.addAttribute("listUsers", listUsers);
		return "userList";
	}

	@GetMapping("/deleteUser/{userId}")
	public String deleteUser(@PathVariable (value = "userId") int userId) {
	 
	 // call delete employee method
	 // this try block need to work on it
//	try {
//		userService.delete(userId);
//	}
//	catch(Exception e) {
//		System.out.println("problem with deleting user...\n");
//		return "redirect:/userList";
//	}
	 userService.delete(userId);
	 return "redirect:/userList";
	}
	
	@GetMapping("/updateUser/{userId}")
	public String updateUser(@PathVariable (value = "userId") int userId, Model model) {
	 
	User user = userService.update(userId); 
	model.addAttribute("user", user);
	
	List<Role> roles = (List<Role>) userService.findAll();
	model.addAttribute("allRoles", roles);
	
	return "updateUserList";
	}
	
	
}
