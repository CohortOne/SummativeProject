"use strict";
var KTDatatablesBasicHeaders = function() {

	var initTable1 = function() {
		var table = $('#kt_datatable');

		// begin first table
		table.DataTable({
			"lengthMenu": [ [5, 10, 25, 50, -1], [5, 10, 25, 50, "All"] ],
			responsive: true,
			columnDefs: [
				{
					targets: -1,
					title: 'Actions',
					orderable: false,
					
					visible: document.getElementById('role').value == 'gotit'
				}
			],
			"createdRow": function( row, data, dataIndex ) {
				console.log(data[5]);
				console.log("data is : " +data);
				console.log(dataIndex);
			    if ( data[5].toString().includes("checked") == true ) {
			      $('td', row).eq(7).addClass('hidethis');
			    }
			  }
		});
	};

	return {

		//main function to initiate the module
		init: function() {
			initTable1();
		},

	};

}();

jQuery(document).ready(function() {
	KTDatatablesBasicHeaders.init();
});
