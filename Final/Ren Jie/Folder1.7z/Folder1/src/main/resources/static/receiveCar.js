$(document).ready(function(){
	
	$('#selectCustomer').on('change', function(){
		var customerId = $(this).find(":selected").val();
		
		$.ajax({
			type: 'GET',
			url: '/receiveCar/loadHireDetails/' + customerId,
			success:function(result){
				console.log(result);
				var result = JSON.parse(result);
				var s = '';
				s+= '<option disabled selected value> -- select an option -- </option>';
				for (var i = 0; i <result.length; i++){
					s+= '<option value ="' + result[i].id + '">' + result[i].id + '</option>';
				}
				console.log(s);
				$('#selectHireDetail').html(s);
			}
		})
	})
	
});