package carDate;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CarzoomApplication {

	public static void main(String[] args) {
		SpringApplication.run(CarzoomApplication.class, args);
		
		System.out.println("**************** Heroku   Carzoom   Application *******************");
		System.out.println("**************** https://carzoom.herokuapp.com/ *************");
		System.out.println("** https://github.com/alvintwng/ntucLH/tree/master/mKHeroku *");
	
	}

}
