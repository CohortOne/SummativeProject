// JavaScript program to calculate the no. of days between two dates and compute charges 

$(document).ready(function () {

	//Disable #rentalActualReturnDate
	const actualReturnDate = document.querySelector("#rentalActualReturnDate");
	actualReturnDate.disabled = true;
	
	//Call computeRental() function
	computeRental("computeRentalModify");							
})