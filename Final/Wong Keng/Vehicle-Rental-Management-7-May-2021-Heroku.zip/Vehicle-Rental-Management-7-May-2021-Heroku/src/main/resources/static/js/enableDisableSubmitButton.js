// JavaScript to activate and deactivate the form submit button for new_customer and new_vehicle forms 

function enableDisableSubmitButton(whichForm) {

	const submitButton = document.querySelector("#submitButton");

	//Disable #submitButton
	submitButton.disabled = true;
	
	if (whichForm == "4NewCustomerForm") {
		$('#drivingLicNum').keyup(function() {
		    if (this.value.length > 5) {
			
			//Enable #submitButton
		        submitButton.disabled = false;
		    }
			else {
				submitButton.disabled = true;
			}
		})
	}
	//if from new customer form	
	else if (whichForm == "4NewVehicleForm") {
		$('#regNum').keyup(function() {
		    if (this.value.length > 4) {
			
			//Enable #submitButton
		        submitButton.disabled = false;
		    }
			else {
				submitButton.disabled = true;
			}
		})	
	}		
}
