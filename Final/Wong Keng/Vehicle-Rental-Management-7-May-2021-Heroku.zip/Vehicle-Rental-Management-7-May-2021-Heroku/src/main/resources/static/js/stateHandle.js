//Function to enable and disable 'Book Vehicle' button

function stateHandle(formTotalCharge) {
	
	const button = document.querySelector("#bookVeh");
	
	if (formTotalCharge.value > 0) {
		button.disabled = false; //button is enabled
	}
}