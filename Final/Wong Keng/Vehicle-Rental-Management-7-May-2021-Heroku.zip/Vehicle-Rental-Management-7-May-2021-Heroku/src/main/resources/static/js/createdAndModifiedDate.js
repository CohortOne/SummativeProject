//Build Created and Modified Date String

function currentDateTimeStr() {
	
	//Initialise variable
	let currentDate = "";
	let month = 0;
	let monthStr = "";
	
	//Set var to current Date and Time	
	currentDate = new Date();
	
	month = currentDate.getMonth() + 1; //Note 0 from getMonth() is January
	
	//if month is less than 10, prefix with'0'
	if (month < 10) {
		monthStr = '0' + month;
	} else {
		monthStr = month;
	}
	
	minutes = currentDate.getMinutes()
	
	//if minutes is less than 10, prefix with'0'
	if (minutes < 10) {
		minutesStr = '0' + minutes;
	} else {
		minutesStr = minutes;
	}
		
	//form datetime string and return string.
	return currentDate.getFullYear() + '-' + monthStr + '-' + currentDate.getDate() + 'T'
								+ currentDate.getHours() + ':' + minutesStr;
	
}