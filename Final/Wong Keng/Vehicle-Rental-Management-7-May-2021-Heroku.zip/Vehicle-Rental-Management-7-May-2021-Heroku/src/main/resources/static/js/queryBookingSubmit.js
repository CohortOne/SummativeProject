// JavaScript validation program for booking query forms

$(document).ready(function () {
	
	$("#queryBookingForm").validate({
/*		errorPlacement: function(error, element){
			if (element.attr("name") == "userRoles") {
     			error.insertAfter(".roleLabel");
  			} else {
			     error.insertAfter(element);
			}
	    },
*/
		rules: {
			bookId:  {
				required: true,
			},
			brand: {
				required: true,
				minlength: 4,
				maxlength: 15				
			},
			model: {
				required: true,
				minlength: 3,
				maxlength: 15				
			},
			hireRate: "required",
		},
		messages: {
			bookId: {
				required: "Please enter a Booking ID",
			},
			brand: {
				required: "Please enter vehicle Brand",
				minlength: "Brand minimum length is 4 characters",
				maxlength: "Brand maximum length is 15 characters"
			},
			model: {
				required: "Please enter vehicle Model",
				minlength: "Model minimum length is 3 characters",
				maxlength: "Model maximum length is 15 characters"
			},
			hireRate: "Please enter daily rate of vehicle",
		}		
	});				
});