// JavaScript validation program for new_user.html, update_user_password.html and update_user_reset_password.html

$(document).ready(function () {
	
	$("#userForm").validate({
		errorPlacement: function(error, element){
			if (element.attr("name") == "userRoles") {
     			error.insertAfter(".roleLabel");
  			} else {
			     error.insertAfter(element);
			}
	    },
		rules: {
			firstName: {
				required: true,
				minlength: 2
			},
			lastName:{
				required: true,
				minlength: 2
			},
			username: {
				required: true,
				minlength: 2
			},
			password: {
				required: true,
				minlength: 5
			},
			reEnterNewPassword: {
				required: true,
				minlength: 5,
				equalTo: "#password"
			},
			userRoles: {
				required: true,
			}
		},
		messages: {
			firstName: {
				required: "Please enter your Firstname",
				minlength: "Firstname must have minimum of 2 characters"
			},
			lastName: {
				required: "Please enter your Lastname",
				minlength: "Lastname must have minimum of 2 characters"
			},
			username: {
				required: "Please enter a username",
				minlength: "Your username must consists of at least 2 characters"
			},
			password: {
				required: "Please provide a password",
				minlength: "Your password must be at least 6 characters long"
			},
			reEnterNewPassword: {
				required: "Please re-enter the same password",
				minlength: "Your password must be at least 6 characters long",
				equalTo: "Passwords do not match. Please re-enter."
			},
			userRoles: {
				required: "Role must be selected."
			}
		}		
	});				
});