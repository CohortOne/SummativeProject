function plotMonthlyCharts_3() {
	
	$.ajax({
	url: 'mgt_showLineChart4Bookings_3',
	success: function(result){
		let month = JSON.parse(result).month;
		let data = JSON.parse(result).objectData;
		let xLabel = '<b>Month</b>';
		let yLabel = '<b>No. of Bookings</b>';
		let containerId = 'container_bookings';
		let format = '{y}';
/*		
		console.log("month : " + month);
		console.log("bookingData : " + data);
*/		
		drawLineChart(month, data, xLabel, yLabel, containerId, format);
		}
	})

	$.ajax({
	url: 'mgt_showLineChart4Revenue_3',
	success: function(result){
		let month = JSON.parse(result).month;
		let data = JSON.parse(result).objectData;
		let xLabel = '<b>Month</b>';
		let yLabel = '<b>Revenue (SGD)</b>';
		let containerId = 'container_revenue';
		let format = '${y}';
/*
		console.log("month : " + month);
		console.log("revenueData : " + data);
*/
		drawRevenueLineChart(month, data, xLabel, yLabel, containerId, format);
		}
	})

}

function plotMonthlyCharts_6() {
	
	$.ajax({
	url: 'mgt_showLineChart4Bookings_6',
	success: function(result){
		let month = JSON.parse(result).month;
		let data = JSON.parse(result).objectData;
		let xLabel = '<b>Month</b>';
		let yLabel = '<b>No. of Bookings</b>';
		let containerId = 'container_bookings';
		let format = '{y}';
/*		
		console.log("month : " + month);
		console.log("bookingData : " + data);
*/		
		drawLineChart(month, data, xLabel, yLabel, containerId, format);
		}
	})

	$.ajax({
	url: 'mgt_showLineChart4Revenue_6',
	success: function(result){
		let month = JSON.parse(result).month;
		let data = JSON.parse(result).objectData;
		let xLabel = '<b>Month</b>';
		let yLabel = '<b>Revenue (SGD)</b>';
		let containerId = 'container_revenue';
		let format = '${y}';
/*
		console.log("month : " + month);
		console.log("revenueData : " + data);
*/
		drawRevenueLineChart(month, data, xLabel, yLabel, containerId, format);
		}
	})

}

function plotMonthlyCharts_9() {
	
	$.ajax({
	url: 'mgt_showLineChart4Bookings_9',
	success: function(result){
		let month = JSON.parse(result).month;
		let data = JSON.parse(result).objectData;
		let xLabel = '<b>Month</b>';
		let yLabel = '<b>No. of Bookings</b>';
		let containerId = 'container_bookings';
		let format = '{y}';
/*		
		console.log("month : " + month);
		console.log("bookingData : " + data);
*/		
		drawLineChart(month, data, xLabel, yLabel, containerId, format);
		}
	})

	$.ajax({
	url: 'mgt_showLineChart4Revenue_9',
	success: function(result){
		let month = JSON.parse(result).month;
		let data = JSON.parse(result).objectData;
		let xLabel = '<b>Month</b>';
		let yLabel = '<b>Revenue (SGD)</b>';
		let containerId = 'container_revenue';
		let format = '${y}';
/*
		console.log("month : " + month);
		console.log("revenueData : " + data);
*/
		drawRevenueLineChart(month, data, xLabel, yLabel, containerId, format);
		}
	})

}

function plotMonthlyCharts_12() {
	
	$.ajax({
	url: 'mgt_showLineChart4Bookings_12',
	success: function(result){
		let month = JSON.parse(result).month;
		let data = JSON.parse(result).objectData;
		let xLabel = '<b>Month</b>';
		let yLabel = '<b>No. of Bookings</b>';
		let containerId = 'container_bookings';
		let format = '{y}';
/*		
		console.log("month : " + month);
		console.log("bookingData : " + data);
*/		
		drawLineChart(month, data, xLabel, yLabel, containerId, format);
		}
	})

	$.ajax({
	url: 'mgt_showLineChart4Revenue_12',
	success: function(result){
		let month = JSON.parse(result).month;
		let data = JSON.parse(result).objectData;
		let xLabel = '<b>Month</b>';
		let yLabel = '<b>Revenue (SGD)</b>';
		let containerId = 'container_revenue';
		let format = '${y}';
/*
		console.log("month : " + month);
		console.log("revenueData : " + data);
*/
		drawRevenueLineChart(month, data, xLabel, yLabel, containerId, format);
		}
	})

}


function drawLineChart(month, data, xLabel, yLabel, containerId, format){
	
	Highcharts.chart(containerId, {
	
		chart: {
			type: 'column',
			width: 500
		},
		
		title: {
			text: ''
		},
		
		xAxis: {
			categories: month,
			
			gridLineWidth: 1,
		    lineColor: '#000',
			tickColor: '#555555',
        	tickWidth: 3,
			
			labels: {
		         style: {
		            color: '#F00',
		            font: '11px Trebuchet MS, Verdana, sans-serif'
		         }
			},
			
			title: {
	            text: xLabel,
	            style: {
	                fontWeight: 'normal'
            	}
        	}
		},
		
		yAxis: {
			allowDecimals: false,
			opposite: false,		
			title: {
	            text: yLabel,
	            style: {
	                fontWeight: 'normal'
            	}
        	}	
		},
		
		plotOptions: {
        series: {
            dataLabels: {
                enabled: true,
                color: 'red',
				borderRadius: 5,
                backgroundColor: 'rgba(252, 255, 197, 0.7)',
                borderWidth: 1,
                borderColor: '#AAA',
				format: format,
	            }
	        }
	    },
		
		legend: {
		    enabled: false
		},
		
		credits: {
		    enabled: false
		},
		
		tooltip: {
			
			enabled: false

		},
		
		series:[{
			data: data
		}]
	});

}

function drawRevenueLineChart(month, data, xLabel, yLabel, containerId, format){
	
	Highcharts.setOptions({
        lang: {
            thousandsSep: ','
		}
    });
	
	
	Highcharts.chart(containerId, {
	
		chart: {
			type: 'line',
			width: 500
		},
		
		title: {
			text: ''
		},
		
		xAxis: {
			categories: month,
			
			gridLineWidth: 1,
		    lineColor: '#000',
			tickColor: '#555555',
        	tickWidth: 3,
			
			labels: {
		         style: {
		            color: '#F00',
		            font: '11px Trebuchet MS, Verdana, sans-serif'
		         }
			},
			
			title: {
	            text: xLabel,
	            style: {
	                fontWeight: 'normal'
            	}
        	}
		},
		
		yAxis: {
			allowDecimals: false,
			opposite: false,		
			title: {
	            text: yLabel,
	            style: {
	                fontWeight: 'normal'
            	}
        	}	
		},
		
		plotOptions: {
        series: {
            dataLabels: {
                enabled: true,
                color: 'red',
				borderRadius: 5,
                backgroundColor: 'rgba(252, 255, 197, 0.7)',
                borderWidth: 1,
                borderColor: '#AAA',
				formatter: function () {
                            return '$' + Highcharts.numberFormat(this.y,2);
                 			}
	            }
	        }
	    },
		
		legend: {
		    enabled: false
		},
		
		credits: {
		    enabled: false
		},
		
		tooltip: {
			
			enabled: false
			
		},

		
		series:[{
			data: data
		}]
	});

}

