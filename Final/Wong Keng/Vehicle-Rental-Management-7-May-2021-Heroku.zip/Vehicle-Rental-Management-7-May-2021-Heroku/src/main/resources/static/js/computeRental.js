// JavaScript program to calculate the no. of days between two dates and compute charges 

$(document).ready(function() {
	
	//call computeRental() function
	computeRental("computeRental");

})