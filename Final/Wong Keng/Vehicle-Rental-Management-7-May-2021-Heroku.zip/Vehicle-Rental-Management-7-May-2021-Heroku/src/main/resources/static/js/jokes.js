const joke = document.querySelector('#joke');
		
const fetchAJoke = async() => {
    const config = { headers: { Accept: 'application/json' } };
    const res = await axios.get("https://icanhazdadjoke.com/", config);
    const newJoke = res.data.joke;

    joke.innerText = newJoke;

}

window.addEventListener('load', fetchAJoke);