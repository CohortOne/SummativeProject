// JavaScript validation program for new_customer.html

$(document).ready(function () {
	
	$("#newCustomerForm").validate({
/*		errorPlacement: function(error, element){
			if (element.attr("name") == "userRoles") {
     			error.insertAfter(".roleLabel");
  			} else {
			     error.insertAfter(element);
			}
	    },
*/
		rules: {
			drivingLicNum:  {
				required: true,
				minlength: 6,
				maxlength: 12				
			},
			firstName: {
				required: true,
				minlength: 2,
				maxlength: 30				
			},
			lastName: {
				required: true,
				minlength: 3,
				maxlength: 30				
			},
			dob: "required",
			ccNum: {
				required: true,
				minlength: 13,
				maxlength: 16				
			},
			ccExpiryDate: "required",
			address: {
				required: true,
				minlength: 6,
				maxlength: 50				
			},
			email: {
				required: true,
				email: true				
			},			
			phoneNo: {
				required: true,
				minlength: 8,
				maxlength: 15
			}
		},
		messages: {
			drivingLicNum: {
				required: "Please enter a valid Driving License",
				minlength: "License Number minimum length is 6 characters",
				maxlength: "License Number maximum length is 12 characters"
			},
			firstName: {
				required: "Please enter your Firstname",
				minlength: "Firstname minimum length is 2 characters",
				maxlength: "Firstname maximum length is 30 characters"
			},
			lastName: {
				required: "Please enter your Lastname",
				minlength: "Lastname minimum length is 3 characters",
				maxlength: "Lastname maximum length is 30 characters"
			},
			dob: "Date of Birth is required",
			ccNum: {
				required: "Please enter a valid Credit Card Number",
				minlength: "CC Number minimum length is 13",
				maxlength: "CC Number maximum length is 16"
			},
			ccExpiryDate: "Credit Card Expiry Date is required",
			address: {
				required: "Please provide an Address",
				minlength: "Address minimum length is 6 characters",
				maxlength: "Address maximum length is 50 characters"
			},
			phoneNo: {
				required: "Please enter contact number",
				minlength: "Phone No. minimum length is 8 characters",
				maxlength: "Phone No. maximum length is 15 characters"
			},
			
		}		
	});				
});