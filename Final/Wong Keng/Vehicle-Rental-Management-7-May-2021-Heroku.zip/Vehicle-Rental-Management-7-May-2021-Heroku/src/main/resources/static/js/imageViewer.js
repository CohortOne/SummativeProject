	$(document).ready(function() {
			$('#fileImage').change(function() {
				
	            if (this.files[0].size > 1048576) {
	                alert("File size exceeded 1MB! Please select a smaller file.");
	            } else {
		
					showImageThumbnail(this);
				}
								
			});
			
			//display file size limit
			$("#fileSizeInfo").text("(Maximum Image file size is 1Mb or less.)");

		});
		
	function showImageThumbnail(fileInput) {
		
			//clear file size limit information
			$("#fileSizeInfo").text("");
		
			file = fileInput.files[0];
			reader = new FileReader();
			
			reader.onload = function(e) {
				$('#thumbnail').attr('src', e.target.result);
			};
			
			reader.readAsDataURL(file);
			
	}