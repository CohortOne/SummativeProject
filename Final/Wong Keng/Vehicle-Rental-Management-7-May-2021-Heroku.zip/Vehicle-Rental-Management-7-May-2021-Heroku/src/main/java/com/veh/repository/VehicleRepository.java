package com.veh.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.veh.Vehicle;

@Repository
public interface VehicleRepository extends JpaRepository<Vehicle, Long> {
	
	Vehicle getVehByVehRegNum(String vehRegNum);
	Page<Vehicle> getVehByBrandAllIgnoreCase(String brand, Pageable page);
	Page<Vehicle> getVehByModelAllIgnoreCase(String model, Pageable page);
	Page<Vehicle> getVehByVehStatus(String vehStatus, Pageable page);
	Vehicle getVehByVehId(Long vehId);
	Page<Vehicle> findByVehRegNumAllIgnoreCase(String vehRegNum, Pageable page);

}
