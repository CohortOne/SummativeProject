package com.veh;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class Tax {
	
	public Tax(String gst) {
		super();
		this.gst = gst;
	}
	
	public Tax() {};

	@Value("${currentGST}")
	private String gst;

	public String getGst() {
		return gst;
	}

	public void setGst(String gst) {
		this.gst = gst;
	}

	@Override
	public String toString() {
		return "Tax [gst=" + gst + "]";
	}
	
}
