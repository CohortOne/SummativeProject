package com.veh;

import java.time.LocalDateTime;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.annotation.DateTimeFormat.ISO;

@Entity
@Table(name = "BOOKING")
public class Booking {	

	public Booking(Long bookId, LocalDateTime startDate, LocalDateTime expectedReturnDate,
			LocalDateTime actualReturnDate, String recordModifiedDate, String recordCreatedDate, Customer theCustomer,
			Users theUser, Vehicle theVehicle, double rate, int duration, double discount, double total) {
		super();
		this.bookId = bookId;
		this.startDate = startDate;
		this.expectedReturnDate = expectedReturnDate;
		this.actualReturnDate = actualReturnDate;
		this.recordModifiedDate = recordModifiedDate;
		this.recordCreatedDate = recordCreatedDate;
		this.theCustomer = theCustomer;
		this.theUser = theUser;
		this.theVehicle = theVehicle;
		this.rate = rate;
		this.duration = duration;
		this.discount = discount;
		this.total = total;
	}

	public Booking() {}
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "book_id")
	private Long bookId;
	
	@Column
	@DateTimeFormat(iso = ISO.DATE_TIME)
	private LocalDateTime startDate;
	
	@Column
	@DateTimeFormat(iso = ISO.DATE_TIME)
	private LocalDateTime expectedReturnDate;
	
	@Column
	@DateTimeFormat(iso = ISO.DATE_TIME)
	private LocalDateTime actualReturnDate;
	
	@Column
	private String recordModifiedDate;
	
	@Column
	private String recordCreatedDate;
	
	@ManyToOne 
	@JoinColumn(name = "customerId")
	private Customer theCustomer;
	
	@ManyToOne
	@JoinColumn(name = "employeeId")
	private Users theUser;
	
	@ManyToOne
	@JoinColumn(name = "vehicleId")
	private Vehicle theVehicle;
	
	@Column
	private double rate;
	
	@Column
	private int duration;
	
	@Column
	private double discount;
	
	@Column
	private double total;
	
	public Long getBookId() {
		return bookId;
	}

	public void setBookId(Long bookId) {
		this.bookId = bookId;
	}

	public LocalDateTime getStartDate() {
		return startDate;
	}

	public void setStartDate(LocalDateTime startDate) {
		this.startDate = startDate;
	}

	public LocalDateTime getExpectedReturnDate() {
		return expectedReturnDate;
	}

	public void setExpectedReturnDate(LocalDateTime expectedReturnDate) {
		this.expectedReturnDate = expectedReturnDate;
	}

	public LocalDateTime getActualReturnDate() {
		return actualReturnDate;
	}

	public void setActualReturnDate(LocalDateTime actualReturnDate) {
		this.actualReturnDate = actualReturnDate;
	}
	
	public String getRecordModifiedDate() {
		return recordModifiedDate;
	}

	public void setRecordModifiedDate(String recordModifiedDate) {
		this.recordModifiedDate = recordModifiedDate;
	}

	public String getRecordCreatedDate() {
		return recordCreatedDate;
	}

	public void setRecordCreatedDate(String recordCreatedDate) {
		this.recordCreatedDate = recordCreatedDate;
	}

	public Customer getTheCustomer() {
		return theCustomer;
	}

	public void setTheCustomer(Customer theCustomer) {
		this.theCustomer = theCustomer;
	}

	public Users getTheUser() {
		return theUser;
	}

	public void setTheUser(Users theUser) {
		this.theUser = theUser;
	}

	public Vehicle getTheVehicle() {
		return theVehicle;
	}

	public void setTheVehicle(Vehicle theVehicle) {
		this.theVehicle = theVehicle;
	}

	public double getRate() {
		return rate;
	}

	public void setRate(double rate) {
		this.rate = rate;
	}

	public int getDuration() {
		return duration;
	}

	public void setDuration(int duration) {
		this.duration = duration;
	}

	public double getDiscount() {
		return discount;
	}

	public void setDiscount(double discount) {
		this.discount = discount;
	}

	public double getTotal() {
		return total;
	}

	public void setTotal(double total) {
		this.total = total;
	}

	@Override
	public String toString() {
		return "Booking [bookId=" + bookId + ", startDate=" + startDate + ", expectedReturnDate=" + expectedReturnDate
				+ ", actualReturnDate=" + actualReturnDate + ", recordModifiedDate=" + recordModifiedDate
				+ ", recordCreatedDate=" + recordCreatedDate + ", rate=" + rate + ", duration=" + duration
				+ ", discount=" + discount + ", total=" + total + "]";
	}	
		
}


















