package com.veh.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.veh.Customer;
import com.veh.ItemNotFoundException;
import com.veh.Vehicle;
import com.veh.dao.CustomerDao;
import com.veh.dao.VehicleService;
import com.veh.repository.VehicleRepository;
import com.veh.utility.ImageFileUploadUtility;

@Controller
public class VehicleController {
	
	@Autowired
	private VehicleService vehicleService;
	
	@Autowired VehicleRepository vehicleRepository;
	
	@Autowired
	private CustomerDao customerDao;
		
	@GetMapping("/list_vehicles/{thisPage}")
	public String listVehicles(Model model, 
			@PathVariable(value="thisPage", required = false) Integer thisPage) {
		
		String sortDir = "asc";
		
		if (thisPage == null)
			thisPage = 1;
		else if (thisPage == -1) {
			thisPage = 1;
			sortDir = "desc";
		}			
		
		return listByPage(thisPage, "vehId", sortDir, model); //show latest vehicles by default
	
	}
	
	@GetMapping("/vehiclePage/{pageNumber}")
	public String listByPage(@PathVariable("pageNumber") int currentPage, 
							 @RequestParam("sortField") String sortField,
							 @RequestParam("sortDir") String sortDir,
							 Model model) {
		
		return listByVehAttributes(currentPage, sortField, sortDir, "dummy", "All", model);
		
	}
	
	@GetMapping("/new_vehicle")
	public String newVehicleCreation(Model model) {
		
		Vehicle theVehicle = new Vehicle();
		model.addAttribute("vehicle", theVehicle);
		return "new_vehicle";
	}
	
	@PostMapping("/saveVehicle")
	public String saveVehicle(@Valid @ModelAttribute("vehicle")Vehicle theVehicle, 
			BindingResult bindingResult,
			RedirectAttributes ra,
			@RequestParam("fileImage") MultipartFile multipartFile) throws IOException {
		
		if (bindingResult.hasErrors())
			return "new_vehicle";
		
//		Saving the Vehicle Object to get the vehId
		Vehicle savedVeh = vehicleService.saveTemp4ID(theVehicle);
		
//		If multipartFile is empty just save the vehicle object to DB
		
		if (!multipartFile.isEmpty()) {
//			Upload car image
			ImageFileUploadUtility imageFileUploadUtility = new ImageFileUploadUtility();
			
			savedVeh = imageFileUploadUtility.upLoadImageFile(savedVeh, multipartFile);
		}	
		
//		System.out.println("savedVeh : " + savedVeh);
		
		vehicleService.save(savedVeh);
		
        ra.addFlashAttribute("message", "Record for Vehicle Registration Number, " + savedVeh.getVehRegNum() + ", Sucessfully Saved.");
        
//		vehicleService.save(theVehicle);				
		return "redirect:/list_vehicles/-1";
	}
		
	@PostMapping("/saveModifiedVehicle/{thisPage}")
	public String saveVehicle(@Valid @ModelAttribute("vehicle")Vehicle theVehicle,
			@RequestParam("currentImageFileName")String currentImageFileName,
			@PathVariable(value="thisPage") Integer thisPage,
			BindingResult bindingResult,
			RedirectAttributes ra,
			@RequestParam("fileImage") MultipartFile multipartFile) throws IOException {
		
		if (bindingResult.hasErrors())
			return "update_vehicle";
		
//		System.out.println("saveModifiedVehicle() - currentImageFileName : " + currentImageFileName);
				
//		Saving the Vehicle Object to get the vehId
		Vehicle savedVeh = vehicleService.saveTemp4ID(theVehicle);
		
//		If multipartFile is empty just save the vehicle object to DB
		
		ImageFileUploadUtility imageFileUploadUtility = new ImageFileUploadUtility();
		
		if (!multipartFile.isEmpty()) {
//			Upload car image					
			savedVeh = imageFileUploadUtility.upLoadImageFile(savedVeh, multipartFile);			
		}	
		else {
			
//			Set back original image filename (only if exists) since user did not upload a new image file	and save Vehicle object	
			if (!(currentImageFileName.equals("NoImageFileFound")))
				savedVeh = imageFileUploadUtility.upLoadOriginalImageFile(savedVeh, currentImageFileName);	
		}
		
		vehicleService.save(savedVeh);

//		System.out.println("savedModifiedVeh : " + savedVeh);
				
        ra.addFlashAttribute("message", "Record for Vehicle Registration Number, " + savedVeh.getVehRegNum() + ", Sucessfully Updated.");
        
//		vehicleService.save(theVehicle);				
		return "redirect:/list_vehicles/" + thisPage;
	}
		
	@GetMapping("/showFormToUpdateVehicle/{thisPage}")
	public String showFormToUpdateVehicle(@RequestParam("vehId") Long id, 
			@PathVariable(value="thisPage") Integer thisPage,
			Model model) {
		
		// Get Vehicle from the Service 
		Vehicle theVehicle = vehicleService.findById(id);
		
		String currentImageFileName = theVehicle.getVehImage();
		
//		System.out.println("showFormToUpdateVehicle()");
//		System.out.println("currentImageFileName : " + currentImageFileName);
//		System.out.println("theVehicle fileName : " + theVehicle.getVehImage());
//		System.out.println("theVehicle ImagePath : " + theVehicle.vehicleImagePath());
		
		// set vehicle as a model attribute to pre-populate the form and make a copy of the image filename if available
		model.addAttribute("vehicle", theVehicle);
		model.addAttribute("thisPage", thisPage);
		
		if (currentImageFileName != null)
			model.addAttribute("currentImageFileName", currentImageFileName);
		else
			model.addAttribute("currentImageFileName", "NoImageFileFound");
			
		return "update_vehicle";
		
	}
		
	@GetMapping("/deleteVehicle")
	public String deleteVehicle(@RequestParam("vehId") Long theId,
								RedirectAttributes ra) {
		
//		get Vehicle Registration Number
		Vehicle theVeh = vehicleRepository.getVehByVehId(theId);
		String regNum = theVeh.getVehRegNum();
			 
//		call delete vehicle method 
		this.vehicleService.deleteById(theId);
		
		ra.addFlashAttribute("message", "Record for Vehicle Registration Number, " + regNum + ", Sucessfully Deleted.");
		
		return "redirect:/list_vehicles/1";
	}
	
	@GetMapping("/showVehSelectPage")
	public String showVehSelectPage(@RequestParam("custId") Long custId, 
									 Model model) {
		
		Customer customer = new Customer();
		List<Vehicle> vehicles = new ArrayList<>();
		
//		Get all vehicles and assign to "vehicles" attribute and 
//		assign selected customer to "customer" attribute
		vehicles = vehicleService.findAll();
		model.addAttribute("listVehicles", vehicles);
		
		customer = customerDao.getCustomerById(custId);
		model.addAttribute(customer);
		
		return "select_vehicle";
	}
	
	@GetMapping("/getVehicleByRegNum")
	public String getVehicleByRegNum(Model model) {
		
		Vehicle theVehicle = new Vehicle();
		model.addAttribute("vehicle", theVehicle);
		
		return "search_vehicle_by_vehicle_registration_number";
	}
	
	@PostMapping("/searchVehDetailsByRegNum")
	public String searchVehicleDetailsByRegNum(@Valid @ModelAttribute("vehicle")Vehicle theVehicle,
												Model model) {
		
		String selectedProperty = theVehicle.getVehRegNum();
		String selectedOption = "RegNum";
		model.addAttribute("empty", "empty");
		
		return listByVehAttributes(1, "vehId", "asc", selectedProperty, selectedOption, model);
	}
	
	@GetMapping("/getVehicleByBrand")
	public String getVehicleByBrand(Model model) {
		
		Vehicle theVehicle = new Vehicle();
		model.addAttribute("vehicle", theVehicle);
		
		return "search_vehicle_by_vehicle_brand";
	}
	
	@PostMapping("/searchVehByBrand")
	public String searchVehicleByBrand(@Valid @ModelAttribute("vehicle")Vehicle theVehicle,
									  Model model) {
		
		String selectedModel = theVehicle.getBrand();
		String selectedOption = "Brand";
		
		return listByVehAttributes(1, "vehId", "asc", selectedModel, selectedOption, model);
	}
	
	@GetMapping("/getVehicleByModel")
	public String getVehicleByModel(Model model) {
		
		Vehicle theVehicle = new Vehicle();
		model.addAttribute("vehicle", theVehicle);
		
		return "search_vehicle_by_vehicle_model";
	}
	
	@PostMapping("/searchVehByModel")
	public String searchVehicleByModel(@Valid @ModelAttribute("vehicle")Vehicle theVehicle,
									 Model model) {
		
		String selectedModel = theVehicle.getModel();
		String selectedOption = "Model";
		
		return listByVehAttributes(1, "vehId", "asc", selectedModel, selectedOption, model);
		
	}
	
	@GetMapping("/vehiclePageByAttribute/{pageNumber}")
	public String listByVehAttributes(@PathVariable("pageNumber") int currentPage, 
							 @RequestParam("sortField") String sortField,
							 @RequestParam("sortDir") String sortDir,
							 @RequestParam("selectedProperty")String selectedProperty,
							 @RequestParam("selectedOption")String selectedOption,
							 Model model) {
		
		Sort sort = Sort.by(sortField);
		sort = sortDir.equals("asc") ? sort.ascending() : sort.descending();
		
		Pageable paging = PageRequest.of(currentPage-1, 5, sort); //maximum of 5 items per page
		
		Page<Vehicle> page = null;
		
		model.addAttribute("selectedOption", selectedOption);
		model.addAttribute("selectedProperty", selectedProperty);
		
		switch (selectedOption) {
			case "All":
				page = vehicleRepository.findAll(paging);
				break;
			
			case "RegNum":
				page = vehicleRepository.findByVehRegNumAllIgnoreCase(selectedProperty, paging);
				
//				if no record found, throw exception
				if (page.isEmpty()) {
					throw new ItemNotFoundException("No Vehicle record found for "
							+ "Registration Number : " + selectedProperty, "/getVehicleByRegNum");
				}

				break;
			
			case "Model":
				page = vehicleRepository.getVehByModelAllIgnoreCase(selectedProperty, paging);
				
//				if no record found, throw exception
				if (page.isEmpty()) {
					throw new ItemNotFoundException("No Vehicle records found for "
							+ "Model : " + selectedProperty, "/getVehicleByModel");
				}

				break;
				
			case "Brand":
				page = vehicleRepository.getVehByBrandAllIgnoreCase(selectedProperty, paging);
				
//				if no record found, throw exception
				if (page.isEmpty()) {
					throw new ItemNotFoundException("No Vehicle records found for "
							+ "Brand : " + selectedProperty, "/getVehicleByBrand");
				}

				break;
				
			case "Availability":
				page = vehicleRepository.getVehByVehStatus(selectedProperty, paging);
				break;
				
//			default:
//				System.out.println("listByVehAttributes() - at default");
//				page = vehicleService.findAll(currentPage, sortField, sortDir);
//				break;
		}
		
		int totalPages = page.getTotalPages();
		long totalItems = page.getTotalElements();
		
		List<Vehicle> listVehicles = page.getContent();
		
		model.addAttribute("listVehicles", listVehicles);
		model.addAttribute("currentPage", currentPage);
		model.addAttribute("totalItems", totalItems);
		model.addAttribute("totalPages", totalPages);
		model.addAttribute("sortField", sortField);
		model.addAttribute("sortDir", sortDir);
				
		String reverseSortDir = sortDir.equals("asc") ? "desc" : "asc";
		model.addAttribute("reverseSortDir", reverseSortDir);
		
		return "list_vehicles_by_attribute";
	}
	
	@GetMapping("/getVehicleByStatus")
	public String getVehicleByStatus(Model model) {
		
		Vehicle theVehicle = new Vehicle();
		model.addAttribute("vehicle", theVehicle);
		
		return "search_vehicle_by_vehicle_status";
	}
	
	@PostMapping("/searchVehByStatus")
	public String searchVehicleByStatus(@Valid @ModelAttribute("vehicle")Vehicle theVehicle,
												Model model) {
		
		String selectedModel = theVehicle.getVehStatus();
		String selectedOption = "Availability";
		
		return listByVehAttributes(1, "vehId", "asc", selectedModel, selectedOption, model);
		
	}
	
	@GetMapping("/displayChosenVeh")
	public String displayChosenVeh(@RequestParam("vehId")Long vehId, 
			@RequestParam("currentPage")Integer currentPage,
			Model model) {
		
		model.addAttribute("empty", "empty");
		Vehicle theVehicle = vehicleService.findById(vehId);
		
		return searchVehicleDetailsByRegNumFromBooking(theVehicle, currentPage, model);
	}
	
	@GetMapping("/searchVehicleDetailsByRegNumFromBooking")
	public String searchVehicleDetailsByRegNumFromBooking(@Valid @ModelAttribute("vehicle")Vehicle theVehicle,
												Integer currentPage,
												Model model) {
		
		model.addAttribute("currentPage", currentPage);
		model.addAttribute("veh", theVehicle);
		
		return "list_single_vehicle";
	}
	
}
