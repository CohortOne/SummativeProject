package com.veh.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.repository.query.Param;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.veh.Booking;
import com.veh.Customer;
import com.veh.ItemNotFoundException;
import com.veh.Tax;
import com.veh.Users;
import com.veh.Vehicle;
import com.veh.dao.BookingService;
import com.veh.dao.CustomerDao;
import com.veh.dao.UserService;
import com.veh.dao.VehicleService;
import com.veh.repository.BookingRepository;
import com.veh.repository.CustomerRepository;
import com.veh.repository.UserRepository;
import com.veh.repository.VehicleRepository;

@Controller
public class BookingController {
	
	@Autowired
	private BookingService bookingService;
	
	@Autowired
	private BookingRepository bookingRepository;
	
	@Autowired
	private CustomerDao customerDao;
	
	@Autowired
	private CustomerRepository customerRepository;
	
	@Autowired
	private VehicleService vehicleService;
	
	@Autowired
	VehicleRepository vehicleRepository;
	
	@Autowired
	private UserService userService;
	
	@Autowired
	private UserRepository userRepository;
	
	@Autowired
	private Tax tax;
	
	@GetMapping("/list_booking/{thisPage}")
	public String listBooking(Model model, 
			@PathVariable(value="thisPage", required = false) Integer thisPage) {
		
		if (thisPage == null)
			thisPage = 1;
		
		return listByPage(thisPage, "bookId", "desc", model); //show latest booking by default
	}
	
	@GetMapping("/bookingPage/{pageNumber}")
	public String listByPage(@PathVariable("pageNumber") int currentPage, 
							 @RequestParam("sortField") String sortField,
							 @RequestParam("sortDir") String sortDir,
							 Model model) {
		
		return listByBookingAttributes(currentPage, sortField, sortDir, "dummy", "All", 0L, model);
	}
	
	@GetMapping("/showFormForBooking")
	public String showFormForBooking(@RequestParam Long custId, 
									 @RequestParam Long vehId, Model model) {
//		Get selected Employee from Service 
		Customer theCustomer = customerDao.getCustomerById(custId);
		
//		Get selected Vehicle from Service
		Vehicle theVehicle = vehicleService.findById(vehId);
		
//		Get current GST percentage
		Double gst = Double.valueOf(tax.getGst());
		
//		// set employee, vehicle and booking using model attribute to pre-populate the form 
		model.addAttribute("customer", theCustomer);
		model.addAttribute("vehicle", theVehicle);
		model.addAttribute("gst", gst);
		
		Booking theBooking = new Booking();
		model.addAttribute("booking", theBooking);
		
//		System.out.println("Here in showFormForBooking()\n Customer: " + theCustomer + "\n"
//				+ "Vehicle: " + theVehicle + "Booking: " + theBooking);
//		
		return "new_booking_form";
	}
	
	@PostMapping("/saveBooking")  //save method for new bookings
	public String saveBooking(@Valid @ModelAttribute("booking")Booking theBooking,
			@Valid @ModelAttribute("customer")Customer theCustomer,
			@Valid @ModelAttribute("vehicle")Vehicle theVehicle,
			BindingResult bindingResult,
			RedirectAttributes ra) {
		
//		System.out.println("saveBooking() booking : " + theBooking);
//		System.out.println("saveBooking() customer : " + theCustomer);
//		System.out.println("saveBooking() vehicle : " + theVehicle);
		
		if (bindingResult.hasErrors())
			return "new_booking_form";
				
//		Calling static method to retrieve agent's username and ID
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		String currentPrincipalName = authentication.getName();
		Long theUserId = userRepository.getIdByUsername(currentPrincipalName);
		
//		System.out.println("currentPrincipalName : " + currentPrincipalName);
//		System.out.println("theUserId : " + theUserId);
		
		Users tempUser = userService.findById(theUserId);
		Customer tempCust = customerDao.getCustomerById(theCustomer.getCustId());
		Vehicle tempVeh = vehicleService.findById(theVehicle.getVehId());
		
//		Set Vehicle Status to "Unavailable" **Need to cater for vehicle return**		
		tempVeh.setVehStatus("Unavailable");
		
//		Add booking to customer and vehicle
		tempCust.add_booking(theBooking);
		tempVeh.add_booking(theBooking);
		tempUser.add_booking(theBooking);
		
//		Save the Booking object
		bookingService.save(theBooking);
		
		ra.addFlashAttribute("message", "Booking ID " + theBooking.getBookId() + " Successfully Saved.");
		
		return "redirect:/list_booking/1";
	}
	
	@PostMapping("/saveModifiedBooking/{thisPage}")
	public String saveBooking(@Valid @ModelAttribute("booking")Booking theBooking,
			@PathVariable(value="thisPage") Integer thisPage,
			BindingResult bindingResult,
			RedirectAttributes ra) {
		
		if (bindingResult.hasErrors())
			return "update_booking_form";
		
//		System.out.println("saveModifiedBooking Booking : " + theBooking);
				
//		Save the new Booking object
		bookingService.save(theBooking);
		
		ra.addFlashAttribute("message", "Booking ID " + theBooking.getBookId() + " Successfully Updated.");
		
		return "redirect:/list_booking/" + thisPage;
	}
	
	@PostMapping("/saveReturnedBooking/{thisPage}")
	public String saveReturnedBooking(@Valid @ModelAttribute("booking")Booking theBooking,
			@PathVariable(value="thisPage") Integer thisPage,
			BindingResult bindingResult,
			RedirectAttributes ra) {
		
		if (bindingResult.hasErrors())
			return "return_vehicle_form";
		
//		Get required Vehicle object
		Vehicle theVehicle = vehicleService.findById(theBooking.getTheVehicle().getVehId());
		
//		Set returned vehicle status to "Available"
		theVehicle.setVehStatus("Available");

//		Save update vehicle object with updated status
		vehicleService.save(theVehicle);
		
//		Save the Booking object
		bookingService.save(theBooking);
				
		ra.addFlashAttribute("message", "Booking ID " + theBooking.getBookId() + " Successfully Saved and Closed.");
		
		return "redirect:/list_booking/" + thisPage;
	}
	
	@GetMapping("/showFormForBookingUpdate/{bookId}/{thisPage}")
	public String showFormForBookingUpdate(@PathVariable(value="bookId") Long bookId, 
			@PathVariable(value="thisPage") Integer thisPage, 
			Model model) {
		
		//Get booking record based on bookId
		Booking theBooking = bookingService.findById(bookId);
		
//		Get current GST percentage
		Double gst = Double.valueOf(tax.getGst());
		
		//setup model attributes
		model.addAttribute("booking", theBooking);
		model.addAttribute("thisPage", thisPage);
		model.addAttribute("gst", gst);
		
		return "update_booking_form";
	}
	
	@GetMapping("/deleteBooking")
	public String deleteBooking(@RequestParam("bookId") long bookId,
								RedirectAttributes ra) {

	 int status = bookingService.deleteBooking(bookId);
	 
//	 System.out.println("deleteBooking() status : " + status);
	 
	 if (status > 0)
		 ra.addFlashAttribute("message", "Booking ID " + bookId + " successfully DELETED.");
	 else
		 throw new ItemNotFoundException("No Booking record deleted for Booking ID : " + bookId);
	 
		 return "redirect:/list_booking/1"; //return to Page 1 of Booking
	}
	
	@GetMapping("/return_vehicle/{bookId}/{thisPage}")
	public String returnVehicle(@PathVariable(value="bookId") Long bookId, 
			@PathVariable(value="thisPage") Integer thisPage,
			Model model) {
		
		//Get booking record based on bookId
		Booking theBooking = bookingService.findById(bookId);
		
//		Get current GST percentage
		Double gst = Double.valueOf(tax.getGst());
		
		//setup model attributes
		model.addAttribute("booking", theBooking);
		model.addAttribute("thisPage", thisPage);
		model.addAttribute("gst", gst);

		return "return_vehicle_form";		
	}
	
	@GetMapping("/getBookingByBookId")
	public String getBookingByBookId(Model model) {
		
		Booking theBooking = new Booking();
		
		model.addAttribute("booking", theBooking);
		
		return "search_booking_by_bookId";
	}
	
	@PostMapping("/searchBookingByBookId")
	public String searchBookingByBookId(@Valid @ModelAttribute("booking")Booking theBooking,
			Model model) {
					
		String selectedModel = "dummy"; //dummy data
		String selectedOption = "BookID";
		
		long bookingId = theBooking.getBookId();
		model.addAttribute("empty", "empty");
		
		return listByBookingAttributes(1, "bookId", "desc", selectedModel, selectedOption, bookingId, model);
	}
	
	@GetMapping("/getCustomerByName")
	public String getCustomerByName(Model model) {
		
		Customer theCustomer = new Customer();
		
		model.addAttribute("customer", theCustomer);
		return "search_booking_by_customer_name";
	}
	
	@PostMapping("/searchBookingByCustName")
	public String searchBookingByCustName(@Valid @ModelAttribute("customer")Customer theCustomer,
			Model model) {
		
		//get required customer object based on First and Last Names.
		Customer tempCustomer = customerDao.getCustByFirstNameAndLastName(theCustomer.getFirstName(), theCustomer.getLastName());

//		if no record found, throw exception
		if (tempCustomer == null) {
			throw new ItemNotFoundException("No Booking records found under Customer : " 
					+ theCustomer.getFirstName() + " " + theCustomer.getLastName(), "/getCustomerByName");
		}

//		System.out.println("Customer Object : " + tempCustomer);
		
		String selectedModel = theCustomer.getFirstName();
		String selectedOption = "Name";
		Long custId = tempCustomer.getCustId();
		
		model.addAttribute("tempCustomer", tempCustomer);
		
		return listByBookingAttributes(1, "bookId", "desc", selectedModel, selectedOption, custId, model);
	}
	
	@GetMapping("/getCustomerByEmail")
	public String getCustomerByEmail(Model model) {
		
		Customer theCustomer = new Customer();
		
		model.addAttribute("customer", theCustomer);
		return "search_booking_by_customer_email";
	}
	
	@PostMapping("/searchBookingByCustEmail")
	public String searchBookingByCustEmail(@Valid @ModelAttribute("customer")Customer theCustomer,
			Model model) {
		
		//get required customer object based on given email
		Customer tempCustomer = customerDao.getCustByEmail(theCustomer.getEmail());

//		if no record found, throw exception
		if (tempCustomer == null) {
			throw new ItemNotFoundException("No Booking records found under Email Address : " 
					+ theCustomer.getEmail(), "/getCustomerByEmail");
		}

//		System.out.println("Customer Object : " + tempCustomer);
		
//		//Get a list of bookings made by the identified customer
//		List<Booking> tempBooking = bookingService.getBookingForIdentifiedCustomer(tempCustomer);
		
		String selectedModel = theCustomer.getEmail();
		String selectedOption = "Email";
		Long custId = tempCustomer.getCustId();
		
		model.addAttribute("tempCustomer", tempCustomer);
		
		return listByBookingAttributes(1, "bookId", "desc", selectedModel, selectedOption, custId, model);
	}
	
	@GetMapping("/getCustomerByDrvLicNum")
	public String getCustomerByDrvLicNum(Model model) {
		
		Customer theCustomer = new Customer();
		
		model.addAttribute("customer", theCustomer);
		return "search_booking_by_customer_driving_lic_number";
	}
	
	@PostMapping("/searchBookingByCustDrvLicNum")
	public String searchBookingByCustDrvLicNum(@Valid @ModelAttribute("customer")Customer theCustomer,
			Model model) {
		
		//get required customer object based on given email
		Customer tempCustomer = customerDao.getCustByDrivingLicNum(theCustomer.getDrivingLicNum());
		
//		if no record found, throw exception
		if (tempCustomer == null) {
			throw new ItemNotFoundException("No Booking records found under Driving License Number : " 
					+ theCustomer.getDrivingLicNum(), "/getCustomerByDrvLicNum");
		}
		
		String selectedModel = theCustomer.getDrivingLicNum();
		String selectedOption = "DrivingLicense";
		Long custId = tempCustomer.getCustId();
		
//		System.out.println("Customer Object : " + tempCustomer);
		
		model.addAttribute("tempCustomer", tempCustomer);
		
		return listByBookingAttributes(1, "bookId", "desc", selectedModel, selectedOption, custId, model);
	}
	
	@GetMapping("/getVehicleObjByRegNum")
	public String getVehicleObjByRegNum(Model model) {
		
		Vehicle theVehicle = new Vehicle();
		
		model.addAttribute("vehicle", theVehicle);
		
		return "search_booking_by_vehicle_registration_num";
	}
	
	@PostMapping("/searchBookingByVehicleRegNum")
	public String searchBookingByVehicleRegNum(@Valid @ModelAttribute("vehicle")Vehicle theVehicle,
			Model model) {
		
		//get required vehicle object based on Vehicle Registration Number.
		
		Vehicle tempVehicle = vehicleService.findByRegNum(theVehicle.getVehRegNum());
		
//		if no record found, throw exception
		if (tempVehicle == null) {
			throw new ItemNotFoundException("No Booking records found under Vehicle Registration Number : " 
					+ theVehicle.getVehRegNum(), "/getVehicleObjByRegNum");
		}

		String selectedModel = theVehicle.getModel();
		String selectedOption = "VehicleRegNum";
		Long vehId = tempVehicle.getVehId();
		
		model.addAttribute("tempVehicle", tempVehicle);
		
		return listByBookingAttributes(1, "bookId", "desc", selectedModel, selectedOption, vehId, model);
	}
	
	@PostMapping("/searchBookingByUserName")
	public String searchBookingByUserName(@Valid @ModelAttribute("user")Users theUser,
			Model model) {
		
		//get required user object based on First and Last Names.
		Users tempUser = userRepository.getUserByFirstNameAndLastNameAllIgnoreCase(theUser.getFirstName(), theUser.getLastName());
		
//		if no record found, throw exception
		if (tempUser == null) {			
			throw new ItemNotFoundException("No User record found under Name : " 
					+ theUser.getFirstName() + " " + theUser.getLastName(), 
					"/getUserByNameForBookings");
		}

		String selectedModel = "dummy";
		String selectedOption = "UserName";
		Long userId = tempUser.getId();
		
		model.addAttribute("empty", "empty");
				
		return listByBookingAttributes(1, "bookId", "desc", selectedModel, selectedOption, userId, model);

	}
	
	@GetMapping("/bookingPageByAttribute/{pageNumber}")
	public String listByBookingAttributes(@PathVariable("pageNumber") int currentPage, 
							 @RequestParam("sortField") String sortField,
							 @RequestParam("sortDir") String sortDir,
							 @RequestParam("selectedProperty")String selectedProperty,
							 @RequestParam("selectedOption")String selectedOption,
							 @RequestParam("objectId")Long objectId,
							 Model model) {
		
		Sort sort = Sort.by(sortField);
		sort = sortDir.equals("asc") ? sort.ascending() : sort.descending();
		
		Pageable paging = PageRequest.of(currentPage-1, 5, sort); //maximum of 5 items per page
		
//		Initialise variables
		Page<Booking> page = null;
		Vehicle tempVehicle = null;
		Customer tempCustomer = null;
		Users tempUser = null;
		
//		Test if the search is by customer or by vehicle information		
		if (selectedOption.equals("VehicleRegNum"))
			tempVehicle = vehicleRepository.getVehByVehId(objectId);
		else if (selectedOption.equals("UserName"))
			tempUser = userRepository.getUserById(objectId);
		else
			tempCustomer = customerRepository.getByCustId(objectId);
		
		model.addAttribute("objectId", objectId);
		model.addAttribute("selectedOption", selectedOption);
		model.addAttribute("selectedProperty", selectedProperty);
		
		switch (selectedOption) {
			case "All":
				page = bookingRepository.findAll(paging);
				break;
				
			case "BookID":
				page = bookingRepository.getPageByBookId(objectId, paging);
				
//				if no record found, throw exception
				if (page.isEmpty()) {
					throw new ItemNotFoundException("No Booking record found for Booking ID : " 
													+ objectId, "/getBookingByBookId");
				}
				break;
		
			case "VehicleRegNum":
				page = bookingRepository.getByTheVehicle(tempVehicle, paging);
				break;
				
			case "UserName":
				page = bookingRepository.getByTheUser(tempUser, paging);
				break;
				
			default:
				page = bookingRepository.getByTheCustomer(tempCustomer, paging);
				break;			
		}
		
		int totalPages = page.getTotalPages();
		long totalItems = page.getTotalElements();
		
		List<Booking> listBookings = page.getContent();
		
		model.addAttribute("listBookings", listBookings);
		model.addAttribute("currentPage", currentPage);
		model.addAttribute("totalItems", totalItems);
		model.addAttribute("totalPages", totalPages);
		model.addAttribute("sortField", sortField);
		model.addAttribute("sortDir", sortDir);
		
//		System.out.println("selectedOption = " + model.getAttribute("selectedOption"));
//		System.out.println("selectedProperty = " + model.getAttribute("selectedProperty"));
				
		String reverseSortDir = sortDir.equals("asc") ? "desc" : "asc";
		model.addAttribute("reverseSortDir", reverseSortDir);
		
		return "list_bookings_by_attribute";
	}

}
