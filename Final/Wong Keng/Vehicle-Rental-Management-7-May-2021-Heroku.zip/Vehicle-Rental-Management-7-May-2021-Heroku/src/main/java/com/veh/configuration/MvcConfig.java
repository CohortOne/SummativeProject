package com.veh.configuration;

import java.io.File;
import java.nio.file.Path;
import java.nio.file.Paths;

import org.springframework.boot.system.ApplicationHome;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class MvcConfig implements WebMvcConfigurer {

	@Override
	public void addResourceHandlers(ResourceHandlerRegistry registry) {
		
//		Resource location for car images
		
//		get path to src/main/resources/static/img
		Path resourceDirectory = Paths.get("src","main","resources", "static", "img");
		String absolutePath = resourceDirectory.toFile().getAbsolutePath();
        
//      Vehicle images home directory
        String vehImageHome = absolutePath + "/vehicle-photos";
        
		Path imageUploadDir = Paths.get(vehImageHome);
		
		String imageUploadPath = imageUploadDir.toFile().getAbsolutePath();
		
		String carImages = "file://" + imageUploadPath + "/";
		
//      Identity Proof images home directory
        String custImageHome = absolutePath + "/customer-photos";      

//		Resource location for customer-related images
		imageUploadDir = Paths.get(custImageHome);
		
		imageUploadPath = imageUploadDir.toFile().getAbsolutePath();
		
		String customerProofImages = "file://" + imageUploadPath + "/";
		
//		registry.addResourceHandler("/Volumes/Toshiba-4TB/sumPrj-photos/vehicle-photos/**",
//				"/Volumes/Toshiba-4TB/sumPrj-photos/customer-photos/**")
//			.addResourceLocations(carImages, customerProofImages);
		
		registry.addResourceHandler(vehImageHome + "/**", 
				custImageHome + "/**")
			.addResourceLocations(carImages, customerProofImages);
						
	}
	
}
