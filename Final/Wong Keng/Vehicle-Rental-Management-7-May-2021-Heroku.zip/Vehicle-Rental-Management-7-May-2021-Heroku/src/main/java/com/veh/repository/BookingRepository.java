package com.veh.repository;

import java.util.List;
import java.util.Map;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.veh.Booking;
import com.veh.Customer;
import com.veh.Users;
import com.veh.Vehicle;

@Repository
public interface BookingRepository extends JpaRepository<Booking, Long> {
	
	@Transactional
	@Modifying
	int deleteByBookId(Long bookId);

//	@Query statements updated with Postgresql specific date functions
	
	Page<Booking> getByTheVehicle(Vehicle vehicle, Pageable page);
	Page<Booking> getByTheCustomer(Customer customer, Pageable page);
	Page<Booking> getByTheUser(Users user, Pageable page);
	Booking getByBookId(Long bookId);
	Page<Booking> getPageByBookId(Long bookId, Pageable page);

//Line Charts
	@Query(value="SELECT to_char(Actual_Return_Date, 'YYYY-MM'), count(*) "
			+ "FROM booking b \n"
			+ "where b.Actual_Return_Date >= current_date - interval '3 months'\n"
			+ "GROUP BY to_char(Actual_Return_Date, 'YYYY-MM')\n"
			+ "ORDER BY to_char(Actual_Return_Date, 'YYYY-MM')", nativeQuery = true)
	List<Object[]> getMonthlyBookingDataFromDB_3();
	
	@Query(value="SELECT to_char(Actual_Return_Date, 'YYYY-MM'), count(*) "
			+ "FROM booking b \n"
			+ "where b.Actual_Return_Date >= current_date - interval '6 months'\n"
			+ "GROUP BY to_char(Actual_Return_Date, 'YYYY-MM')\n"
			+ "ORDER BY to_char(Actual_Return_Date, 'YYYY-MM')", nativeQuery = true)
	List<Object[]> getMonthlyBookingDataFromDB_6();
	
	@Query(value="SELECT to_char(Actual_Return_Date, 'YYYY-MM'), count(*) "
			+ "FROM booking b \n"
			+ "where b.Actual_Return_Date >= current_date - interval '9 months'\n"
			+ "GROUP BY to_char(Actual_Return_Date, 'YYYY-MM')\n"
			+ "ORDER BY to_char(Actual_Return_Date, 'YYYY-MM')", nativeQuery = true)
	List<Object[]> getMonthlyBookingDataFromDB_9();

	@Query(value="SELECT to_char(Actual_Return_Date, 'YYYY-MM'), count(*) "
			+ "FROM booking b \n"
			+ "where b.Actual_Return_Date >= current_date - interval '12 months'\n"
			+ "GROUP BY to_char(Actual_Return_Date, 'YYYY-MM')\n"
			+ "ORDER BY to_char(Actual_Return_Date, 'YYYY-MM')", nativeQuery = true)
	List<Object[]> getMonthlyBookingDataFromDB_12();

		
	@Query(value="SELECT to_char(Actual_Return_Date, 'YYYY-MM'), sum(b.total) "
			+ "FROM booking b \n"
			+ "where b.Actual_Return_Date >= current_date - interval '3 months'\n"
			+ "GROUP BY to_char(Actual_Return_Date, 'YYYY-MM')\n"
			+ "ORDER BY to_char(Actual_Return_Date, 'YYYY-MM')", nativeQuery = true)
	List<Object[]> getMonthlyRevenueDataFromDB_3();
	
	@Query(value="SELECT to_char(Actual_Return_Date, 'YYYY-MM'), sum(b.total) "
			+ "FROM booking b \n"
			+ "where b.Actual_Return_Date >= current_date - interval '6 months'\n"
			+ "GROUP BY to_char(Actual_Return_Date, 'YYYY-MM')\n"
			+ "ORDER BY to_char(Actual_Return_Date, 'YYYY-MM')", nativeQuery = true)
	List<Object[]> getMonthlyRevenueDataFromDB_6();

	@Query(value="SELECT to_char(Actual_Return_Date, 'YYYY-MM'), sum(b.total) "
			+ "FROM booking b \n"
			+ "where b.Actual_Return_Date >= current_date - interval '9 months'\n"
			+ "GROUP BY to_char(Actual_Return_Date, 'YYYY-MM')\n"
			+ "ORDER BY to_char(Actual_Return_Date, 'YYYY-MM')", nativeQuery = true)
	List<Object[]> getMonthlyRevenueDataFromDB_9();

	@Query(value="SELECT to_char(Actual_Return_Date, 'YYYY-MM'), sum(b.total) "
			+ "FROM booking b \n"
			+ "where b.Actual_Return_Date >= current_date - interval '12 months'\n"
			+ "GROUP BY to_char(Actual_Return_Date, 'YYYY-MM')\n"
			+ "ORDER BY to_char(Actual_Return_Date, 'YYYY-MM')", nativeQuery = true)
	List<Object[]> getMonthlyRevenueDataFromDB_12();

//Pie Charts		
	@Query(value="select model, count(*)\n"
			+ "from booking b\n"
			+ "inner join vehicle on\n"
			+ "vehicle.veh_id = b.vehicle_id\n"
			+ "where b.Actual_Return_Date >= current_date - interval '3 Months'\n"
			+ "group by model", nativeQuery = true)
	List<Object[]> getVehicleCountByModelFromDB_3();
	
	@Query(value="select model, sum(total)\n"
			+ "from booking b\n"
			+ "inner join vehicle on\n"
			+ "vehicle.veh_id = b.vehicle_id\n"
			+ "where b.Actual_Return_Date >= current_date - interval '3 Months'\n"
			+ "group by model", nativeQuery = true)
	List<Object[]> getRevenueByModelFromDB_3();
	
	@Query(value="select model, count(*)\n"
			+ "from booking b\n"
			+ "inner join vehicle on\n"
			+ "vehicle.veh_id = b.vehicle_id\n"
			+ "where b.Actual_Return_Date >= current_date - interval '6 Months'\n"
			+ "group by model", nativeQuery = true)
	List<Object[]> getVehicleCountByModelFromDB_6();
	
	@Query(value="select model, sum(total)\n"
			+ "from booking b\n"
			+ "inner join vehicle on\n"
			+ "vehicle.veh_id = b.vehicle_id\n"
			+ "where b.Actual_Return_Date >= current_date - interval '6 Months'\n"
			+ "group by model", nativeQuery = true)
	List<Object[]> getRevenueByModelFromDB_6();

	@Query(value="select model, count(*)\n"
			+ "from booking b\n"
			+ "inner join vehicle on\n"
			+ "vehicle.veh_id = b.vehicle_id\n"
			+ "where b.Actual_Return_Date >= current_date - interval '9 Months'\n"
			+ "group by model", nativeQuery = true)
	List<Object[]> getVehicleCountByModelFromDB_9();
	
	@Query(value="select model, sum(total)\n"
			+ "from booking b\n"
			+ "inner join vehicle on\n"
			+ "vehicle.veh_id = b.vehicle_id\n"
			+ "where b.Actual_Return_Date >= current_date - interval '9 Months'\n"
			+ "group by model", nativeQuery = true)
	List<Object[]> getRevenueByModelFromDB_9();

	@Query(value="select model, count(*)\n"
			+ "from booking b\n"
			+ "inner join vehicle on\n"
			+ "vehicle.veh_id = b.vehicle_id\n"
			+ "where b.Actual_Return_Date >= current_date - interval '12 Months'\n"
			+ "group by model", nativeQuery = true)
	List<Object[]> getVehicleCountByModelFromDB_12();
	
	@Query(value="select model, sum(total)\n"
			+ "from booking b\n"
			+ "inner join vehicle on\n"
			+ "vehicle.veh_id = b.vehicle_id\n"
			+ "where b.Actual_Return_Date >= current_date - interval '12 Months'\n"
			+ "group by model", nativeQuery = true)
	List<Object[]> getRevenueByModelFromDB_12();

}