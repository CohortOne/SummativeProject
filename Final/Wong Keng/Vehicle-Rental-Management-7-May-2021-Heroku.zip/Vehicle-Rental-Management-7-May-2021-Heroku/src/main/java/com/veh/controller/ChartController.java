package com.veh.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.veh.repository.BookingRepository;

@Controller
public class ChartController {
	
	@Autowired
	BookingRepository bookingRepository;
	
	@GetMapping("/mgt_bookings_reporting")
	public String mgtReporting() {		
		return "mgt_bookings_by_month";
	}
	
	@GetMapping("/mgt_bookings_bycarModels_reporting")
	public String mgtReportingByCarModels() {
		return "mgt_bookings_by_carModels";
	}
	
//Line Charts
	@GetMapping("/mgt_showLineChart4Bookings_3")
	@ResponseBody
	public String showLineChart4Bookings_3() {
		
//		System.out.println("showLineChart4Bookings() numOfMonth : " + numOfMonth);
		
		List<Object[]> bookingCount =  bookingRepository.getMonthlyBookingDataFromDB_3();
		
		return processForLineChart4Bookings(bookingCount);
	}
		
	@GetMapping("/mgt_showLineChart4Bookings_6")
	@ResponseBody
	public String showLineChart4Bookings_6() {
		
//		System.out.println("showLineChart4Bookings() numOfMonth : " + numOfMonth);
		
		List<Object[]> bookingCount =  bookingRepository.getMonthlyBookingDataFromDB_6();
		
		return processForLineChart4Bookings(bookingCount);
	}

	@GetMapping("/mgt_showLineChart4Bookings_9")
	@ResponseBody
	public String showLineChart4Bookings_9() {
		
//		System.out.println("showLineChart4Bookings() numOfMonth : " + numOfMonth);
		
		List<Object[]> bookingCount =  bookingRepository.getMonthlyBookingDataFromDB_9();
		
		return processForLineChart4Bookings(bookingCount);
	}

	@GetMapping("/mgt_showLineChart4Bookings_12")
	@ResponseBody
	public String showLineChart4Bookings_12() {
		
//		System.out.println("showLineChart4Bookings() numOfMonth : " + numOfMonth);
		
		List<Object[]> bookingCount =  bookingRepository.getMonthlyBookingDataFromDB_12();
		
		return processForLineChart4Bookings(bookingCount);
	}

	
	private String processForLineChart4Bookings(List<Object[]> bookingCount) {
		
		Map<String, Long> map = null;
		
//		create JSON variables and object
		JsonArray jsonMonth = new JsonArray();
		JsonArray jsonData = new JsonArray();
		JsonObject json	= new JsonObject();
				
		if(bookingCount != null && !bookingCount.isEmpty()) {
			map = new HashMap<String, Long>();
			for (Object[] object : bookingCount) {
				
				String month = object[0].toString();
				Long bookingData = Long.valueOf(object[1].toString());		
								
				jsonMonth.add(month);
				jsonData.add(bookingData);
				
//				map.put(month, yAxis_data);				
			}
		}
		
		json.add("month", jsonMonth);
		json.add("objectData", jsonData);
		
//		System.out.println("json object : " + json.toString());
		
		return json.toString();

	}
			
	@GetMapping("/mgt_showLineChart4Revenue_3")
	@ResponseBody
	public String showLineChart4Revenue_3() {
		
		List<Object[]> monthlyRevenue =  bookingRepository.getMonthlyRevenueDataFromDB_3();
		
		return processForLineChart4Revenue(monthlyRevenue);
	}
	
	@GetMapping("/mgt_showLineChart4Revenue_6")
	@ResponseBody
	public String showLineChart4Revenue_6() {
		
		List<Object[]> monthlyRevenue =  bookingRepository.getMonthlyRevenueDataFromDB_6();
		
		return processForLineChart4Revenue(monthlyRevenue);
	}

	@GetMapping("/mgt_showLineChart4Revenue_9")
	@ResponseBody
	public String showLineChart4Revenue_9() {
		
		List<Object[]> monthlyRevenue =  bookingRepository.getMonthlyRevenueDataFromDB_9();
		
		return processForLineChart4Revenue(monthlyRevenue);
	}

	@GetMapping("/mgt_showLineChart4Revenue_12")
	@ResponseBody
	public String showLineChart4Revenue_12() {
		
		List<Object[]> monthlyRevenue =  bookingRepository.getMonthlyRevenueDataFromDB_12();
		
		return processForLineChart4Revenue(monthlyRevenue);
	}

		
	private String processForLineChart4Revenue(List<Object[]> monthlyRevenue) {
		
		Map<String, Long> map = null;
		
//		create JSON variables and object
		JsonArray jsonMonth = new JsonArray();
		JsonArray jsonData = new JsonArray();
		JsonObject json	= new JsonObject();
				
		if(monthlyRevenue != null && !monthlyRevenue.isEmpty()) {
			map = new HashMap<String, Long>();
			for (Object[] object : monthlyRevenue) {
				
				String month = object[0].toString();
				Double revenueData = Double.valueOf(object[1].toString());		
				
//				System.out.println("object length : " + object.length);
//				System.out.println("object.toString : " + object.toString());
//				System.out.println("Object[0] : " + month + ", Object[1] : " + revenueData + "\n");
				
				jsonMonth.add(month);
				jsonData.add(revenueData);
				
//				map.put(month, yAxis_data);				
			}
		}
		
		json.add("month", jsonMonth);
		json.add("objectData", jsonData);
		
//		System.out.println("json object : " + json.toString());
		
		return json.toString();

	}

// Pie Charts
	
	@GetMapping("/mgt_showPieChart4Model_3")
	@ResponseBody
	public String showPieChart4Model_3() {
		
		List<Object[]> modelCountData =  bookingRepository.getVehicleCountByModelFromDB_3();
		
		return processForPieChart4Model (modelCountData);		
	}

	@GetMapping("/mgt_showPieChart4Model_6")
	@ResponseBody
	public String showPieChart4Model_6() {
		
		List<Object[]> modelCountData =  bookingRepository.getVehicleCountByModelFromDB_6();
		
		return processForPieChart4Model (modelCountData);		
	}

	@GetMapping("/mgt_showPieChart4Model_9")
	@ResponseBody
	public String showPieChart4Model_9() {
		
		List<Object[]> modelCountData =  bookingRepository.getVehicleCountByModelFromDB_9();
		
		return processForPieChart4Model (modelCountData);		
	}

	@GetMapping("/mgt_showPieChart4Model_12")
	@ResponseBody
	public String showPieChart4Model_12() {
		
		List<Object[]> modelCountData =  bookingRepository.getVehicleCountByModelFromDB_12();
		
		return processForPieChart4Model (modelCountData);		
	}

	
	private String processForPieChart4Model (List<Object[]> modelCountData) {
		
//		Map<String, Long> map = null;
		
//		create JSON variables and object
		JsonArray jsonMonth = new JsonArray();
		JsonArray jsonData = new JsonArray();
		JsonObject json	= new JsonObject();
				
		if(modelCountData != null && !modelCountData.isEmpty()) {
			
//			map = new HashMap<String, Long>();
			
			for (Object[] object : modelCountData) {
				
				String carModel = object[0].toString();
				Long modelData = Long.valueOf(object[1].toString());		
				
//				System.out.println("object length : " + object.length);
//				System.out.println("object.toString : " + object.toString());
//				System.out.println("Object[0] : " + carModel + ", Object[1] : " + modelData + "\n");
				
				jsonMonth.add(carModel);
				jsonData.add(modelData);
				
//				map.put(month, yAxis_data);				
			}
		}
		
		json.add("carModel", jsonMonth);
		json.add("carData", jsonData);
		
//		System.out.println("json object : " + json.toString());
		
		return json.toString();
	}

	
	@GetMapping("/mgt_showRevenuePieChart4Model_3")
	@ResponseBody
	public String showRevenuePieChart4Model_3() {
		
		List<Object[]> modelCountData =  bookingRepository.getRevenueByModelFromDB_3();
		
		return processForRevenuePieChart4Model (modelCountData);
		
	}

	@GetMapping("/mgt_showRevenuePieChart4Model_6")
	@ResponseBody
	public String showRevenuePieChart4Model_6() {
		
		List<Object[]> modelCountData =  bookingRepository.getRevenueByModelFromDB_6();
		
		return processForRevenuePieChart4Model (modelCountData);
		
	}

	@GetMapping("/mgt_showRevenuePieChart4Model_9")
	@ResponseBody
	public String showRevenuePieChart4Model_9() {
		
		List<Object[]> modelCountData =  bookingRepository.getRevenueByModelFromDB_9();
		
		return processForRevenuePieChart4Model (modelCountData);
		
	}

	@GetMapping("/mgt_showRevenuePieChart4Model_12")
	@ResponseBody
	public String showRevenuePieChart4Model_12() {
		
		List<Object[]> modelCountData =  bookingRepository.getRevenueByModelFromDB_12();
		
		return processForRevenuePieChart4Model (modelCountData);
		
	}

	private String processForRevenuePieChart4Model (List<Object[]> modelCountData) {
		
//		create JSON variables and object
		JsonArray jsonMonth = new JsonArray();
		JsonArray jsonData = new JsonArray();
		JsonObject json	= new JsonObject();
				
		if(modelCountData != null && !modelCountData.isEmpty()) {
			
//			map = new HashMap<String, Long>();
			
			for (Object[] object : modelCountData) {
				
				String carModel = object[0].toString();
				Double modelData = Double.valueOf(object[1].toString());		
				
//				System.out.println("object length : " + object.length);
//				System.out.println("object.toString : " + object.toString());
//				System.out.println("Object[0] : " + carModel + ", Object[1] : " + modelData + "\n");
				
				jsonMonth.add(carModel);
				jsonData.add(modelData);
				
			}
		}
		
		json.add("carModel", jsonMonth);
		json.add("carData", jsonData);
		
//		System.out.println("json object : " + json.toString());
		
		return json.toString();
	}

}