package com.veh.repository;

import java.util.List;
import java.util.Map;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.veh.Booking;
import com.veh.Customer;
import com.veh.Users;
import com.veh.Vehicle;

@Repository
public interface BookingRepository extends JpaRepository<Booking, Long> {

	Page<Booking> getByTheVehicle(Vehicle vehicle, Pageable page);
	Page<Booking> getByTheCustomer(Customer customer, Pageable page);
	Page<Booking> getByTheUser(Users user, Pageable page);
	Booking getByBookId(Long bookId);
	Page<Booking> getPageByBookId(Long bookId, Pageable page);
	
	@Transactional
	@Modifying
	int deleteByBookId(Long bookId);
	
	@Query(value="SELECT to_char(Actual_Return_Date, 'YYYY-mm'), count(*) "
			+ "FROM booking b \n"
			+ "WHERE b.Actual_Return_Date >= add_months(sysdate, :numOfMonths)\n"
			+ "GROUP BY to_char(Actual_Return_Date, 'YYYY-mm')\n"
			+ "ORDER BY to_char(Actual_Return_Date, 'YYYY-mm')", nativeQuery = true)
	List<Object[]> getMonthlyBookingDataFromDB(@Param("numOfMonths")Integer numOfMonths);
	
	@Query(value="SELECT to_char(Actual_Return_Date, 'YYYY-mm'), sum(b.total) "
			+ "FROM booking b \n"
			+ "WHERE b.Actual_Return_Date >= add_months(sysdate, :numOfMonths)\n"
			+ "GROUP BY to_char(Actual_Return_Date, 'YYYY-mm')\n"
			+ "ORDER BY to_char(Actual_Return_Date, 'YYYY-mm')", nativeQuery = true)
	List<Object[]> getMonthlyRevenueDataFromDB(@Param("numOfMonths")Integer numOfMonths);
		
	@Query(value="select model, count(*)\n"
			+ "from booking b\n"
			+ "inner join vehicle on\n"
			+ "vehicle.veh_id = b.vehicle_id\n"
			+ "where b.Actual_Return_Date >= add_months(sysdate, :numOfMonths)\n"
			+ "group by model", nativeQuery = true)
	List<Object[]> getVehicleCountByModelFromDB(@Param("numOfMonths")Integer numOfMonths);
	
	@Query(value="select model, sum(total)\n"
			+ "from booking b\n"
			+ "inner join vehicle on\n"
			+ "vehicle.veh_id = b.vehicle_id\n"
			+ "where b.Actual_Return_Date >= add_months(sysdate, :numOfMonths)\n"
			+ "group by model", nativeQuery = true)
	List<Object[]> getRevenueByModelFromDB(@Param("numOfMonths")Integer numOfMonths);
		
}