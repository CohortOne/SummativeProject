package com.veh;

import java.io.File;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.constraints.Email;
import javax.validation.constraints.Size;

import org.springframework.boot.system.ApplicationHome;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.annotation.DateTimeFormat.ISO;

import com.sun.istack.NotNull;

@Entity
@Table(name = "Customer")
public class Customer {
	
	public Customer(Long custId, @Size(min = 3, max = 30) String lastName, @Size(min = 2, max = 30) String firstName,
			@Size(min = 6, max = 50) String address, @Size(min = 13, max = 16) String ccNum, LocalDate dob,
			@Size(min = 5, max = 50) @Email(message = "Should be a valid email address; eg abc@abc.com") String email,
			boolean isActive, @Size(min = 8, max = 15) String phoneNo, @Size(min = 6, max = 12) String drivingLicNum,
			LocalDate ccExpiryDate, String identityProof, List<Booking> bookings) {
		
		this.custId = custId;
		this.lastName = lastName;
		this.firstName = firstName;
		this.address = address;
		this.ccNum = ccNum;
		this.dob = dob;
		this.email = email;
		this.isActive = isActive;
		this.phoneNo = phoneNo;
		this.drivingLicNum = drivingLicNum;
		this.ccExpiryDate = ccExpiryDate;
		this.identityProof = identityProof;
		this.bookings = bookings;
	}
	
	public Customer() {};

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="CUSTID")
	private Long custId;
	
	@NotNull
	@Column(name = "LAST_NAME")
	@Size(min=3, max=30)
	private String lastName;
	
	@NotNull
	@Column(name = "FIRST_NAME")
	@Size(min=2, max=30)
	private String firstName;
	
	@NotNull
	@Column(name = "ADDRESS")
	@Size(min=6, max=50)
	private String address;
	
	@NotNull
	@Column(name = "CREDIT_CARD_NUM")
	@Size(min=13, max=16)
	private String ccNum;
	
	@NotNull
	@Column(name = "CC_EXPIRY_DATE")
	@DateTimeFormat(iso = ISO.DATE)
	private LocalDate ccExpiryDate;
	
	@NotNull
	@Column(name = "DOB")
	@DateTimeFormat(iso = ISO.DATE)
	private LocalDate dob;
	
	@NotNull
	@Size(min=5, max=50)
	@Email(message = "Should be a valid email address; eg abc@abc.com")
	@Column(name = "EMAIL")
	private String email;
	
	@Column(name = "ISACTIVE")
	private boolean isActive;
	
	@NotNull
	@Size(min=8, max=15)
	@Column(name = "PHONENO")
	private String phoneNo;
	
	@NotNull
	@Size(min=6, max=12)
	@Column(name = "DRIVING_LIC_NO")
	private String drivingLicNum;
	
	@Column(name = "IDENTITY_PROOF")
	private String identityProof;
	
	@OneToMany(mappedBy="theCustomer",
			   cascade = {CascadeType.MERGE, CascadeType.PERSIST, CascadeType.REFRESH, CascadeType.DETACH})
	private List<Booking> bookings;
	
	
	public List<Booking> getBookings() {
		return bookings;
	}

	public void setBookings(List<Booking> bookings) {
		this.bookings = bookings;
	}

	public Long getCustId() {
		return custId;
	}

	public void setCustId(Long custId) {
		this.custId = custId;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getCcNum() {
		return ccNum;
	}

	public void setCcNum(String ccNum) {
		this.ccNum = ccNum;
	}

	public LocalDate getCcExpiryDate() {
		return ccExpiryDate;
	}

	public void setCcExpiryDate(LocalDate ccExpiryDate) {
		this.ccExpiryDate = ccExpiryDate;
	}

	public void setActive(boolean isActive) {
		this.isActive = isActive;
	}

	public LocalDate getDob() {
		return dob;
	}

	public void setDob(LocalDate dob) {
		this.dob = dob;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(boolean isActive) {
		this.isActive = isActive;
	}

	public String getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}

	public String getDrivingLicNum() {
		return drivingLicNum;
	}

	public void setDrivingLicNum(String drivingLicNum) {
		this.drivingLicNum = drivingLicNum;
	}
	
	public String getIdentityProof() {
		return identityProof;
	}

	public void setIdentityProof(String identityProof) {
		this.identityProof = identityProof;
	}
	
	// Add convenience method for bi-directional relationship
	public void add_booking(Booking booking) {
		
		if (bookings == null) {
			bookings = new ArrayList<>();
		}
		
		bookings.add(booking);
		
		booking.setTheCustomer(this);
	}
	
	
	@Transient
	public String customerImagePath() {
		if (identityProof == null) return null;
		
//		get path to src/main/resources/static/img
		Path resourceDirectory = Paths.get("src","main","resources", "static", "img");
		String absolutePath = resourceDirectory.toFile().getAbsolutePath();
        
//        System.out.println("In vehicleImagePath() appDir.toString : " + appDir.toString());

		return absolutePath + "/customer-photos/" + custId + "/" + identityProof;
		
	}

	@Override
	public String toString() {
		return "Customer [custId=" + custId + ", lastName=" + lastName + ", firstName=" + firstName + ", address="
				+ address + ", ccNum=" + ccNum + ", dob=" + dob + ", email=" + email + ", isActive=" + isActive
				+ ", phoneNo=" + phoneNo + ", drivingLicNum=" + drivingLicNum + ", drvLicExpiryDate=" + ccExpiryDate
				+ ", identityProof=" + identityProof + "]";
	}

}
