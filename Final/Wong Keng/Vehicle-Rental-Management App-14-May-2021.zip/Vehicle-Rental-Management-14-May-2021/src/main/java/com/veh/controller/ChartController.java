package com.veh.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.veh.repository.BookingRepository;

@Controller
public class ChartController {
	
	@Autowired
	BookingRepository bookingRepository;
	
	@GetMapping("/mgt_bookings_reporting")
	public String mgtReporting() {		
		return "mgt_bookings_by_month";
	}
	
	@GetMapping("/mgt_bookings_bycarModels_reporting")
	public String mgtReportingByCarModels() {
		return "mgt_bookings_by_carModels";
	}
	
	@GetMapping("/mgt_showLineChart4Bookings")
	@ResponseBody
	public String showLineChart4Bookings(@RequestParam(value="requiredMonths")Integer numOfMonth) {
		
//		System.out.println("showLineChart4Bookings() numOfMonth : " + numOfMonth);
		
		List<Object[]> bookingCount =  bookingRepository.getMonthlyBookingDataFromDB(numOfMonth);
		
		Map<String, Long> map = null;
		
//		create JSON variables and object
		JsonArray jsonMonth = new JsonArray();
		JsonArray jsonData = new JsonArray();
		JsonObject json	= new JsonObject();
				
		if(bookingCount != null && !bookingCount.isEmpty()) {
			map = new HashMap<String, Long>();
			for (Object[] object : bookingCount) {
				
				String month = object[0].toString();
				Long bookingData = Long.valueOf(object[1].toString());		
								
				jsonMonth.add(month);
				jsonData.add(bookingData);
				
//				map.put(month, yAxis_data);				
			}
		}
		
		json.add("month", jsonMonth);
		json.add("objectData", jsonData);
		
//		System.out.println("json object : " + json.toString());
		
		return json.toString();
	}
	
	@GetMapping("/mgt_showLineChart4Revenue")
	@ResponseBody
	public String showLineChart4Revenue(@RequestParam(value="requiredMonths")Integer numOfMonth) {
		
		List<Object[]> monthlyRevenue =  bookingRepository.getMonthlyRevenueDataFromDB(numOfMonth);
		
		Map<String, Long> map = null;
		
//		create JSON variables and object
		JsonArray jsonMonth = new JsonArray();
		JsonArray jsonData = new JsonArray();
		JsonObject json	= new JsonObject();
				
		if(monthlyRevenue != null && !monthlyRevenue.isEmpty()) {
			map = new HashMap<String, Long>();
			for (Object[] object : monthlyRevenue) {
				
				String month = object[0].toString();
				Double revenueData = Double.valueOf(object[1].toString());		
				
//				System.out.println("object length : " + object.length);
//				System.out.println("object.toString : " + object.toString());
//				System.out.println("Object[0] : " + month + ", Object[1] : " + revenueData + "\n");
				
				jsonMonth.add(month);
				jsonData.add(revenueData);
				
//				map.put(month, yAxis_data);				
			}
		}
		
		json.add("month", jsonMonth);
		json.add("objectData", jsonData);
		
//		System.out.println("json object : " + json.toString());
		
		return json.toString();
	}
	
	@GetMapping("/mgt_showPieChart4Model")
	@ResponseBody
	public String showPieChart4Model(@RequestParam(value="requiredMonths")Integer numOfMonth) {
		
		List<Object[]> modelCountData =  bookingRepository.getVehicleCountByModelFromDB(numOfMonth);
		
//		Map<String, Long> map = null;
		
//		create JSON variables and object
		JsonArray jsonMonth = new JsonArray();
		JsonArray jsonData = new JsonArray();
		JsonObject json	= new JsonObject();
				
		if(modelCountData != null && !modelCountData.isEmpty()) {
			
//			map = new HashMap<String, Long>();
			
			for (Object[] object : modelCountData) {
				
				String carModel = object[0].toString();
				Long modelData = Long.valueOf(object[1].toString());		
				
//				System.out.println("object length : " + object.length);
//				System.out.println("object.toString : " + object.toString());
//				System.out.println("Object[0] : " + carModel + ", Object[1] : " + modelData + "\n");
				
				jsonMonth.add(carModel);
				jsonData.add(modelData);
				
//				map.put(month, yAxis_data);				
			}
		}
		
		json.add("carModel", jsonMonth);
		json.add("carData", jsonData);
		
//		System.out.println("json object : " + json.toString());
		
		return json.toString();
	}
	
	@GetMapping("/mgt_showRevenuePieChart4Model")
	@ResponseBody
	public String showRevenuePieChart4Model(@RequestParam(value="requiredMonths")Integer numOfMonth) {
		
		List<Object[]> modelCountData =  bookingRepository.getRevenueByModelFromDB(numOfMonth);
		
//		create JSON variables and object
		JsonArray jsonMonth = new JsonArray();
		JsonArray jsonData = new JsonArray();
		JsonObject json	= new JsonObject();
				
		if(modelCountData != null && !modelCountData.isEmpty()) {
			
//			map = new HashMap<String, Long>();
			
			for (Object[] object : modelCountData) {
				
				String carModel = object[0].toString();
				Double modelData = Double.valueOf(object[1].toString());		
				
//				System.out.println("object length : " + object.length);
//				System.out.println("object.toString : " + object.toString());
//				System.out.println("Object[0] : " + carModel + ", Object[1] : " + modelData + "\n");
				
				jsonMonth.add(carModel);
				jsonData.add(modelData);
				
			}
		}
		
		json.add("carModel", jsonMonth);
		json.add("carData", jsonData);
		
//		System.out.println("json object : " + json.toString());
		
		return json.toString();
	}

}