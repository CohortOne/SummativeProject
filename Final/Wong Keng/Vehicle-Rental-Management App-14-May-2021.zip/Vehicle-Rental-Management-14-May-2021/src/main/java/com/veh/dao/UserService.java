package com.veh.dao;

import java.util.List;

import com.veh.Users;

public interface UserService {

		public List<Users> findAll();
		
		public Users findById(long theId);
		
		public void save(Users theEmployee);
		
		public void deleteById(long theId);
}
