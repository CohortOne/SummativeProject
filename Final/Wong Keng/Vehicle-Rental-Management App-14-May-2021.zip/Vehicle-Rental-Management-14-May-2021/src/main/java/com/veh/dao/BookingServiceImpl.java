package com.veh.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.veh.Booking;
import com.veh.Customer;
import com.veh.Vehicle;
import com.veh.repository.BookingRepository;

@Service
public class BookingServiceImpl implements BookingService {

	@Autowired
	private BookingRepository bookingRepository;

	@Override
	public Booking findById(Long theId) {
		Optional <Booking> optional = bookingRepository.findById(theId);
		Booking theBooking = null;
		
		if (optional.isPresent())
			theBooking = optional.get();
		else
			throw new RuntimeException(" Booking not found for id :: " + theId);
		
		return theBooking;
	}

	@Override
	public void save(Booking theBooking) {
		bookingRepository.save(theBooking);
	}

	@Override
	public int deleteBooking(Long theId) {
		
//		set Vehicle to Available using vehId
		Booking theBooking = bookingRepository.getByBookId(theId);
		
		Vehicle theVehicle = theBooking.getTheVehicle();
		
		theVehicle.setVehStatus("Available");
		
		int status = bookingRepository.deleteByBookId(theId);
		
		return status;
				
	}

}
