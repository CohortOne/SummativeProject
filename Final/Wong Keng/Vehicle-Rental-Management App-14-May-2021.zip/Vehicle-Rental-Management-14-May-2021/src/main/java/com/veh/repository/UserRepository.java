package com.veh.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.veh.Customer;
import com.veh.Users;

//public interface UserRepository extends CrudRepository<Users, Long> 

@Repository
public interface UserRepository extends JpaRepository<Users, Long>{

		Users getUserByUsername(String username);
		Users getUserById(Long id);
		Users getUserByFirstNameAndLastNameAllIgnoreCase (String firstName, String lastName);
		Page<Users> findUserById (Long id, Pageable page);
		
		@Query(value="SELECT USER_ID FROM USERS b \n"
				+ "where b.username = :username", nativeQuery = true)
		Long getIdByUsername(@Param("username") String username);
}
