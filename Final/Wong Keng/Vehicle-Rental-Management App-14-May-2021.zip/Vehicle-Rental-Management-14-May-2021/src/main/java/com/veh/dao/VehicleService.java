package com.veh.dao;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.veh.Booking;
import com.veh.Users;
import com.veh.Vehicle;

public interface VehicleService {

		public List<Vehicle> findAll();
		
		public Vehicle findById(Long theId);
		
		public void save(Vehicle theVehicle);
		
		public Vehicle saveTemp4ID(Vehicle theVehicle);
		
		public void deleteById(Long theId);
		
		public Vehicle findByRegNum(String vehRegNum);
		
}
