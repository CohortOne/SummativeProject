package com.veh.dao;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.veh.Booking;
import com.veh.Customer;
import com.veh.Vehicle;

@Service
public interface BookingService {
		
		public Booking findById(Long theId);
		
		public void save(Booking theBooking);
		
		public int deleteBooking(Long theId);
}
