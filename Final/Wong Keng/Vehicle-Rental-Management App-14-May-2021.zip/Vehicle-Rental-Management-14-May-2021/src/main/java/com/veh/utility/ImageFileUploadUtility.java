package com.veh.utility;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;

import javax.servlet.ServletContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.system.ApplicationHome;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import com.veh.Vehicle;

@Component
public class ImageFileUploadUtility {
	
	public ImageFileUploadUtility() {};

	public Vehicle upLoadImageFile(Vehicle theVehicle,
								   MultipartFile multipartFile) throws IOException {
		
		String fileName = StringUtils.cleanPath(multipartFile.getOriginalFilename());
        
		theVehicle.setVehImage(fileName);
		
//		System.out.println("ImageFileUploadUtility() - fileName : " + fileName);

//		get path to src/main/resources/static/img
		Path resourceDirectory = Paths.get("src","main","resources", "static", "img");
		String absolutePath = resourceDirectory.toFile().getAbsolutePath();

//		System.out.println("absolutePath : " + absolutePath);
		
        String uploadDir = absolutePath + "/vehicle-photos/" + theVehicle.getVehId();
        
        Path uploadPath = Paths.get(uploadDir);
              
        //Create directory if it does not exist
        
        if (!Files.exists(uploadPath)) {
        	Files.createDirectories(uploadPath);
        }
        
        try (InputStream inputStream = multipartFile.getInputStream()) {
        	Path filePath = uploadPath.resolve(fileName);
        	
//        	System.out.println("filePath : " + filePath.toString());

            Files.copy(inputStream, filePath, StandardCopyOption.REPLACE_EXISTING);
            
        } catch (IOException e) {
        	throw new IOException("Could not save uploaded file: " + fileName);

        }
		
        return theVehicle;
	}
	
	public Vehicle upLoadOriginalImageFile(Vehicle theVehicle,
			   String fileName) throws IOException {
		
//		This method will upload the original image file if it is present when the vehicle record is updated
//		without a new image upload
		
		theVehicle.setVehImage(fileName);
				
//		get path to src/main/resources/static/img
		Path resourceDirectory = Paths.get("src","main","resources", "static", "img");
		String absolutePath = resourceDirectory.toFile().getAbsolutePath();
		
		String uploadDir = absolutePath + "/vehicle-photos/" + theVehicle.getVehId();        

		Path uploadPath = Paths.get(uploadDir);

		Path filePath = uploadPath.resolve(fileName);
		
		File initialFile = new File(filePath.toFile().getAbsolutePath());
		
	    InputStream inputStream = new FileInputStream(initialFile);
		
		Files.copy(inputStream, filePath, StandardCopyOption.REPLACE_EXISTING);
		
		return theVehicle;
		}
	
}
