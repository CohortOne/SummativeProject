package com.veh.controller;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import org.springframework.http.HttpStatus;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.veh.ItemNotFoundException;
import com.veh.VehAppException;

@ControllerAdvice
public class ExceptionController {
	
	@ExceptionHandler
	public String handleException(ItemNotFoundException exc, Model model) {
		
		VehAppException vehAppException = new VehAppException();
		
		vehAppException.setStatus(HttpStatus.NOT_FOUND.value());
		vehAppException.setErrorMessage(exc.getMessage());
		
//		Get Date and Time as String		
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd-MMM-uuuu HH:mm:ss");
        LocalDateTime now = LocalDateTime.now(); 
        String dateTime = now.format(dtf);
		
		vehAppException.setDateTimeStamp(dateTime);
		vehAppException.setFromURL(exc.getFromURL());
		
		model.addAttribute("vehAppException", vehAppException);
		
		return "error_message_page";
	}

}
