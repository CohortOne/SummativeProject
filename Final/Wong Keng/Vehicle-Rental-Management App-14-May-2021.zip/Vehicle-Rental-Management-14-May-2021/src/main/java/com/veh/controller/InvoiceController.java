package com.veh.controller;

import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;
import org.thymeleaf.templatemode.TemplateMode;
import org.thymeleaf.templateresolver.ClassLoaderTemplateResolver;

import com.lowagie.text.DocumentException;
import com.veh.Booking;
import com.veh.dao.BookingService;
import com.veh.utility.CreditCardMasker;
import com.veh.utility.ThymeleafToPDF;

@Controller
public class InvoiceController {

	@Autowired
	BookingService bookingService;
	
	@Autowired
	ThymeleafToPDF theThymeleafToPDF;
	
	@GetMapping("/generate_invoice/{bookId}/{pdf}/{thisPage}")
	public String generateInvoice(@PathVariable("bookId")Long bookId,
								  @PathVariable("pdf")Long pdf,
								  @PathVariable(value="thisPage") Integer thisPage,
								  Model model,
								  RedirectAttributes redirectAttributes){
		
		Booking theBooking = bookingService.findById(bookId);
		
//		add theBooking to model attribute "booking"
		model.addAttribute("booking", theBooking);
		
//		add current page of required record to model attribute
		model.addAttribute("thisPage", thisPage);
				
//		add required attributes for PDF invoice generation
		model.addAttribute("title", "Keng Car Rental Pte Ltd");
		
		model.addAttribute("bookId", bookId);
		
		model.addAttribute("customer_name", theBooking.getTheCustomer().getFirstName() + " "
											+ theBooking.getTheCustomer().getLastName());
		model.addAttribute("customer_address", theBooking.getTheCustomer().getAddress());
		model.addAttribute("customer_phoneNo", theBooking.getTheCustomer().getPhoneNo());
		model.addAttribute("customer_email", theBooking.getTheCustomer().getEmail());
		
		model.addAttribute("veh_regNum", theBooking.getTheVehicle().getVehRegNum());
		model.addAttribute("veh_brand", theBooking.getTheVehicle().getBrand());
		model.addAttribute("veh_model", theBooking.getTheVehicle().getModel());
		
		model.addAttribute("veh_hireRate", theBooking.getTheVehicle().getHireRate());
		
		model.addAttribute("duration", theBooking.getDuration());
		model.addAttribute("total", theBooking.getTotal());		

//		Get current date and time
		LocalDateTime now = LocalDateTime.now();
		
//		Format datetime to String
		String currentDateTime = (now.format(DateTimeFormatter.ofPattern("EEEE, dd-MMMM-yyyy, HH:mm")) + "hr");
		
//		Format rental Start and Return dates to String
		String startDate = (theBooking.getStartDate().format(DateTimeFormatter.ofPattern("EEEE, dd-MMMM-yyyy, HH:mm")) + "hr");
		String returnDate = (theBooking.getActualReturnDate().format(DateTimeFormatter.ofPattern("EEEE, dd-MMMM-yyyy, HH:mm")) + "hr");
		
//		Add to model attribute "currentDateTime"
		model.addAttribute("currentDateTime", currentDateTime);
		model.addAttribute("startDate", startDate);
		model.addAttribute("returnDate", returnDate);
		
//		Get customer's CC number
		String ccNum = theBooking.getTheCustomer().getCcNum();
		
//		Mask Credit Card number and add to model attribute "maskedCCNum
		String maskedCCNum = CreditCardMasker.maskCreditCard(ccNum);
		
		model.addAttribute("maskedCCNum",  maskedCCNum);
				
//		add model to redirectAttributes for transfer to other endpoints
		redirectAttributes.addFlashAttribute("forInvoicePdf", model);
		
//		System.out.println("pdf : " + pdf);
//		
		if (pdf == 1)
			return "invoice"; //generate invoice in browser
		else
			return "redirect:/generatePdfInvoiceTemp"; //generate invoice in PDF format
			
	}
		
	@GetMapping("/generatePdfInvoiceTemp")
	public String generatePdfInvoiceTemp(@ModelAttribute("forInvoicePdf") Model model,
										 RedirectAttributes ra) throws IOException, DocumentException {
		
		ClassLoaderTemplateResolver templateResolver = new ClassLoaderTemplateResolver();
	    templateResolver.setSuffix(".html");
	    templateResolver.setPrefix("templates/");
	    templateResolver.setTemplateMode(TemplateMode.HTML);

	    TemplateEngine templateEngine = new TemplateEngine();
	    templateEngine.setTemplateResolver(templateResolver);

	    Context context = new Context();
	    context.setVariable("invoice_num", model.getAttribute("bookId"));
	    context.setVariable("currentDateTime", model.getAttribute("currentDateTime"));
	    
	    context.setVariable("customer_name", model.getAttribute("customer_name"));
	    context.setVariable("customer_address", model.getAttribute("customer_address"));
	    context.setVariable("customer_phoneNo", model.getAttribute("customer_phoneNo"));
	    context.setVariable("customer_email", model.getAttribute("customer_email"));
	    
	    context.setVariable("maskedCCNum", model.getAttribute("maskedCCNum"));
	    
	    context.setVariable("veh_regNum", model.getAttribute("veh_regNum"));
	    context.setVariable("veh_brand", model.getAttribute("veh_brand"));
	    context.setVariable("veh_model", model.getAttribute("veh_model"));
	    
	    context.setVariable("veh_hireRate", model.getAttribute("veh_hireRate"));
	    
	    context.setVariable("startDate", model.getAttribute("startDate"));
	    context.setVariable("returnDate", model.getAttribute("returnDate"));
	    context.setVariable("duration", model.getAttribute("duration"));
	    context.setVariable("total", model.getAttribute("total")); 
	    
	  	String html = templateEngine.process("invoice_pdf", context);
	  	
	  	Long bookId = (Long)model.getAttribute("bookId");
	  	
		Integer currentPage = (Integer)model.getAttribute("thisPage");
  			
		theThymeleafToPDF.generatePdfFromHtml(html, bookId);
		
		ra.addFlashAttribute("message", "PDF Invoice " + bookId + " successfully generated");
				
		return "redirect:/list_booking/" + currentPage;
	}

}














