package com.veh;

public class ItemNotFoundException extends RuntimeException {
	
	String fromURL;

	public ItemNotFoundException(String message, Throwable cause) {
		super(message, cause);
	}

	public ItemNotFoundException(String message) {
		super(message);
	}

	public ItemNotFoundException(Throwable cause) {
		super(cause);
	}
	
	public ItemNotFoundException(String message, String fromURL) {
		super(message);
		this.fromURL = fromURL;
	}

	public String getFromURL() {
		return fromURL;
	}

	public void setFromURL(String fromURL) {
		this.fromURL = fromURL;
	}

	
}
