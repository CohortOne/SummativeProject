package com.veh.dao;

import java.util.List;

import org.springframework.data.domain.Page;

import com.veh.Booking;
import com.veh.Customer;

public interface CustomerDao {
	
	public Page<Customer> getAllCustomers(int pageNumber, String sortField, String sortDir);
	public void saveCustomer(Customer customer);
	public void updateCustomer(Customer customer);
	public Customer getCustomerById(Long custId);
	public void deleteCustomerById(Long custId);
	public Customer saveTemp4ID(Customer customer);
	public Customer getCustByFirstNameAndLastName (String firstName, String lastName);
	public Customer getCustByEmail (String email);
	public Customer getCustByDrivingLicNum (String drivingLicNum);

}
