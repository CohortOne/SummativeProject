package com.veh.controller;

import java.util.List;
import java.util.Set;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.repository.query.Param;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.veh.ItemNotFoundException;
import com.veh.MyUserDetails;
import com.veh.Password;
import com.veh.UserRole;
import com.veh.Users;
import com.veh.dao.UserService;
import com.veh.repository.RoleRepository;
import com.veh.repository.UserRepository;

@Controller
public class UserController {
	
	@Autowired
	private UserService userService;
	
	@Autowired
	private RoleRepository roleRepo;
	
	@Autowired
	private UserRepository userRepository;
	
	@Autowired
	private BCryptPasswordEncoder bcryptPasswordEncoder;
	
	@GetMapping("/list_users")
	public String listUsers(Model model, @AuthenticationPrincipal MyUserDetails myUserDetails) {
		
//		Get username of the login user
		String username = myUserDetails.getUsername();
		
//		Get the ID of the login user
		Users theUser = userRepository.getUserByUsername(username);
		
//		Get user roles
		Set<UserRole> roles = theUser.getUserRoles();
		
		int roleFlag = 0;
		
		for (UserRole role : roles) {
			
			if (role.getName().equals("ADMIN"))
				roleFlag = 1; //set flag to indicate that login user has role of "ADMIN"
		}
		
		if (roleFlag == 0) {
//			only list the details of the login user
			String selectedProperty = "dummy"; //dummy data
			String selectedOption = "Name";
			Long userId = theUser.getId();
			
			return listByUserAttributes(1, "id", "asc", selectedProperty, selectedOption,
					 userId, model);
			
		}
			
		return findPaginated(1, "id", "asc", model); //list all users in the application
	}
	
	@GetMapping("/userPage/{pageNo}")
	public String findPaginated(@PathVariable("pageNo") int pageNo,
									@RequestParam("sortField") String sortField,
									@RequestParam("sortDir") String sortDir,
									Model model) {
		
		return listByUserAttributes(pageNo, sortField, sortDir, "dummy", "All", null, model);
	}
	
	@GetMapping("/new_user")
	public String newUserCreation(Model model) {
		List<UserRole> roles = roleRepo.findAll();
		model.addAttribute("roles", roles);
		
		Users theUser = new Users();
		model.addAttribute("user", theUser);
		return "new_user";
	}
	
	@PostMapping("/saveUser")
	public String saveUser(@Valid @ModelAttribute("user")Users theUser, 
			BindingResult bindingResult,
			RedirectAttributes ra) {
		
		if (bindingResult.hasErrors())
			return "new_user";
		
//		Encrypt the password and set it in the User object before saving it
		String encryptPassword = bcryptPasswordEncoder.encode(theUser.getPassword());
		
		theUser.setPassword(encryptPassword);
		
		userService.save(theUser);
		
		ra.addFlashAttribute("message", "New User " + theUser.getFirstName() + " " + theUser.getLastName() + " Successfully Created.");
		
		return "redirect:/list_users";
	}
	
	@PostMapping("/updateUser_password") //this endpoint is just for changing of password by USER and MANAGER
	public String updateUser_password(@Valid @ModelAttribute("user")Users theUser, 
			@ModelAttribute("thePassword")Password thePassword,
			BindingResult bindingResult,
			RedirectAttributes ra,
			Model model) {
		
		if (bindingResult.hasErrors())
			return "update_user_password";
		
//		current password entered by user
		String currentPassword = thePassword.getCurrentPassword();
		
//		Get the encrypted user password from the DB
		Long userId = theUser.getId();
		
		Users loginUser = userRepository.getUserById(userId);
		String currentEncryptedPassword = loginUser.getPassword();
		
//		Check if current password entered by user matches the one from the DB
		boolean result = bcryptPasswordEncoder.matches(currentPassword, currentEncryptedPassword);
		
		if (result) {
//			Current entered password matched the one in DB.
//			Encrypt the new password and set it in the User object, loginUser, before saving it
			String encryptPassword = bcryptPasswordEncoder.encode(thePassword.getNewPassword());
						
			loginUser.setPassword(encryptPassword);
			
//			System.out.println("updateUser() loginUser : " + loginUser.toString());
//			System.out.println("updateUser() theUser : " + theUser.toString());
			
			userService.save(loginUser);
			
			ra.addFlashAttribute("message", "Password successfully changed for Username, " + loginUser.getUsername() + ".");

		}
		else {
			ra.addFlashAttribute("failedMessage", "Password change FAILED for Username, " + loginUser.getUsername() + "! Invalid Old Password.");
			
		}		
								
		return "redirect:/list_users";
	}
	
	@PostMapping("/updateUser_reset_password") //this endpoint is for ADMIN to reset password
	public String updateUser_reset_password(@Valid @ModelAttribute("user")Users theUser, 
			@ModelAttribute("thePassword")Password thePassword,
			BindingResult bindingResult,
			RedirectAttributes ra) {
		
		if (bindingResult.hasErrors())
			return "update_user_reset_password";
		
//		Get Login userId and get User object
		Long userId = theUser.getId();
		
		Users loginUser = userRepository.getUserById(userId);
		
//		Encrypt the new password and set it in the User object, loginUser, before saving it
		String encryptPassword = bcryptPasswordEncoder.encode(thePassword.getNewPassword());
					
		loginUser.setPassword(encryptPassword);
		
//			System.out.println("updateUser() loginUser : " + loginUser.toString());
//			System.out.println("updateUser() theUser : " + theUser.toString());
		
		userService.save(loginUser);
		
		ra.addFlashAttribute("message", "User password successfully reset for Username, " + loginUser.getUsername() + ".");
		
		return "redirect:/list_users";
	}

	@PostMapping("/updateUser_details") //this endpoint is for ADMIN to change user details
	public String updateUser_details(@Valid @ModelAttribute("user")Users theUser, 
			BindingResult bindingResult,
			RedirectAttributes ra) {
		
		if (bindingResult.hasErrors())
			return "update_user_details";
		
//		Get Login userId and get User object
		Long userId = theUser.getId();
		
		Users loginUser = userRepository.getUserById(userId);
		
//		set current password to theUser object and save to DB
		String currentEncryptedPwdFromDB = loginUser.getPassword();
		
		theUser.setPassword(currentEncryptedPwdFromDB);
				
		userService.save(theUser);
		
		ra.addFlashAttribute("message", "Details for Username, " + theUser.getUsername() + ", Successfully Updated.");
		
		return "redirect:/list_users";
	}
	
	@GetMapping("/showFormToUpdateUser/{whatToDo}")
	public String showFormToUpdateUser(@RequestParam("userId")Long id, 
			@PathVariable(value="whatToDo")Integer whatToDo,
			Model model) {
		
		//Get list of roles
		List<UserRole> roles = roleRepo.findAll();
		model.addAttribute("roles", roles);
		
		// Get User from the Service 
		Users theUser = userService.findById(id);
		
		// set employee as a model attribute to pre-populate the form
		Password thePassword = new Password();
		
		model.addAttribute("user", theUser);
		model.addAttribute("thePassword", thePassword);
		
//		System.out.println("In Update User - " + model.toString());
		
		switch (whatToDo) {
		
			case 1:
				return "update_user_password";
			case 2:
				return "update_user_reset_password";
			case 3:
				return "update_user_details";
			default:
				throw new ItemNotFoundException("Error in selected option.", "redirect:/list_users");
		}		
	}
	
	@GetMapping("/deleteUser")
	public String deleteCustomer(@RequestParam("userId") long theId,
			RedirectAttributes ra) {
	 
		// call delete employee method 
	 this.userService.deleteById(theId);
	 
	 ra.addFlashAttribute("message", "Record of User ID " + theId + " successfully Deleted.");
	 
	 return "redirect:/list_users";
	}
	
	@GetMapping("/getUserDetailsByName")
	public String getUserDetailsByName(Model model) {
		
		Users theUser = new Users();
		
		model.addAttribute("user", theUser);
		return "search_user_details_by_user_name";
	}
	
	@PostMapping("/searchUserDetailsByUserName")
	public String searchUserDetailsByUserName(@Valid @ModelAttribute("user")Users theUser,
			Model model) {
		
		//get required user object based on First and Last Names.
		Users tempUser = userRepository.getUserByFirstNameAndLastNameAllIgnoreCase(theUser.getFirstName(), theUser.getLastName());
		
//		if no record found, throw exception
		if (tempUser == null) {
			throw new ItemNotFoundException("No User record found under Name : " 
					+ theUser.getFirstName() + " " + theUser.getLastName(), "/getUserDetailsByName");
		}
		
		String selectedProperty = "dummy"; //dummy data
		String selectedOption = "Name";
		Long userId = tempUser.getId();
		
//		System.out.println("searchUserDetailsByUserName() tempUser : " + tempUser);		
		
		return listByUserAttributes(1, "id", "asc", selectedProperty, selectedOption,
				 userId, model);
	}
	
	@GetMapping("/getUserByNameForBookings")
	public String getUserByNameForBookings(Model model) {
		
		Users theUser = new Users();
		
		model.addAttribute("user", theUser);
		return "search_user_details_by_user_name_for_booking";
	}
		
	@GetMapping("/userPageByAttribute/{pageNumber}")
	public String listByUserAttributes(@PathVariable("pageNumber") int currentPage, 
							 @RequestParam("sortField") String sortField,
							 @RequestParam("sortDir") String sortDir,
							 @RequestParam("selectedProperty")String selectedProperty,
							 @RequestParam("selectedOption")String selectedOption,
							 @RequestParam("objectId")Long objectId,
							 Model model) {
		
		Sort sort = Sort.by(sortField);
		sort = sortDir.equals("asc") ? sort.ascending() : sort.descending();
		
		Pageable paging = PageRequest.of(currentPage-1, 5, sort); //maximum of 5 items per page
		
//		Initialise variables
		Page<Users> page = null;
		Users tempUser = null;
					
		model.addAttribute("objectId", objectId);
		model.addAttribute("selectedOption", selectedOption);
		model.addAttribute("selectedProperty", selectedProperty);
		
		switch (selectedOption) {
			case "All":
				page = userRepository.findAll(paging);
				break;
				
			case "Name":
				page = userRepository.findUserById(objectId, paging);
				break;	
		}
		
		int totalPages = page.getTotalPages();
		long totalItems = page.getTotalElements();
		
//		System.out.println("total number of elements " + totalItems);
		
		List<Users> listUsers = page.getContent();
		
//		System.out.println(("Booking List : " + listBookings));
		
		model.addAttribute("listUsers", listUsers);
		model.addAttribute("currentPage", currentPage);
		model.addAttribute("totalItems", totalItems);
		model.addAttribute("totalPages", totalPages);
		model.addAttribute("sortField", sortField);
		model.addAttribute("sortDir", sortDir);
		
//		System.out.println("selectedOption = " + model.getAttribute("selectedOption"));
//		System.out.println("selectedProperty = " + model.getAttribute("selectedProperty"));
				
		String reverseSortDir = sortDir.equals("asc") ? "desc" : "asc";
		model.addAttribute("reverseSortDir", reverseSortDir);
		
		return "list_users_by_attribute";
	}

}