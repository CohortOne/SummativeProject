package com.veh.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.veh.Booking;
import com.veh.Customer;

@Repository
public interface CustomerRepository extends JpaRepository<Customer, Long>{
	
	List<Booking> findByFirstNameAndLastNameAllIgnoreCase (String firstName, String lastName);
	List<Booking> findByEmail(String email);
	Customer getCustomerByFirstNameAndLastNameAllIgnoreCase (String firstName, String lastName);
	Customer getCustomerByEmail (String email);
	Customer getCustomerByDrivingLicNum (String drivingLicNum);
	Customer getByCustId(Long custId);
	Page<Customer> findCustomerByEmail(String email, Pageable page);
	Page<Customer> findCustomerByDrivingLicNum (String drivingLicNum, Pageable page);
	Page<Customer> findCustomerByCustId(Long custId, Pageable page);
	Page<Customer> findAll(Pageable page);
	
	@Transactional
	@Modifying
	int deleteByCustId(Long bookId);
}
