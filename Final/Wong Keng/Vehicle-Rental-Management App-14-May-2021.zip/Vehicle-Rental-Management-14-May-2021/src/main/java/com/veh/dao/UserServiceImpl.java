package com.veh.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.veh.Customer;
import com.veh.Users;
import com.veh.repository.UserRepository;

@Service
public class UserServiceImpl implements UserService {

	private UserRepository userRepository;
	
	@Autowired
	public UserServiceImpl(UserRepository userRepository) {
		this.userRepository = userRepository;
	}

	@Override
	public List<Users> findAll() {
		return userRepository.findAll();
	}

	@Override
	public Users findById(long theId) {
		Optional <Users> optional = userRepository.findById(theId);
		Users theUser = null;
		
		if(optional.isPresent())
			theUser = optional.get();
		else
			throw new RuntimeException(" Customer not found for id :: " + theId);
		
		return theUser;
	}

	@Override
	public void save(Users theUser) {
		userRepository.save(theUser);
	}

	@Override
	public void deleteById(long theId) {
		userRepository.deleteById(theId);

	}

}
