package com.veh.utility;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import org.springframework.boot.system.ApplicationHome;
import org.springframework.stereotype.Component;
import org.xhtmlrenderer.pdf.ITextRenderer;

import com.lowagie.text.DocumentException;

@Component
public class ThymeleafToPDF {
	
	public ThymeleafToPDF() {};
	
	public void generatePdfFromHtml(String html, Long bookId) throws IOException, DocumentException {
        
//		get path to src/main/resources/static/
		Path resourceDirectory = Paths.get("src","main","resources", "static");
		String absolutePath = resourceDirectory.toFile().getAbsolutePath();
        
        String uploadDir = absolutePath + "/pdf/invoices";
        
        Path uploadPath = Paths.get(uploadDir);
        
//		Create directory if it does not exist
        
        if (!Files.exists(uploadPath)) {
        	Files.createDirectories(uploadPath);
        }

		String outputFolder = uploadDir + File.separator + "rental_invoice_" + bookId +".pdf";
        
//        System.out.println("Output Folder Location user.home : " + outputFolder);
        
        OutputStream outputStream = new FileOutputStream(outputFolder);

        ITextRenderer renderer = new ITextRenderer();
        renderer.setDocumentFromString(html);
        renderer.layout();
        renderer.createPDF(outputStream);

        outputStream.close();
    }
	
}
