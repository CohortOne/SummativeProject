package com.veh.controller;

import java.io.IOException;
import java.security.Principal;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.veh.Booking;
import com.veh.Customer;
import com.veh.ItemNotFoundException;
import com.veh.Tax;
import com.veh.Vehicle;
import com.veh.dao.CustomerDao;
import com.veh.repository.CustomerRepository;
import com.veh.repository.VehicleRepository;
import com.veh.utility.IdentityFileUploadUtility;

@Controller
public class CustomerController {
	
	@Autowired
	private CustomerDao customerDao;
	
	@Autowired
	private CustomerRepository customerRepository;
	
	@Autowired
	private VehicleRepository vehicleRepository;
	
	@Autowired
	private Tax tax;
	
	@GetMapping("/login")
	public String login() {
			return "login";
	}
	
//	@GetMapping("/login_success")
//	public String login_success() {
//			return "/";
//	}
	
	@RequestMapping("/logout-success")
	public String logout() {
			return "logout";

	}
	
	@RequestMapping("/testaop")
	public String TestAop(Principal principal) {
		return "Welcomeaop";
	}
	
	@GetMapping("/list_customer/{thisPage}")
	public String viewHomePage(Model model, 
			@PathVariable(value="thisPage", required = false) Integer thisPage) {
		
		String sortDir = "asc";
		
		if (thisPage == null)
			thisPage = 1;
		else if (thisPage == -1) {
			thisPage = 1;
			sortDir = "desc";
		}			
		
		return findPaginated(thisPage, "custId", sortDir, model);
		
	}
	
	@GetMapping("/page/{pageNo}")
	public String findPaginated(@PathVariable("pageNo") int pageNo,
									@RequestParam("sortField") String sortField,
									@RequestParam("sortDir") String sortDir,
									Model model) {
		
		return listByCustomerAttributes(pageNo, sortField, sortDir, "dummy", "All", null, model);
	}
	
	@GetMapping("/showNewCustomerForm")
	public String showNewCustomerForm(Model model) {
		
		Customer customer = new Customer();
		model.addAttribute("customer", customer);
		return "new_customer";
	}
	
	@PostMapping("/saveCustomer")
	public String saveCustomer(@Valid @ModelAttribute("customer")Customer customer, 
			BindingResult bindingResult,
			RedirectAttributes ra,
			@RequestParam("fileImage") MultipartFile multipartFile) throws IOException {
		
		if (bindingResult.hasErrors())
			return "new_customer";

//		Save the new Customer object to get custId
		Customer savedCust = customerDao.saveTemp4ID(customer);
		
//		If multipartFile is empty just save the customer object to DB
		
		if (!multipartFile.isEmpty()) {
//			Upload Customer identity proof
			IdentityFileUploadUtility identityFileUploadUtility = new IdentityFileUploadUtility();
			
			savedCust = identityFileUploadUtility.upLoadImageFile(savedCust, multipartFile);
		}

		customerDao.saveCustomer(savedCust);
		
		ra.addFlashAttribute("message", "Record for Customer, " + savedCust.getFirstName() + " " + savedCust.getLastName() + ", Successfully Saved.");
		
		return "redirect:/list_customer/-1";
	}
	
	@PostMapping("/saveModifiedCustomer/{thisPage}")
	public String saveModifiedCustomer(@Valid @ModelAttribute("customer")Customer customer,
			@RequestParam("currentImageFileName")String currentImageFileName,
			@PathVariable(value="thisPage") Integer thisPage,
			BindingResult bindingResult,
			RedirectAttributes ra,
			@RequestParam("fileImage") MultipartFile multipartFile) throws IOException {
		
		if (bindingResult.hasErrors())
			return "update_customer";

//		Save the new Customer object to get custId
		Customer savedCust = customerDao.saveTemp4ID(customer);
		
//		If multipartFile is empty just save the customer object to DB
		
		IdentityFileUploadUtility identityFileUploadUtility = new IdentityFileUploadUtility();
		
		if (!multipartFile.isEmpty()) {
//			Upload Customer identity proof			
			savedCust = identityFileUploadUtility.upLoadImageFile(savedCust, multipartFile);
		}
		else {
//			Set back original image filename (only if exists) since user did not upload a new image file	and save Vehicle object	
			if (!(currentImageFileName.equals("NoImageFileFound")))
				savedCust = identityFileUploadUtility.upLoadOriginalImageFile(savedCust, currentImageFileName);
			
		}

		customerDao.saveCustomer(savedCust);
		
		ra.addFlashAttribute("message", "Record for Customer, " + savedCust.getFirstName() + " " + savedCust.getLastName() + ", Successfully Updated.");
		
		return "redirect:/list_customer/" + thisPage;
	}

	@GetMapping("/showFormForUpdate/{thisPage}")
	public String showFormForUpdate(@RequestParam("custId")Long custId, 
			@PathVariable(value="thisPage") Integer thisPage,
			Model model) {
		
		// Get Employee from the Service 
		Customer customer = customerDao.getCustomerById(custId);
		
		String currentImageFileName = customer.getIdentityProof();
		
		// set employee as a model attribute to pre-populate the form and make a copy of the image filename if available
		model.addAttribute("customer", customer);
		model.addAttribute("thisPage", thisPage);
		
		if (currentImageFileName != null)
			model.addAttribute("currentImageFileName", currentImageFileName);
		else
			model.addAttribute("currentImageFileName", "NoImageFileFound");
		
		return "update_customer";
	}
	
	@GetMapping("/fromBookingToShowFormForUpdate/{custId}/{vehId}")
	public String fromBookingToShowFormForUpdate(@PathVariable(value="custId")Long custId,
			@PathVariable(value="vehId")Long vehId,
			Model model) {
		
		// Get Employee from the Service 
		Customer customer = customerDao.getCustomerById(custId);
		
		String currentImageFileName = customer.getIdentityProof();
		
		// set employee as a model attribute to pre-populate the form and make a copy of the image filename if available
		model.addAttribute("customer", customer);
		model.addAttribute("vehId", vehId);
		
		if (currentImageFileName != null)
			model.addAttribute("currentImageFileName", currentImageFileName);
		else
			model.addAttribute("currentImageFileName", "NoImageFileFound");
		
		return "from_booking_to_update_customer";
	}
	
	@PostMapping("/saveModifiedCustomerAndReturnToBooking/{vehId}")
	public String saveModifiedCustomerAndReturnToBooking(@Valid @ModelAttribute("customer")Customer customer,
			@RequestParam("currentImageFileName")String currentImageFileName,
			@PathVariable(value="vehId") Long vehId,
			BindingResult bindingResult,
			RedirectAttributes ra,
			Model model,
			@RequestParam("fileImage") MultipartFile multipartFile) throws IOException {
		
		if (bindingResult.hasErrors())
			return "from_booking_to_update_customer";

//		Save the new Customer object to get custId
		Customer savedCust = customerDao.saveTemp4ID(customer);
		
//		If multipartFile is empty just save the customer object to DB
		
		IdentityFileUploadUtility identityFileUploadUtility = new IdentityFileUploadUtility();
		
		if (!multipartFile.isEmpty()) {
//			Upload Customer identity proof			
			savedCust = identityFileUploadUtility.upLoadImageFile(savedCust, multipartFile);
		}
		else {
//			Set back original image filename (only if exists) since user did not upload a new image file	and save Vehicle object	
			if (!(currentImageFileName.equals("NoImageFileFound")))
				savedCust = identityFileUploadUtility.upLoadOriginalImageFile(savedCust, currentImageFileName);
			
		}

		customerDao.saveCustomer(savedCust);
		
//		Get current GST percentage
		Double gst = Double.valueOf(tax.getGst());
		
//		Get Vehicle and Booking Objects
		Vehicle theVehicle = vehicleRepository.getVehByVehId(vehId);
		Booking theBooking = new Booking();
		
		model.addAttribute("customer", savedCust);
		model.addAttribute("vehicle", theVehicle);
		model.addAttribute("booking",  theBooking);
		model.addAttribute("gst", gst);
		
		ra.addFlashAttribute("message", "Record for Customer, " + savedCust.getFirstName() + " " + savedCust.getLastName() + ", Successfully Updated.");
		
		return "new_booking_form";
	}

	@GetMapping("/deleteCustomer")
	public String deleteCustomer(@RequestParam("custId") Long custId, 
								RedirectAttributes ra) {
		
	 // call delete employee method
		
	 int count = customerRepository.deleteByCustId(custId);
	 
//	 this.customerDao.deleteCustomerById(custId);
	 
	 if (count > 0)
		 ra.addFlashAttribute("message", "Customer ID " + custId + " Successfully Deleted.");
	 else
		 ra.addFlashAttribute("failedMessage", "Customer ID " + custId + " Cannot Be Deleted.");
	 
	 return "redirect:/list_customer/1";
	}
	
	@GetMapping("/getCustomerDetailsByName")
	public String getCustDetailsByName(Model model) {
		
		Customer theCustomer = new Customer();
		
		model.addAttribute("customer", theCustomer);
		return "search_customer_details_by_customer_name";
	}
	
	@PostMapping("/searchCustDetailsByCustName")
	public String searchCustDetailsByCustName(@Valid @ModelAttribute("customer")Customer theCustomer,
			Model model) {
		
		//get required customer object based on First and Last Names.
		Customer tempCustomer = customerRepository.getCustomerByFirstNameAndLastNameAllIgnoreCase(theCustomer.getFirstName(), theCustomer.getLastName());
		
//		if no record found, throw exception
		if (tempCustomer == null) {
			throw new ItemNotFoundException("No Customer record found under Customer Name : " 
					+ theCustomer.getFirstName() + " " + theCustomer.getLastName(), "/getCustomerDetailsByName");
		}
		
		String selectedProperty = "dummy"; //dummy data
		String selectedOption = "Name";
		Long custId = tempCustomer.getCustId();
		
		return listByCustomerAttributes(1, "custId", "asc", selectedProperty, selectedOption,
				 custId, model);
	}
	
	@GetMapping("/getCustomerDetailsByEmail")
	public String getCustDetailsByEmail(Model model) {
		
		Customer theCustomer = new Customer();
		
		model.addAttribute("customer", theCustomer);
		return "search_customer_details_by_customer_email";
	}
	
	@PostMapping("/searchCustDetailsByCustEmail")
	public String searchCustDetailsByCustEmail(@Valid @ModelAttribute("customer")Customer theCustomer,
			Model model) {
				
		String selectedProperty = theCustomer.getEmail();
		String selectedOption = "Email";
		Long custId = null; //dummy data
		
		return listByCustomerAttributes(1, "custId", "asc", selectedProperty, selectedOption,
				 custId, model);
	}
	
	@GetMapping("/getCustomerDetailsByDrvLicNum")
	public String getCustDetailsByDrvLicNum(Model model) {
		
		Customer theCustomer = new Customer();
		
		model.addAttribute("customer", theCustomer);
		
		return "search_customer_details_by_customer_driving_lic_number";
	}
	
	@PostMapping("/searchCustDetailsByCustDrvLicNum")
	public String searchCustDetailsByCustDrvLicNum(@Valid @ModelAttribute("customer")Customer theCustomer,
			Model model) {
		
		String selectedProperty = theCustomer.getDrivingLicNum();
		String selectedOption = "DrivingLicense";
		Long custId = null; //dummy data
		
		return listByCustomerAttributes(1, "custId", "asc", selectedProperty, selectedOption,
				 custId, model);
	}
		
	@GetMapping("/customerPageByAttribute/{pageNumber}")
	public String listByCustomerAttributes(@PathVariable("pageNumber") int currentPage, 
							 @Param("sortField") String sortField,
							 @Param("sortDir") String sortDir,
							 @Param("selectedProperty")String selectedProperty,
							 @Param("selectedOption")String selectedOption,
							 @Param("objectId")Long objectId,
							 Model model) {
		
		Sort sort = Sort.by(sortField);
		sort = sortDir.equals("asc") ? sort.ascending() : sort.descending();
		
		Pageable paging = PageRequest.of(currentPage-1, 5, sort); //maximum of 5 items per page
		
//		Initialise variables
		Page<Customer> page = null;
		Customer tempCustomer = null;
		
//		check if objectId is not null, then, find the required Users object via its ID
		if (objectId != null)
			tempCustomer = customerRepository.getByCustId(objectId);
		
		model.addAttribute("objectId", objectId);
		model.addAttribute("selectedOption", selectedOption);
		model.addAttribute("selectedProperty", selectedProperty);
		
		switch (selectedOption) {
			case "All":
				page = customerRepository.findAll(paging);
				break;
				
			case "Name":
				page = customerRepository.findCustomerByCustId(objectId, paging);		
				break;
				
			case "Email":
				page = customerRepository.findCustomerByEmail(selectedProperty, paging);
				
//				if no record found, throw exception
				if (page.isEmpty()) {
					throw new ItemNotFoundException("No Customer record found for "
							+ "Customer Email : " + selectedProperty, "/getCustomerDetailsByEmail");
				}

				break;
				
			case "DrivingLicense":
				page = customerRepository.findCustomerByDrivingLicNum(selectedProperty, paging);
				
//				if no record found, throw exception
				if (page.isEmpty()) {
					throw new ItemNotFoundException("No Customer record found for "
							+ "Driving License Number : " + selectedProperty, "/getCustomerDetailsByDrvLicNum");
				}

				break;
				
//			default:
//				page = customerRepository.getByTheCustomer(tempCustomer, paging);
//				break;			
		}
		
		int totalPages = page.getTotalPages();
		long totalItems = page.getTotalElements();
		
//		System.out.println("total number of elements " + totalItems);
		
		List<Customer> listCustomers = page.getContent();
		
//		System.out.println(("Booking List : " + listBookings));
		
		model.addAttribute("listCustomers", listCustomers);
		model.addAttribute("currentPage", currentPage);
		model.addAttribute("totalItems", totalItems);
		model.addAttribute("totalPages", totalPages);
		model.addAttribute("sortField", sortField);
		model.addAttribute("sortDir", sortDir);
						
		String reverseSortDir = sortDir.equals("asc") ? "desc" : "asc";
		model.addAttribute("reverseSortDir", reverseSortDir);
		
		return "list_customers_by_attribute";
	}

	@GetMapping("/displayChosenCustomer")
	public String displayChosenCustomer(@RequestParam("custId")Long custId, 
				@RequestParam("currentPage")Integer currentPage,
				Model model) {
		
		model.addAttribute("empty", "empty");
		
		Customer theCustomer = customerRepository.getByCustId(custId);
		
		return searchCustomerByIdFromBooking(theCustomer, currentPage, model);
	}
	
	@GetMapping("/searchCustomerByIdFromBooking")
	public String searchCustomerByIdFromBooking(@Valid @ModelAttribute("customer")Customer theCustomer,
				Integer currentPage,
				Model model){
		
		model.addAttribute("currentPage", currentPage);
		model.addAttribute("customer", theCustomer);
					
	return "list_single_customer";			
	}
}
