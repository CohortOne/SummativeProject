package com.veh;

public class VehAppException {
	
	public VehAppException(int status, String errorMessage, String dateTimeStamp, String fromURL) {
		this.status = status;
		this.errorMessage = errorMessage;
		this.dateTimeStamp = dateTimeStamp;
		this.fromURL = fromURL;
	}
	
	public VehAppException() {};

	private int status;
	private String errorMessage;
	private String dateTimeStamp;
	private String fromURL;
	
	public String getFromURL() {
		return fromURL;
	}

	public void setFromURL(String fromURL) {
		this.fromURL = fromURL;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public String getDateTimeStamp() {
		return dateTimeStamp;
	}

	public void setDateTimeStamp(String dateTimeStamp) {
		this.dateTimeStamp = dateTimeStamp;
	}

}
