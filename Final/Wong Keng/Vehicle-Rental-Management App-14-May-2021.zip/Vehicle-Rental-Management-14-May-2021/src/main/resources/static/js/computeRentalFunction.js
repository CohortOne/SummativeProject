// JavaScript program to calculate the no. of days between two dates and compute charges 

function computeRental(calledFrom) {
	
	const button = document.querySelector("#bookVeh");
	const startDate = document.querySelector("#rentalStartDate");
	const expectedReturnDate = document.querySelector("#rentalExpectedReturnDate");
	const actualReturnDate = document.querySelector("#rentalActualReturnDate");
	const hireRate = document.querySelector("#hireRate");
	const formDuration = document.querySelector("#duration");
	const formTotalCharge = document.querySelector("#totalCharge");
	const formRate = document.querySelector("#dailyRate");
	const formModDateTime = document.querySelector("#modifiedDate");
	const computeButton = document.querySelector("#computeRental");
	const returnDateError = document.querySelector("#returnDateError");
	const clickMe = document.querySelector("#clickMe");
	const gst = document.querySelector("#gst");
	
	
	//initialise variables and GST
	let totalRental = 0;
	let totalCharge = "";
	let duration = 0;
	const GST = parseFloat(gst.innerText)*0.01;
		
	if (calledFrom == "computeRentalReturn") {
	
			//Disable #rentalStartDate and #rentalExpectedReturnDate
			startDate.disabled = true;
			expectedReturnDate.disabled = true;	
	}

	button.disabled = true; //setting button state to disabled
	
	//Set blinking message to display below the cash register icon
	clickMe.innerHTML = "Click To Compute Total";
	clickMe.classList.add("blinking");

	computeButton.addEventListener("click", () => {
		
		//Remove blinking message
		clickMe.style.display = "none";
	
		//Convert hireRate from String to Float
		const dailyRate = parseFloat(hireRate.innerText);
		
		//assign Start and Return Dates as valueAsNumber to variables
	
		let startDateValueAsNum = startDate.valueAsNumber;
		let returnDateValueAsNum = 0;
		
		if ((calledFrom == "computeRentalModify") || (calledFrom == "computeRental")) {
			returnDateValueAsNum = expectedReturnDate.valueAsNumber;
		}
		else {
			
			//means the call is from the booking return page
			returnDateValueAsNum = actualReturnDate.valueAsNumber;
		}
																
		//To calculate time difference between two dates
		let diff_In_Time = returnDateValueAsNum - startDateValueAsNum;
				
		if (diff_In_Time < 0) {
			
			returnDateError.innerText = "Return Date must be later than Rental Start Date!";			
		
		}
		else {
			returnDateError.innerText = "";
			
			let diff_In_Days = diff_In_Time / (1000 * 3600 * 24); // To calculate the no. of days between two dates
		
			//Check if actual Return time is greater than 1 hr from expected Return time
			if ((diff_In_Days - Math.floor(diff_In_Days)) <= 0.042) {
				
				duration = Math.floor(diff_In_Days);
				
			} else {
				
				duration = Math.floor(diff_In_Days)+1;
				
			}
			
			totalRental = duration * dailyRate * (1+GST);
			
			totalCharge = totalRental.toFixed(2);
			
			//Update the respective rate, duration and charge fields
			
			formDuration.value = duration;
			formTotalCharge.value = totalCharge;
			formRate.value = dailyRate;
			formModDateTime.value = currentDateTimeStr();
			
			stateHandle(formTotalCharge);
		}
	})	 

}