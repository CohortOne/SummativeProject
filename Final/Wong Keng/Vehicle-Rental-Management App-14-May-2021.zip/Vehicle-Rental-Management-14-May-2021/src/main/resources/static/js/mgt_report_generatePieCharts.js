function plotMonthlyCharts(requiredMonths) {
	
/*	console.log ("requiredMonths : " + requiredMonths); */
	
	$.ajax({
		url: 'mgt_showPieChart4Model',
		data: requiredMonths,
		success: function(result){
			let model = JSON.parse(result);
			
			let containerId = 'container_model_piechart';
			let series = [];
			let data = [];
			
			for (let i = 0; i < (model.carModel).length; i++) {
				
				let object = {};
				object.name = (model.carModel)[i].toUpperCase();
				object.y = (model.carData)[i];
				data.push(object);
							
			}
			
			let seriesObject = {
				name: 'Car Model',
				colorByPoint: true,
				data: data
			}
				
			series.push(seriesObject);
		
			drawPieChart(series, containerId);
			}
	})
	
	$.ajax({
		url: 'mgt_showRevenuePieChart4Model',
		data: requiredMonths,
		success: function(result){
			let model = JSON.parse(result);
			
			let containerId = 'container_revenue_piechart';
			let series = [];
			let data = [];
			
			for (let i = 0; i < (model.carModel).length; i++) {
				
				let object = {};
				object.name = (model.carModel)[i].toUpperCase();
				object.y = (model.carData)[i];
				data.push(object);
							
			}
			
			let seriesObject = {
				name: 'Car Model',
				colorByPoint: true,
				data: data
			}
				
			series.push(seriesObject);
			
			drawRevenuePieChart(series, containerId);
			}
	})
}

function drawPieChart(series, containerId) {
		
	Highcharts.chart(containerId, {
    chart: {
        plotBackgroundColor: null,
		backgroundColor: null,
        plotBorderWidth: null,
        plotShadow: false,
        type: 'pie',
		width: 500
    },

    title: {
        text: ''
    },

	credits: {
		    enabled: false
		},
				
    tooltip: {
        pointFormat: '<b>{point.y}</b>'
    },

    accessibility: {
        point: {
            valueSuffix: ''
        }
    },

    plotOptions: {
        pie: {
			borderColor: '#000000',
            allowPointSelect: true,
            cursor: 'pointer',
            dataLabels: {
               enabled: true,
               format: '<b>{point.name}</b>: {point.y}'
            }
        }
    },
    series: series
	});	
}

function drawRevenuePieChart(series, containerId) {
	
	Highcharts.setOptions({
        lang: {
            thousandsSep: ','
		}
    });
		
	Highcharts.chart(containerId, {
    chart: {
        plotBackgroundColor: null,
		backgroundColor: null,
        plotBorderWidth: null,
        plotShadow: false,
        type: 'pie',
		width: 500
    },

    title: {
        text: ''
    },

	credits: {
		    enabled: false
		},
				
    tooltip: {
			pointFormat: '<b>${point.y: .2f}</b>'
    },

    accessibility: {
        point: {
            valueSuffix: ''
        }
    },

    plotOptions: {
        pie: {
			borderColor: '#000000',
            allowPointSelect: true,
            cursor: 'pointer',
            dataLabels: {
                enabled: true,
				formatter: function () {
                            return this.point.name + ': $' + Highcharts.numberFormat(this.y,2);
                 			}
            }
        }
    },

    series: series
	});	
}