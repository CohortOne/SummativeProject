//Function to check credit card expiry date

$(document).ready(function () {
	
	const ccExpiryDateError = document.querySelector('#ccExpiryDateError');
	const startDate = document.querySelector("#rentalStartDate");
	const expectedReturnDate = document.querySelector("#rentalExpectedReturnDate");
	const clickMe = document.querySelector("#clickMe");
	
	let ccExpiryDate = $("#ccExpiryDate").text();
	let ccExpiryDateValueAsNum = Date.parse(ccExpiryDate);

	let currentDate = new Date();
	let currentDateValueAsNum = Date.parse(currentDate);

/*	console.log("ccExpiryDate : " + ccExpiryDate);
	console.log("ccExpiryDateValueAsNum : " + ccExpiryDateValueAsNum);
	
	console.log("currentDate : " + currentDate);	
	console.log("currentDateValueAsNum : " + currentDateValueAsNum);
*/
	
	if (currentDateValueAsNum - ccExpiryDateValueAsNum > 0) {
		
		//Credit Card has expired.
		ccExpiryDateError.innerHTML = "Customer's Credit Card Has Expired! Please click on the 'Update Customer' button to update the credit card before proceeding."
		ccExpiryDateError.classList.add("blinkingCCExpiryMsg");
		
		//Disable #rentalStartDate and #rentalExpectedReturnDate
		startDate.disabled = true;
		expectedReturnDate.disabled = true;
		
		//Hide Book Vehicle button and Show Update Customer button
		$("#bookVeh").hide();
		$("#updateCustDetails").show();
		
		//Remove blinking message below cash register icon
		clickMe.style.display = "none";
		
	} else {
		
		//Credit Card has not expired.
		ccExpiryDateError.innerHTML = "";
		ccExpiryDateError.classList.remove("blinkingCCExpiryMsg");
		
		//Enable #rentalStartDate and #rentalExpectedReturnDate
		startDate.disabled = false;
		expectedReturnDate.disabled = false;
		
		//Show Book Vehicle button and Hide Update Customer button
		$("#bookVeh").show();
		$("#updateCustDetails").hide();
		
	}

})
