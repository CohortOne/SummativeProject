// JavaScript to activate and deactivate the form submit button for new_customer form

$(document).ready(function () {
	
	enableDisableSubmitButton("4NewCustomerForm");
						
})