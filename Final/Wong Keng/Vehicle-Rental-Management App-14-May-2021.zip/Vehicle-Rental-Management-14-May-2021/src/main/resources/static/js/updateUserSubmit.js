// JavaScript program for new_user.html, update_user_password.html and update_user_reset_password.html

$(document).ready(function () {
	
	$("#userForm").validate({
		rules: {
			newPassword: {
				required: true,
				minlength: 5
			},
			reEnterNewPassword: {
				required: true,
				minlength: 5,
				equalTo: "#newPassword"
			},
			userRoles: {
				required: true,
			}
		},
		messages: {
			newPassword: {
				required: "Please provide a password",
				minlength: "Your password must be at least 6 characters long"
			},
			reEnterNewPassword: {
				required: "Please re-enter the same password",
				minlength: "Your password must be at least 6 characters long",
				equalTo: "Passwords do not match. Please re-enter."
			},
			userRoles: {
				rqeuired: "Role must be selected."
			}
		}		
	});				
});