// JavaScript validation program for new_vehicle.html

$(document).ready(function () {
	
	$("#newVehicleForm").validate({
/*		errorPlacement: function(error, element){
			if (element.attr("name") == "userRoles") {
     			error.insertAfter(".roleLabel");
  			} else {
			     error.insertAfter(element);
			}
	    },
*/
		rules: {
			vehRegNum:  {
				required: true,
				minlength: 5,
				maxlength: 8				
			},
			brand: {
				required: true,
				minlength: 3,
				maxlength: 15				
			},
			model: {
				required: true,
				minlength: 3,
				maxlength: 15				
			},
			hireRate: "required",
		},
		messages: {
			vehRegNum: {
				required: "Vehicle Registration Number is mandatory",
				minlength: "Registration Number minimum length is 5 characters",
				maxlength: "Registration Number maximum length is 8 characters"
			},
			brand: {
				required: "Please enter vehicle Brand",
				minlength: "Brand minimum length is 3 characters",
				maxlength: "Brand maximum length is 15 characters"
			},
			model: {
				required: "Please enter vehicle Model",
				minlength: "Model minimum length is 3 characters",
				maxlength: "Model maximum length is 15 characters"
			},
			hireRate: "Please enter daily rate of vehicle",
		}		
	});				
});