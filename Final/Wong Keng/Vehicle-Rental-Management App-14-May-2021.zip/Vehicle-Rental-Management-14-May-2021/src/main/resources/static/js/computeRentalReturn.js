// JavaScript program to calculate the no. of days between two dates and compute charges 

$(document).ready(function () {
	
	computeRental("computeRentalReturn");
							
});

function enableStartAndExpectedDateField() {
	
	const startDate = document.querySelector("#rentalStartDate");
	const expectedReturnDate = document.querySelector("#rentalExpectedReturnDate");
	
	//Enable #rentalStartDate and #rentalExpectedReturnDate
	startDate.disabled = false;
	expectedReturnDate.disabled = false;		
		
};