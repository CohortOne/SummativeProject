package com.example.demo.Service;
import java.util.List;

import com.example.demo.entity.Car;
public interface CarService {

    public List<Car> findAll();

    public Car findById(int id);

    public void save(Car car);

    public void deleteById (int id);

}
