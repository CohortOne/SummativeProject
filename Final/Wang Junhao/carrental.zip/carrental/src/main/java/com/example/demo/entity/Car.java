package com.example.demo.entity;

import javax.persistence.*;

import com.example.demo.locateDate.DateTimeInterval;

import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.*;
import java.util.function.Supplier;
import java.util.stream.Collectors;

@Entity
@Table(name = "car")
public class Car {

    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @Column(name = "brand")
    private String brand;

    @Override
	public String toString() {
		return "Car [id=" + id + ", brand=" + brand + ", model=" + model + ", description=" + description + ", status="
				+ status + ", priceForADay=" + priceForADay + ", imageUrl=" + imageUrl + ",  reservations=" + reservations + "]";
	}

	@Column(name = "model")
    private String model;

    @Column(name = "desciption")
    private String description;

    @Column(name = "status")
    private String status;

    @Column(name = "price_for_a_day")
    private int priceForADay;

    @Column(name = "image_url")
    private String imageUrl;
//
//    @ManyToOne(cascade = {CascadeType.PERSIST, CascadeType.MERGE})
//    @JoinTable(name = "car_location",
//            joinColumns = @JoinColumn(name = "car_id"),
//            inverseJoinColumns = @JoinColumn(name = "reservation_id"))
//    
//    private Reservation reservation;

    @OneToMany(mappedBy = "car", cascade = CascadeType.ALL)
    private List<Reservation> reservations;

    public Car() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getPriceForADay() {
        return priceForADay;
    }

    public void setPriceForADay(int priceForADay) {
        this.priceForADay = priceForADay;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public void refreshStatus() {
        List<DateTimeInterval> ongoingReservations = getOngoingResv();

        if (ongoingReservations.size() == 0) {
            setStatus("available");
        } else
            setStatus("unavailable");
    }

    public List<DateTimeInterval> getOngoingResv() {

        return reservations
                .stream()
                .map(reservation -> new DateTimeInterval(dateToLocalDate(reservation.getRentDate()), dateToLocalDate(reservation.getReturnDate())))
                .filter(reservation -> reservation.contains(LocalDate.now()))
                .collect(Collectors.toList());
    }

    public Date getOngoingResvReturnDate() {
        Optional<Date> ongReturnDate = getOngoingResv()
                .stream()
                .map(ongoingResv -> localDatetoDate(ongoingResv.getEnd()))
                .findAny();

        Date returnDate = null;
        if (status.equals("available")) {
            return null;
        } else {
            if (ongReturnDate.isPresent()) {
                returnDate = ongReturnDate.get();
            } else {
                throw new RuntimeException("Return date does not exist");
            }
        }
        return returnDate;
    }



    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }


    public List<Reservation> getReservations() {
        return reservations.stream()
                .sorted(((o1, o2) -> o1.getRentDate().compareTo(o2.getRentDate())))
                .collect(Collectors.toList());
    }

    public void setReservations(List<Reservation> reservations) {
        this.reservations = reservations;
    }

    public List<Reservation> getUpcomingReservations() {
        List<Reservation> upcomingReservations = new ArrayList<>();

        upcomingReservations = reservations.stream()
                .filter(reservation -> dateToLocalDate(reservation.getRentDate()).isAfter(LocalDate.now()))
                .sorted(((o1, o2) -> (o1.getRentDate().compareTo(o2.getRentDate()))))
                .collect(Collectors.toList());

        return upcomingReservations;
    }


    public List<Reservation> getUpcomingReservationsAfterThisReservation(Date rentDate){
        List<Reservation> upcomingReservationsAfterThisReservation = getUpcomingReservations()
                .stream()
                .filter(reservation -> reservation.getRentDate().after(rentDate))
                .collect(Collectors.toList());

        return upcomingReservationsAfterThisReservation;

    }



    public List<DateTimeInterval> getUpcomingReservationIntervals() {
        List<DateTimeInterval> upcomingReservationsDates = getUpcomingReservations()
                .stream()
                .map(reservation -> new DateTimeInterval(dateToLocalDate(reservation.getRentDate()), dateToLocalDate(reservation.getReturnDate())))
                .collect(Collectors.toList());

        return upcomingReservationsDates;
    }

    public boolean doesUpcomingReservationsContainsDate(Date date) {
        boolean result;
        if (getUpcomingReservationIntervals()
                .stream()
                .filter(interval -> interval.contains(dateToLocalDate(date)))
                .findFirst().isPresent()) {
            result = true;}
        else {
            result = false;
        }
        return result;
    }



    public void addReservation(Reservation reservation) {
        if (this.reservations.size() == 0) {
            this.reservations = Arrays.asList(reservation);
        } else {
            this.reservations.add(reservation);
        }
    }

    public void deleteReservation(Reservation reservation) {
        this.reservations.remove(reservation);
    }

    public LocalDate dateToLocalDate(Date date) {
        Instant instantDate = date.toInstant();
        LocalDate newLocalDate = instantDate.atZone(ZoneId.systemDefault()).toLocalDate();
        return newLocalDate;
    }

    public Date localDatetoDate(LocalDate localDate) {
        return java.util.Date.from(localDate.atStartOfDay()
                .atZone(ZoneId.systemDefault())
                .toInstant());
    }


    
    
    }


