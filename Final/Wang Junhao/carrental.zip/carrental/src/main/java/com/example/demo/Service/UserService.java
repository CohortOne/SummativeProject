package com.example.demo.Service;

import java.util.List;

import com.example.demo.entity.User;

public interface UserService {

    public User findUserByUsername(String username);

    public void saveUser(User user);
    
    public List<User>getAllUser();

}
