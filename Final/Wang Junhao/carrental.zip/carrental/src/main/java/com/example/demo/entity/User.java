package com.example.demo.entity;
import javax.persistence.*;
import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Entity
@Table(name="users")
public class User {

    @Id
    @GeneratedValue(strategy=GenerationType.AUTO)
    @Column(name="id")
    private int id;

    @Column(name="name")
    private String name;

    @Column(name="nric")
    private String nric;

    @Column(name="username")
    private String username;
    
    public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getNric() {
		return nric;
	}

	public void setNric(String nric) {
		this.nric = nric;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getImageUrl() {
		return imageUrl;
	}

	public void setImageUrl(String imageUrl) {
		this.imageUrl = imageUrl;
	}

	@Column(name="address")
    private String address;
    
    @Column(name = "image_url")
    private String imageUrl;

   

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	@Column(name="password")
    private String password;

    @Column(name="active")
    private int active;

    @ManyToMany(cascade=CascadeType.ALL, fetch=FetchType.EAGER)
    @JoinTable(name="user_role",
            joinColumns=@JoinColumn( name="user_id"),
            inverseJoinColumns=@JoinColumn(name="role_id"))
    private List<Role> roles;

    @OneToMany(mappedBy="user", cascade={CascadeType.PERSIST, CascadeType.MERGE,
            CascadeType.DETACH, CascadeType.REFRESH})
    private List<Reservation> reservations;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

   

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public int getActive() {
        return active;
    }

    public void setActive(int active) {
        this.active = active;
    }

    public List<Role> getRoles() {
        return roles;
    }

    public void setRoles(List<Role> roles) {
        this.roles = roles;
    }

    public List<Reservation> getReservations() {
        return reservations.stream()
                .sorted(((o1, o2) -> o1.getRentDate().compareTo(o2.getRentDate())))
                .collect(Collectors.toList());
    }

    public void addReservation (Reservation reservation) {
        if (this.reservations.size() == 0){
            this.reservations = Arrays.asList(reservation);
        } else {
            this.reservations.add(reservation);
        }
    }

    public boolean getIsAdmin(){
        boolean result;

        List<String> stringRoles = roles.stream()
                .map(role -> role.getRole())
                .collect(Collectors.toList());

        if (stringRoles.contains("ADMIN")){
            result = true;
        } else
            result = false;
        return result;
    }
}

