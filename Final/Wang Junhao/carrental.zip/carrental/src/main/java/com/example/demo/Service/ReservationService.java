package com.example.demo.Service;

import java.util.List;

import com.example.demo.entity.Reservation;

public interface ReservationService {

    public List<Reservation> findAll();

    public Reservation findById(int id);

    public void save(Reservation reservation);

    public void deleteById (int id);
}
