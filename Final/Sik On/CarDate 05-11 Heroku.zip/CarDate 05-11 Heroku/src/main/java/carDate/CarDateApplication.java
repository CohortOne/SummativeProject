package carDate;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.session.jdbc.config.annotation.web.http.EnableJdbcHttpSession;
import org.springframework.transaction.annotation.EnableTransactionManagement;


@SpringBootApplication
@EnableJdbcHttpSession
@ComponentScan(basePackages= {"carDate"})
public class CarDateApplication {

	public static void main(String[] args) {
		SpringApplication.run(CarDateApplication.class, args);
	}

}
