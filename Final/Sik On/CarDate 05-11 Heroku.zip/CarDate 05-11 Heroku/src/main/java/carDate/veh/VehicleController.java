package carDate.veh;

import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import carDate.Home;
import carDate.cust.Customer;
import carDate.cust.CustomerDao;
import carDate.pict.Picture;
import carDate.pict.PictureStorageService;
import carDate.pict.UploadForm;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

	@Api(value = "VehicleController", description = "Vehicle maintenance")
	@Controller
	public class VehicleController {

		@Autowired
		private Home home;

		@Autowired
		private CustomerDao customerDao;

		@Autowired
		private VehicleDao vehicleDao;

		@Autowired
		private VehStatusRepo vehStatusRepo;

		@Autowired
		private PictureStorageService storageService;

		String currFunc;
		int currPage;
		int totalPages;
		int pageSize;
		String sortField;
		String sortDirection;
		long pinCustId;
		long pinVehId;
		long pictsVehId;
		String keyword;
		int onlyHired; // 0 = show all Vehicles (default), 1 = show only those currently Hired
		
		private boolean loadSessionAttributes(HttpSession session) {
			currFunc = (session.getAttribute("currFunc")==null)?"":(String) session.getAttribute("currFunc");
			if (!currFunc.equals("veh")) {
				currFunc = "veh";
				session.setAttribute("currFunc", currFunc);
			}
			
			currPage = (session.getAttribute("vehCurrPage")==null)?1:(int) session.getAttribute("vehCurrPage");
			session.setAttribute("vehCurrPage", currPage);
			
			totalPages = (session.getAttribute("vehTotalPages"))==null?1:(int) session.getAttribute("vehTotalPages");
			session.setAttribute("vehTotalPages", totalPages);

			pageSize = (session.getAttribute("vehPageSize")==null)?5:(int) session.getAttribute("vehPageSize");
			session.setAttribute("vehPageSize", pageSize);

			sortField = (session.getAttribute("vehSortField")==null)?"vehId":(String) session.getAttribute("vehSortField");
			session.setAttribute("vehSortField", sortField);
			
			sortDirection = (session.getAttribute("vehSortDirection")==null)?"ASC":(String) session.getAttribute("vehSortDirection");
			session.setAttribute("vehSortDirection", sortDirection);

			pinCustId = (session.getAttribute("pinCustId")==null)?0:(long) session.getAttribute("pinCustId");
			session.setAttribute("pinCustId", pinCustId);

			pictsVehId = (session.getAttribute("pictsVehId")==null)?0:(long) session.getAttribute("pictsVehId");
			session.setAttribute("pictsVehId", pictsVehId);

			pinVehId = (session.getAttribute("pinVehId")==null)?0:(long) session.getAttribute("pinVehId");
			session.setAttribute("pinVehId", pinVehId);

			keyword = (session.getAttribute("vehKeyword")==null)?"":(String) session.getAttribute("vehKeyword");
			session.setAttribute("vehKeyword", keyword);

			onlyHired = (session.getAttribute("onlyHired")==null)?0:(int) session.getAttribute("onlyHired");
			session.setAttribute("onlyHired", onlyHired);

			return true;
		}

		
		@GetMapping("/vehPage/{pageMvnt}")
		public String vehPaginated(@PathVariable(value="pageMvnt") int pageMvnt,
				Model model, HttpSession session) {
			if ((!home.hasRole("MANAGER")) && (!home.hasRole("USER"))) {return "/403";}
			if (!loadSessionAttributes(session)) {return "redirect:/";}

			// set-up current page number
			switch (pageMvnt) {
			    case -9: currPage = 1; break;                            // go to first page
			    case -1: currPage = currPage > 1? currPage - 1:1; break; // go to prev page  
			    case  0: break;                                          // stay at curr page
			    case  1: currPage = currPage < totalPages? currPage + 1:totalPages; break;  // go to next page
			    case  9: currPage = totalPages; break;                   // go to last page
			    default: currPage = 1;
			}
			if (currPage<=0) {currPage=1;}

			// get a page of Vehicle records
			session.setAttribute("vehCurrPage", currPage);
			Page <Vehicle> page = vehicleDao.vehPaginated(currPage, pageSize, keyword, onlyHired, sortField, sortDirection);
			session.setAttribute("vehTotalPages", page.getTotalPages());
			if ((currPage > 1) && (currPage > page.getTotalPages())) {return vehPaginated(9, model, session);}
			
			List <Vehicle> listVehs = page.getContent();
			model.addAttribute("listVehs", listVehs);
			session.setAttribute("vehTotalItems", page.getTotalElements());

			// set-up the pinned Customer.
			Customer pinCust = new Customer();
			if (pinCustId>0) {
				pinCust = customerDao.getCustomerById(pinCustId);
				pinCustId = pinCust.getCustId();
			}
			model.addAttribute("pinCust", pinCust);
			session.setAttribute("pinCustId", pinCustId);
			
			// set-up the pinned Vehicle.
			Vehicle pinVeh = new Vehicle();
			if (pinVehId>0) {
				pinVeh = vehicleDao.getVehicleById(pinVehId);
				pinVehId = pinVeh.getVehId();
			}
			model.addAttribute("pinVeh", pinVeh);
			session.setAttribute("pinVehId", pinVehId);

			// set-up the new Vehicle, which is a record for user to edit to create new Vehicle or update an existing Vehicle.
			Vehicle newVeh = (Vehicle)model.getAttribute("newVeh");
			if (newVeh==null) {
				newVeh = new Vehicle();
				newVeh.setVehStatus(vehStatusRepo.findByName("FREE"));
			}
			model.addAttribute("newVeh", newVeh);

			// set-up the pictured Vehicle.  This picture Vehicle is loaded so that the Picture of that Vehicle can be edited on a Modal.
			Vehicle pictsVeh = new Vehicle();
			if (pictsVehId>0) {
				pictsVeh = vehicleDao.getVehicleById(pictsVehId);
				pictsVehId = pictsVeh.getVehId();
			}
			model.addAttribute("pictsVeh", pictsVeh);
			session.setAttribute("pictsVehId", pictsVehId);

			List<Picture> listVehPicts = null;
			
			if (pictsVehId>0) {
				listVehPicts = pictsVeh.getPictures().stream().sorted(Comparator.comparingLong(Picture::getPictId)).collect(Collectors.toList());
			}
			
			model.addAttribute("listVehPicts", listVehPicts);
			
			List<VehStatus> listVehStatus = vehStatusRepo.findAll();
			model.addAttribute("listVehStatus", listVehStatus);
			
			// render the loaded data to Vehicles.html
			return "Vehicles";
		}
		
		
		@GetMapping("/vehFilter") // set-up a session.keyword to filter Vehicles
		public String vehFilter(
				@RequestParam("keyword") String keyword, 
				Model model, HttpSession session) {
			
			session.setAttribute("vehKeyword", keyword);
			return vehPaginated(0, model, session);
		}

		
		@GetMapping("/vehOnlyHired/{onlyHired}") // set-up a session.indicator to show only Vehicles with current Hire (1), or show all Vehicles (0 default).
		public String hireVeh(@PathVariable(value = "onlyHired") int onlyHired, 
	            Model model, HttpSession session) {

			if ((onlyHired<0) || (onlyHired>1)) {
				model.addAttribute("optMsg", "/vehOnlyHire/x, only 0 and 1 allowed for x.");
			} else {
				session.setAttribute("onlyHired", onlyHired);
			}
			return vehPaginated(0, model, session);
		}

		
		@GetMapping("/vehSort/{newSortField}")
		//change sortField, if same sortField given, change the sort direction
		public String vehSort(@PathVariable(value="newSortField") String newSortField, 
				Model model, HttpSession session) {
			
			if (!loadSessionAttributes(session)) {return "redirect:/";}

			if (newSortField.equals(sortField)) {
				// if sortDirection reversed, mirror the page number so records currently on screen continue to be visible
				currPage = (totalPages==0)?1:totalPages - currPage + 1;
				sortDirection = sortDirection.equalsIgnoreCase("ASC")?"DESC":"ASC";
			} else {  
				// if sortField is changed: go to page 1 and change sort order to  Asc
				sortField = newSortField;
				currPage = 1;
				sortDirection = "ASC";
			}
			
			session.setAttribute("vehCurrPage", currPage);
			session.setAttribute("vehSortField", sortField);
			session.setAttribute("vehSortDirection", sortDirection);
			return vehPaginated(0, model, session);
		}


		@GetMapping("/vehPageSize/{newPageSize}")
		public String vehPageSize(@PathVariable(value="newPageSize") int newPageSize,
				Model model, HttpSession session) {

			if ((newPageSize<5) || (newPageSize>20)) {
				model.addAttribute("optMsg", "Page size can be set to between 5 and 20 only.");
				return vehPaginated(0, model, session);
			}

			if (!loadSessionAttributes(session)) {return "redirect:/";}
			// when page size is changed, current page is adjusted so that most of the 
			// records currently visible continue to appear in the new page.
			currPage = (((currPage - 1) * pageSize + 1) / newPageSize) + (((((currPage - 1) * pageSize + 1) % newPageSize)==0)?0:1);
			pageSize = newPageSize; 
			session.setAttribute("vehCurrPage", currPage);
			session.setAttribute("vehPageSize", pageSize);
			return vehPaginated(0, model, session);
		}

		
		@GetMapping("/vehPin/{theVehId}")
		// pin (non-zero) a Vehicle, or un-pin (zero) the pinned Vehicle, and render the result on Vehicle.html
		public String vehPin(@PathVariable(value = "theVehId") long theVehId, 
	            Model model, HttpSession session) {

			if (theVehId < 0) {
				model.addAttribute("optMsg", "Invalid Vehicle id [" + theVehId + "] to pin.");
			} else {
				session.setAttribute("pinVehId", theVehId);
			}
			return vehPaginated(0, model, session);
		}

		
		@GetMapping("/vehPicts/{theVehId}")
		// this method is to store a vehId of nominated Vehicle, so that its pictures will be retrieved
		// to be loaded onto Vehicles.html.
		// Once on Vehicles.html, the pictures can be presented in slideshow style on a modal
		// and user can selectively replace, delete, or add more pictures.
		public String vehPicts(@PathVariable(value = "theVehId") long theVehId, 
	            Model model, HttpSession session) {

			if (theVehId<0) {
				model.addAttribute("optMsg", "Invalid Vehicle [" + theVehId + "] to show picture.");
				return vehPaginated(0, model, session);
			}
			session.setAttribute("pictsVehId", theVehId);
			return vehPaginated(0, model, session);
		}

		
		@GetMapping("/vehPinCust/{theCustId}")
		// pin (non-zero) a Vehicle, or un-pin (zero) the pinned Vehicle, and render the result on Customers.html
		public String vehPinCust(@PathVariable(value = "theCustId") long theCustId, 
	            Model model, HttpSession session) {

			if (theCustId<0) {
				model.addAttribute("optMsg", "Invalid Customer [" + theCustId + "] to pin.");
				return vehPaginated(0, model, session);
			}
			session.setAttribute("pinCustId", theCustId);
			return vehPaginated(0, model, session);
		}

		
		@ApiOperation(value="Brings high-lighted Vehicle record to editing area for edit", response=Iterable.class, tags="home")
		@GetMapping("/vehUpdaOts/{vehId}")
		public String vehUpdaOts(@PathVariable(value = "vehId") long vehId, 
				Model model, HttpSession session) {

			if ((!home.hasRole("MANAGER")) && (!home.hasRole("USER"))) {return "/403";}

			// Get vehicle from the Service
			Vehicle newVeh = new Vehicle();
			if (vehId == 0) { // this method is not expected to be invoked with vehId=0
				model.addAttribute("newVeh", newVeh);
				return vehPaginated(0, model, session);
			}

			Vehicle veh = vehicleDao.getVehicleById(vehId>0?vehId:-vehId);
			if (veh.getVehId()==0) {
				if (vehId > 0) {
					model.addAttribute("optMsg", "Vehicle [" + vehId + "] you want to edit no longer exists.");
				} else {
					model.addAttribute("optMsg", "Vehicle[" + (-vehId) + "] you want to clone from no longer exists.");
				}
				return vehPaginated(0, model, session);
			}
			
			if (vehId > 0) {  // bring details of existing Vehicle into input area for editing
				newVeh.setVehId(veh.getVehId());
				newVeh.setVehModel(veh.getVehModel());
				newVeh.setVehBrand(veh.getVehBrand());
				newVeh.setEngCap(veh.getEngCap());
				newVeh.setBhp(veh.getBhp());
				newVeh.setTopSpeed(veh.getTopSpeed());
				newVeh.setVehLicPlate(veh.getVehLicPlate());
				newVeh.setCurrHire(veh.getCurrHire());
				newVeh.setVehStatus(veh.getVehStatus());
				newVeh.setDailyRate(veh.getDailyRate());
				newVeh.setHires(veh.getHires());
				model.addAttribute("optMsg", "Modify Vehicle record and then click <Save>.");
			} else { // copy details of an existing Vehicle into input area for editing into a new Vehicle
				newVeh.setVehModel(veh.getVehModel());
				newVeh.setVehBrand(veh.getVehBrand());
				newVeh.setEngCap(veh.getEngCap());
				newVeh.setBhp(veh.getBhp());
				newVeh.setTopSpeed(veh.getTopSpeed());
				newVeh.setVehStatus(vehStatusRepo.findByName("FREE"));
				newVeh.setDailyRate(veh.getDailyRate());
				model.addAttribute("optMsg", "Enter required details and then click <Save>.");
			}
			model.addAttribute("newVeh", newVeh);
			return vehPaginated(0, model, session);
		}

		
		@PostMapping("/vehSaveOts")	
		public String vehSaveOts(@Valid @ModelAttribute("newVeh")Vehicle newVeh, BindingResult bindingResult, 
				Model model, HttpSession session) {

			if (!home.hasRole("MANAGER")) {return "/403";}
			
			if (bindingResult.hasErrors()) {
				model.addAttribute("optMsg", "Please correct the validation errors.");
				return vehPaginated(0, model, session);
			}

			Vehicle oldVeh = new Vehicle();
			if (newVeh.getVehId() > 0) {
				oldVeh = vehicleDao.getVehicleById(newVeh.getVehId());
			}
			
			if (newVeh.getVehId()==0) {
				if ((!newVeh.getVehStatus().equals(vehStatusRepo.findByName("FREE"))) && !newVeh.getVehStatus().equals(vehStatusRepo.findByName("SUSPENDED"))) {
					model.addAttribute("optMsg", "New vehicles can only be added with status FREE or SUSPENDED.");
					return vehPaginated(0, model, session);
				}
			} else {
				if (oldVeh.getVehStatus().equals(vehStatusRepo.findByName("HIRED"))) {
					if (newVeh.getVehStatus()!=oldVeh.getVehStatus()) {
						model.addAttribute("optMsg", "Status of hired Vehicle cannot be changed.");
						return vehPaginated(0, model, session);
					}
				} else {
					if (!(newVeh.getVehStatus().equals(vehStatusRepo.findByName("FREE"))) && !(newVeh.getVehStatus().equals(vehStatusRepo.findByName("SUSPENDED")))) {
						model.addAttribute("optMsg", "Vehicls not Hired cannot only toggle status between FREE and SUSPENDED.");
						return vehPaginated(0, model, session);
					}
				}
			}

			if (newVeh.getVehId()>0) {
				if ((newVeh.getBhp()==oldVeh.getBhp()) &&
				    (newVeh.getDailyRate()==oldVeh.getDailyRate()) &&
				    (newVeh.getEngCap()==oldVeh.getEngCap()) &&
				    (newVeh.getTopSpeed()==oldVeh.getTopSpeed()) &&
				    (newVeh.getVehBrand().equals(oldVeh.getVehBrand())) &&
				    (newVeh.getVehLicPlate().equals(oldVeh.getVehLicPlate())) &&
				    (newVeh.getVehModel().equals(oldVeh.getVehModel())) &&
				    (newVeh.getVehStatus().equals(oldVeh.getVehStatus()))) {
					model.addAttribute("optMsg", "You have not changed anything.");
					return vehPaginated(0, model, session);
				}
			}

				
			// ********************************************************************************
			// Validation completed successfully.  Now proceed to save the changes to database 
			if (newVeh.getVehId()>0) {
				// update existing Vehicle
				oldVeh.setBhp(newVeh.getBhp());
				oldVeh.setDailyRate(newVeh.getDailyRate());
				oldVeh.setEngCap(newVeh.getEngCap());
				oldVeh.setTopSpeed(newVeh.getTopSpeed());
				oldVeh.setVehBrand(newVeh.getVehBrand());
				oldVeh.setVehLicPlate(newVeh.getVehLicPlate());
				oldVeh.setVehModel(newVeh.getVehModel());
				oldVeh.setVehStatus(newVeh.getVehStatus());
				try {
					vehicleDao.saveVehicle (oldVeh);
				} catch(DataIntegrityViolationException e) {
					e.printStackTrace();
					model.addAttribute("optMsg", "There is another Vehicle with the same license plate, or other problems, please correct the data and retry.");
					model.addAttribute("newVeh", newVeh);
					return vehPaginated(0, model, session);
				} catch(Exception e) {
					e.printStackTrace();
					model.addAttribute("optMsg", e.getMessage());
					model.addAttribute("newVeh", newVeh);
					return vehPaginated(0, model, session);
				}
			} else {
				// saving a new Vehicle
				try {
					vehicleDao.saveVehicle (newVeh);
				} catch(DataIntegrityViolationException e) {
					e.printStackTrace();
					model.addAttribute("optMsg", "There is another Vehicle with the same license plate, or other problems, please correct the data and retry.");
					model.addAttribute("newVeh", newVeh);
					return vehPaginated(0, model, session);
				} catch(Exception e) {
					e.printStackTrace();
					model.addAttribute("optMsg", e.getMessage());
					model.addAttribute("newVeh", newVeh);
					return vehPaginated(0, model, session);
				}
			}

			newVeh = new Vehicle();
			model.addAttribute("newVeh", null);
			return vehPaginated(0, model, session); 
		}

		
		@GetMapping("/vehDeleOts/{vehId}")
		public String vehDeleOts(@PathVariable(value = "vehId") long vehId,
				Model model, HttpSession session) {
			if (!home.hasRole("MANAGER")) {return "/403";}
			if (!loadSessionAttributes(session)) {return "redirect:/";}

			Vehicle myVeh = vehicleDao.getVehicleById(vehId);
			if (myVeh==null) {
				model.addAttribute("optMsg", "Vehicle [" + vehId + "] not found, unale to delete.");
				return vehPaginated(0, model, session);
			}
			if (myVeh.getCurrHire()!=null) {
				model.addAttribute("optMsg", "Vehicle [" + vehId + "] is currently on Hire, record cannot be deleted.");
				return vehPaginated(0, model, session);
			}
			if (myVeh.getHires().size()>0) {
				model.addAttribute("optMsg", "Vehicle [" + vehId + "] has associated Hire history, they must be removed before the Vehicle can be deleted.");
				return vehPaginated(0, model, session);
			}
			if (myVeh.getPicture()!=null) {
				model.addAttribute("optMsg", "Vehicle [" + vehId + "] has associated profile Picture, it must be removed before the Vehicle can be deleted.");
				return vehPaginated(0, model, session);
			}
			if (myVeh.getPictures().size()>0) {
				model.addAttribute("optMsg", "Vehicle [" + vehId + "] has associated pictures, they must be removed before the Vehicle can be deleted.");
				return vehPaginated(0, model, session);
			}
			// ********************************************************************************
			// Validation completed successfully.  Now proceed to save the changes to database 
			model.addAttribute("optMsg", "Vehicle [" + myVeh.getVehLicPlate() + "] deleted.");
			try {
				vehicleDao.deleteVehicleById(vehId);
			} catch(DataIntegrityViolationException e) {
				e.printStackTrace();
				model.addAttribute("optMsg", "Technical problem encountered deleting Vehicle [" + vehId + "], please report to IT.");
			} catch(Exception e) {
				e.printStackTrace();
				model.addAttribute("optMsg", e.getMessage());
			}
			return vehPaginated(0, model, session);
		}


		@PostMapping("/vehAddPictJs")	
		// add a picture to set of pictures of vehicle
		public ResponseEntity<?> vehAddPictJs(@ModelAttribute UploadForm form) {

			long vehId = form.getEntityId();

			if ((!home.hasRole("MANAGER")) && (!home.hasRole("USER"))) {
				return new ResponseEntity<>("You are not authorised to upload pictures.", HttpStatus.UNAUTHORIZED);
			}

			if ((form.getFile()==null) || (form.getFile().getOriginalFilename().isEmpty())) {
			    return new ResponseEntity<>("No file selected.", HttpStatus.BAD_REQUEST);
			}

			if (form.getFile().getSize()==0) {
			    return new ResponseEntity<>("Uploaded file has no data.", HttpStatus.BAD_REQUEST);
			}

			Vehicle myVeh = vehicleDao.getVehicleById(vehId);
			if (myVeh.getVehId()==0) {
			    return new ResponseEntity<>("Vehicle [" + vehId + "] does not exist.", HttpStatus.BAD_REQUEST);
			}

			Picture newPict = new Picture();
			// ********************************************************************************
			// Validation completed successfully.  Now proceed to save the changes to database 
			try {
				newPict = storageService.store(form.getFile(),0,false);
		    } catch (Exception e) {
				e.printStackTrace();
			    return new ResponseEntity<>("Could not upload the file [" + form.getFile().getOriginalFilename() + "]!", HttpStatus.BAD_REQUEST);
		    }

			myVeh.getPictures().add(newPict);

			// if Vehicle has no profile picture, make this new picture the profile picture
			if (myVeh.getPicture()==null) {
				myVeh.setPicture(newPict);
			}
			vehicleDao.saveVehicle (myVeh);

			return new ResponseEntity<String>("" + newPict.getPictId(), HttpStatus.OK);

		}
		


		@PostMapping("/vehReplPictJs")	
		// Replace an uploaded picture into existing album of the Vehicle
		public ResponseEntity<?> vehReplPictJs(@ModelAttribute UploadForm form) {
			
			if ((!home.hasRole("MANAGER")) && (!home.hasRole("USER"))) {
				return new ResponseEntity<>("You are not authorised to upload pictures.", HttpStatus.UNAUTHORIZED);
			}

			long pictId = form.getId();
			long vehId = form.getEntityId();

			if ((form.getFile()==null) || (form.getFile().getOriginalFilename()==null) || (form.getFile().getOriginalFilename().isEmpty())) {
			    return new ResponseEntity<>("No file selected.", HttpStatus.BAD_REQUEST);
			}

			if (form.getFile().getSize()==0) {
			    return new ResponseEntity<>("Uploaded file has no data.", HttpStatus.BAD_REQUEST);
			}

			Vehicle myVeh = vehicleDao.getVehicleById(vehId);
			if (myVeh==null) {
			    return new ResponseEntity<>("Vehicle [" + vehId + "] does not exist.", HttpStatus.BAD_REQUEST);
			}

			Picture newPict = storageService.getPicture(pictId);
			if (newPict.getPictId()==0) {
			    return new ResponseEntity<>("Picture [" + pictId + "] does not exist.", HttpStatus.BAD_REQUEST);
			}

			Boolean pictFound = false;
			Set<Picture> myPictures = myVeh.getPictures();
			for (Iterator<Picture> iterator = myPictures.iterator(); iterator.hasNext();) {
			    Picture onePict =  iterator.next();
			    if (onePict.getPictId() == pictId) {
					pictFound = true;
			    }
			}
			if (!pictFound) {
			    return new ResponseEntity<>("Vehicle [" + vehId + "] does not have Picture [" + pictId + "] in its album.", HttpStatus.BAD_REQUEST);
			}
			
			// ********************************************************************************
			// Validation completed successfully.  Now proceed to save the changes to database 
			try {
				newPict = storageService.store(form.getFile(),pictId,false);
		    } catch (Exception e) {
				e.printStackTrace();
			    return new ResponseEntity<>("Could not upload the file[" + form.getFile().getOriginalFilename() + "]!", HttpStatus.BAD_REQUEST);
		    }

			return new ResponseEntity<String>("Picture [" + newPict.getPictId() + "] replaced.", HttpStatus.OK);

		}

		

		@GetMapping("/vehProfPictJs/{vehId}/{pictId}")	
		// add a picture to set of pictures of vehicle
		public ResponseEntity<?> vehProfPict(@PathVariable(value="vehId") long vehId, @PathVariable(value="pictId") long pictId) {
			
			if ((!home.hasRole("MANAGER")) && (!home.hasRole("USER"))) {
				return new ResponseEntity<>("You are not authorised to change profile pictures.", HttpStatus.UNAUTHORIZED);
			}

			Vehicle myVeh = vehicleDao.getVehicleById(vehId);
			if (myVeh.getVehId()==0) {
			    return new ResponseEntity<>("Vehicle [" + vehId + "] does not exist.", HttpStatus.BAD_REQUEST);
			}

			Picture newPict = storageService.getPicture(pictId);
			if (newPict.getPictId()==0) {
			    return new ResponseEntity<>("Picture [" + pictId + "] does not exist.", HttpStatus.BAD_REQUEST);
			}

			long oldPictId = 0;
			if (myVeh.getPicture()!=null) {
				oldPictId = myVeh.getPicture().getPictId();
				if (oldPictId==pictId) {
				    return new ResponseEntity<>("Vehicle [" + vehId + "] already has Picture [" + pictId + "] as profile picture.", HttpStatus.BAD_REQUEST);
				}
			}

			Boolean pictFound = false;
			Set<Picture> myPictures = myVeh.getPictures();
			for (Iterator<Picture> iterator = myPictures.iterator(); iterator.hasNext();) {
			    Picture onePict =  iterator.next();
			    if (onePict.getPictId() == pictId) {
					pictFound = true;
			    }
			}
			if (!pictFound) {
			    return new ResponseEntity<>("Vehicle [" + vehId + "] does not have Picture [" + pictId + "] in its album.", HttpStatus.BAD_REQUEST);
			}
			
			
			// ********************************************************************************
			// Validation completed successfully.  Now proceed to save the changes to database 
			myVeh.setPicture(newPict);
			
			try {
				vehicleDao.saveVehicle (myVeh);
			} catch(Exception e) {
				e.printStackTrace();
			    return new ResponseEntity<>("Unable to tag Picture["+newPict.getPictId()+"] as profile picture of Vehicle["+myVeh.getVehId()+"]!", HttpStatus.BAD_REQUEST);
			}

		    return new ResponseEntity<>("" + oldPictId, HttpStatus.OK);

		}

		
		@GetMapping("/vehRmvPictJs/{vehId}/{pictId}")
		public ResponseEntity<?> vehRmvPictJs(@PathVariable long vehId, @PathVariable long pictId) {
			Boolean vehChanged = false;
			if ((!home.hasRole("MANAGER")) && (!home.hasRole("USER"))) {
				return new ResponseEntity<>("You are not authorised to delete pictures.", HttpStatus.UNAUTHORIZED);
			}

			Vehicle myVeh = vehicleDao.getVehicleById(vehId);
			if (myVeh.getVehId()==0) {
			    return new ResponseEntity<>("Vehicle [" + vehId + "] does not exist.", HttpStatus.BAD_REQUEST);
			}

			Picture myPict = storageService.getPicture(pictId);
			if (myPict.getPictId()==0) {
			    return new ResponseEntity<>("Picture [" + pictId + "] does not exist.", HttpStatus.BAD_REQUEST);
			}
			
			// ********************************************************************************
			// Validation completed successfully.  Now proceed to save the changes to database 
			Set<Picture> myPictures = myVeh.getPictures();
			for (Iterator<Picture> iterator = myPictures.iterator(); iterator.hasNext();) {
			    Picture onePict =  iterator.next();
			    if (onePict.getPictId() == pictId) {
			        iterator.remove();
					vehChanged = true;
			    }
			}
			if (vehChanged) {
				myVeh.setPictures(myPictures);
			}

			if (myVeh.getPicture()!=null && myVeh.getPicture().getPictId()==pictId) {
				myVeh.setPicture(null);
				vehChanged = true;
			}

			if (vehChanged) {
				vehicleDao.saveVehicle(myVeh);
				storageService.delPicture(pictId);
			}
			
		    return new ResponseEntity<>("Vehicle " + pictsVehId + " has picture " + pictId + " deleted.", HttpStatus.OK);
		}

	
}
