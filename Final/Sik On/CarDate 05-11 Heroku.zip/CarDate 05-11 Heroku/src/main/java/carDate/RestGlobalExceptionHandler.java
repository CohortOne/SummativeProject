package carDate;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartException;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;
//import org.hibernate.exception.ConstraintViolationException;
 
import javax.servlet.http.HttpServletRequest;

@ControllerAdvice
public class RestGlobalExceptionHandler extends ResponseEntityExceptionHandler {

    // Catch max file size Exception.
    @ExceptionHandler(MultipartException.class)
    @ResponseBody
    public ResponseEntity<?> handleControllerException(HttpServletRequest request, Throwable ex) {
 
        HttpStatus status = this.getStatus(request);
        if (ex.getMessage().startsWith("Maximum upload size exceeded")) {
            return new ResponseEntity<String>("Picture file size exceeded the maximum, please pick a picture of smaller file size.", status);
        }
        return new ResponseEntity<String>("(Message in RestGlobalExceptionHandler *): " + ex.getMessage(), status);
    }

//    @ExceptionHandler(ConstraintViolationException.class)
//    @ResponseBody
//    public ResponseEntity<?> handleConstraintViolationException(HttpServletRequest request, Throwable ex) {
// 
//        HttpStatus status = this.getStatus(request);
//        return new ResponseEntity<String>("Encountered DB referential integrity problem, please report to IT Support.", status);
//    }
    
    // Catch Other Exceptions
    @ExceptionHandler(Exception.class)
    @ResponseBody
    public ResponseEntity<?> handleControllerRootException(HttpServletRequest request, Throwable ex) {

        HttpStatus status = this.getStatus(request);
        return new ResponseEntity<String>("(Message in RestGlobalExceptionHandler **): " + ex.getMessage(), status);
    }
//  public String handleControllerRootException(HttpServletRequest request, Throwable ex, Model model) {
//
//      HttpStatus status = this.getStatus(request);
//      model.addAttribute("optMsg1", status.toString());
//      model.addAttribute("optMsg2", ex.getMessage());
//      return "error";
//  }
 
    private HttpStatus getStatus(HttpServletRequest request) {
        Integer statusCode = (Integer) request.getAttribute("javax.servlet.error.status_code");
        if (statusCode == null) {
            return HttpStatus.INTERNAL_SERVER_ERROR;
        }
        return HttpStatus.valueOf(statusCode);
    }
}
