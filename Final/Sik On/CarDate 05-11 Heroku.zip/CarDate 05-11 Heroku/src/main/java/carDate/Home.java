package carDate;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import carDate.cfg.BusinessConfig;
import carDate.cfg.BusinessConfigDao;
import carDate.emp.Employee;
import carDate.emp.EmployeeDao;
import io.swagger.annotations.Api;

	@Api(value = "Home", description = "Application home page")
	@Controller
	public class Home {

		@Autowired
		private EmployeeDao employeeDao;

		@Autowired
		private BusinessConfigDao businessConfigDao;

		private Object principal;
		private String empName;


		String currFunc;
		int currPage;
		int totalPages;
		int pageSize;
		int nextPageSize;
		String sortField;
		String sortDirection;
		long pinCustId;
		long pinVehId;
		
		
		public boolean hasRole(String role) {

			System.out.println("\n\t home Explicit authentication begins...");
			principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
			empName = "";
			
			if (principal instanceof UserDetails) {
				empName = ((UserDetails) principal).getUsername();
				System.out.println("\t Authenticating User=" + empName + "  for Role=" + role + "...");
				System.out.println("\t authenticaed user has these roles=" + ((UserDetails) principal).getAuthorities());
				if (SecurityContextHolder.getContext().getAuthentication().getAuthorities().stream()
		          .anyMatch(r -> r.getAuthority().equals("ROLE_".concat(role)))) {
					System.out.println("\t Explicit authentication ends with true.");
					return true;
				}
				System.out.println("\t Explicit authentication ends with false due to missing required Role " + role + ".");
				return false;
			} else {
				System.out.println("\t Explicit authentication ends with false due to missing UserDetails.");
				return false;
			}
		}

		@RequestMapping("/homePage")
		public String HomePage(Model model, HttpSession session) { 
			principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
			empName = ((UserDetails) principal).getUsername();
			Employee meEmp = employeeDao.getEmployeeByEmpName(empName);
			model.addAttribute("meEmp", meEmp);
			return "Home"; // present home.html
		}

		@PostMapping("/homeSave")
		public String homeSave(@RequestParam Map<String,String> reqPar, Model model, HttpSession session) {
			String oldPswd = reqPar.get("oldPswd"); 
			String newPswd1 = reqPar.get("newPswd1"); 
			String newPswd2 = reqPar.get("newPswd2"); 
			String newMenu = reqPar.get("newMenu"); 
			BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
			principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
			empName = ((UserDetails) principal).getUsername();
			Employee meEmp = employeeDao.getEmployeeByEmpName(empName);
			model.addAttribute("meEmp", meEmp);
			if (!(oldPswd.isEmpty() && newPswd1.isEmpty() && newPswd2.isEmpty())) {
				if (!oldPswd.equals(oldPswd.trim()) || !newPswd1.equals(newPswd1.trim()) || !newPswd2.equals(newPswd2.trim())) {
					model.addAttribute("optMsg", "Leading and trailing blanks are not allowed in passwords, plesae try again.");
					return "Home";
				}
				if (oldPswd.isEmpty() || newPswd1.isEmpty() || newPswd2.isEmpty()) {
					model.addAttribute("optMsg", "To change password, you must enter the old password, and new password twice, plesae try again.");
					return "Home";
				}

				if (!newPswd1.equals(newPswd2)) {
					model.addAttribute("optMsg", "New passwords do not match, plesae try again.");
					return "Home";
				}

				if (oldPswd.equals(newPswd1)) {
					model.addAttribute("optMsg", "New password is the same as old password, plesae try again.");
					return "Home";
				}
				
				if (!encoder.matches(oldPswd, meEmp.getPassword())) {
					model.addAttribute("optMsg", "Old password do not match record, plesae try again.");
					return "Home";
				}
				
				meEmp.setPassword(encoder.encode(newPswd1));
				meEmp.setPswdExpiry(homeClock().plusDays(60).toLocalDate());
				model.addAttribute("optMsg", "Password changed successfully.");
			}
			if (!meEmp.getInitMenu().equals(newMenu) ) {
				meEmp.setInitMenu(newMenu);
			}
			model.addAttribute("meEmp", meEmp);
			return "Home";
		}

		@RequestMapping("/")
		public String Welcome(Model model, HttpSession session) { 
			System.out.println("\n\t Access to home page detected...");
			principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
			empName = "";
			
			if (principal instanceof UserDetails) {
				empName = ((UserDetails) principal).getUsername();
				System.out.println("\t User=" + empName + " has been authenticated.");
				session.setAttribute("empName", empName);
				Employee meEmp = employeeDao.getEmployeeByEmpName(empName);
				model.addAttribute("meEmp", meEmp);
				switch (meEmp.getInitMenu()) {
					case "Customers":
						if (hasRole("MANAGER") || hasRole("USER")) {
							return "redirect:/custPage/0";
						} else {
							return "redirect:/homePage";
						}
					case "Vehicles":
						if (hasRole("MANAGER") || hasRole("USER")) {
							return "redirect:/vehPage/0";
						} else {
							return "redirect:/homePage";
						}
					case "Hires":
						if (hasRole("MANAGER") || hasRole("USER")) {
							return "redirect:/hirePage/0";
						} else {
							return "redirect:/homePage";
						}
					case "Employees":
						if (hasRole("ADMIN")) {
							return "redirect:/empPage/0";
						} else {
							return "redirect:/homePage";
						}
					case "Configurations":
						if (hasRole("MANAGER") || hasRole("ADMIN")) {
							return "redirect:/cfgPage";
						} else {
							return "redirect:/homePage";
						}
					default:
						return "redirect:/homePage";
				}
			} else {
				model.addAttribute("optMsg", "Authentication failed.");
			}

			return "redirect:/login";
		}
		
		@RequestMapping("/login")
		public String login(Model model) {
			model.addAttribute("optMsg", "Please log in with your user name and password.");
			System.out.println("\tlogin detected...");
				return "login";
		}
		
		@RequestMapping("/bye")
		public String bye(Model model, HttpSession session) {
			empName = null;
			session.setAttribute("empName", empName);
			model.addAttribute("optMsg", "You are logged out.");
			return "login";
		}


		public String getEmpName() {
			return empName;
		}


		public BusinessConfig homeConfig() {
        // this method helps to pick the correct BusinessConfig as the master config, base on effective date
			BusinessConfig mstrCfg = businessConfigDao.getBusinessConfigById(1);
			mstrCfg = businessConfigDao.getBusinessConfigById(mstrCfg.getPrevId());
			if (mstrCfg.getNextId() > 0) {  // there is a pending new config that may have become applicable
				BusinessConfig nextCfg = businessConfigDao.getBusinessConfigById(mstrCfg.getNextId());
				LocalDateTime dtsNow = java.time.LocalDateTime.now();
				dtsNow = dtsNow.plusDays(mstrCfg.getOffsetDays());
				dtsNow = dtsNow.plusHours(mstrCfg.getOffsetHours());
				if (!nextCfg.getEffDate().isAfter(dtsNow.toLocalDate())) { // application clock has reached/passed effective date of nextCfg
					// apply nextCfg
					mstrCfg = businessConfigDao.getBusinessConfigById(mstrCfg.getNextId());
				}
			}
			return mstrCfg;
		
		}	

		

		public LocalDateTime homeClock() {
			
			BusinessConfig mstrCfg = homeConfig();
			
			LocalDateTime dtsNow = java.time.LocalDateTime.now();
			dtsNow = dtsNow.plusDays(mstrCfg.getOffsetDays());
			dtsNow = dtsNow.plusHours(mstrCfg.getOffsetHours());
			
			return dtsNow;
			
		}
		
		@GetMapping("/homeClock")
		public ResponseEntity<?> homeClockJs() {

			LocalDateTime dtsNow = homeClock();
			DateTimeFormatter dtsFormat = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

		    return new ResponseEntity<String>(dtsFormat.format(dtsNow), HttpStatus.OK);
			
		}

		
}
