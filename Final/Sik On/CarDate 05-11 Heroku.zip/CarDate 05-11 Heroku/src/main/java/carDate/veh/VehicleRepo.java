package carDate.veh;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface VehicleRepo extends JpaRepository<Vehicle, Long> {

	// note that the table and column names used below should follow pojo, not database.
    @Query("SELECT v FROM Vehicle v WHERE CONCAT(v.vehBrand, ' ', v.vehModel, ' ', v.vehLicPlate) LIKE %?1% AND ((currHire <> NULL) OR ?2 = 0)")
	public Page<Vehicle> search(String keyword, int onlyHired, Pageable pageable);
	
    @Query("SELECT v FROM Vehicle v WHERE NOT (currHire = NULL)")
	public Page<Vehicle> findHired(Pageable pageable);
}
