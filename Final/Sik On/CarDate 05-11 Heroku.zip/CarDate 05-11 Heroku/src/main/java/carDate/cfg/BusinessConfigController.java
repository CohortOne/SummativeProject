package carDate.cfg;

import java.time.LocalDateTime;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import carDate.Home;

@Controller
@ControllerAdvice

public class BusinessConfigController {

	@Autowired
	private Home home;

	@Autowired
	private BusinessConfigDao businessConfigDao;

	String currFunc;
	String keyword;

	@GetMapping("/cfgPage")
	public String cfgPage(Model model, HttpSession session) {
		if ((!home.hasRole("MANAGER")) && (!home.hasRole("ADMIN"))) {return "/403";}
//		if (!loadSessionAttributes(session)) {return "redirect:/";}

		BusinessConfig rootCfg = businessConfigDao.getBusinessConfigById(1);
		BusinessConfig mstrCfg;
		BusinessConfig nextCfg;
		if (rootCfg.getNextId() > 0) {  // there is a pending new config that may need to be applied
			nextCfg = businessConfigDao.getBusinessConfigById(rootCfg.getNextId());
			LocalDateTime dtsNow = java.time.LocalDateTime.now();
			dtsNow = dtsNow.plusDays(rootCfg.getOffsetDays());
			dtsNow = dtsNow.plusHours(rootCfg.getOffsetHours());
			if (!nextCfg.getEffDate().isAfter(dtsNow.toLocalDate())) { // application clock has reached/passed effective date of nextCfg
				// apply nextCfg
				rootCfg.setCloseTime(nextCfg.getCloseTime());
				rootCfg.setEffDate(nextCfg.getEffDate());
				rootCfg.setExtraTimeFactor(nextCfg.getExtraTimeFactor());
				rootCfg.setGracePeriod(nextCfg.getGracePeriod());
				rootCfg.setHireTime(nextCfg.getHireTime());
				rootCfg.setHourlyFactor(nextCfg.getHourlyFactor());
				rootCfg.setNextId(nextCfg.getNextId());
				rootCfg.setOffsetDays(nextCfg.getOffsetDays());
				rootCfg.setOffsetHours(nextCfg.getOffsetHours());
				rootCfg.setOpenTime(nextCfg.getOpenTime());
				rootCfg.setPrevId(nextCfg.getConfigId());
				businessConfigDao.saveBusinessConfig(rootCfg);
				model.addAttribute("nextCfg",null);
			}
		}

		mstrCfg = businessConfigDao.getBusinessConfigById(rootCfg.getPrevId());
		model.addAttribute("mstrCfg", mstrCfg);
		
		nextCfg = (BusinessConfig)model.getAttribute("nextCfg");
		if (nextCfg==null) {
			nextCfg = new BusinessConfig();
			if (mstrCfg.getNextId() > 0) {
				nextCfg = businessConfigDao.getBusinessConfigById(mstrCfg.getNextId());
			} else {
				nextCfg.setConfigId(0);
				nextCfg.setPrevId(mstrCfg.getConfigId());
				nextCfg.setCompanyName(mstrCfg.getCompanyName());
				nextCfg.setAddr1(mstrCfg.getAddr1());
				nextCfg.setAddr2(mstrCfg.getAddr2());
				nextCfg.setCloseTime(mstrCfg.getCloseTime());
				nextCfg.setEffDate(mstrCfg.getEffDate());
				if (nextCfg.getEffDate().isBefore(home.homeClock().toLocalDate())) {
					nextCfg.setEffDate(home.homeClock().toLocalDate());
				}
				nextCfg.setExtraTimeFactor(mstrCfg.getExtraTimeFactor());
				nextCfg.setGracePeriod(mstrCfg.getGracePeriod());
				nextCfg.setHireTime(mstrCfg.getHireTime());
				nextCfg.setHourlyFactor(mstrCfg.getHourlyFactor());
				nextCfg.setOffsetDays(mstrCfg.getOffsetDays());
				nextCfg.setOffsetHours(mstrCfg.getOffsetHours());
				nextCfg.setOpenTime(mstrCfg.getOpenTime());
				nextCfg.setReturnTime(mstrCfg.getReturnTime());
				nextCfg.setWeekendFactor(mstrCfg.getWeekendFactor());
			}
		}
		model.addAttribute("nextCfg", nextCfg);
		
		return "BusinessConfigs";
	}
	
	@PostMapping("/cfgSave")	
	public String cfgSave(@Valid @ModelAttribute("nextCfg")BusinessConfig nextCfg, BindingResult bindingResult, 
			Model model, 
			HttpSession session) {

		if ((!home.hasRole("MANAGER")) && (!home.hasRole("ADMIN"))) {return "/403";}
//		if (!loadSessionAttributes(session)) {return "redirect:/";}
		
		if (bindingResult.hasErrors()) {
			model.addAttribute("optMsg", "Please correct the validation errors.");
			return cfgPage(model, session);
		}

		BusinessConfig rootCfg = businessConfigDao.getBusinessConfigById(1);
		BusinessConfig mstrCfg = businessConfigDao.getBusinessConfigById(rootCfg.getPrevId());

		if (nextCfg.getEffDate().isBefore(home.homeClock().toLocalDate())) {
			model.addAttribute("optMsg", "Effective date must not be in the past.");
			return cfgPage(model, session);
		}

		if ((nextCfg.getGracePeriod()==0) && (mstrCfg.getGracePeriod()!=0)) {
			// Grace Period is to ensure that Hire start/end date/time is not too far off the derived server clock,
			// by enforcing that the input date/time is not more than that number of minutes from actual date/time. 
			// This is a mechanism to improve the accuracy of data input, as well as to prevent fraud in production.
			// If Grace Period is set to 0, the checking is disabled, so users are free to input any date/time.
			// Disabling this checking is useful in test environment.  However, we only allow the value to be set to 0
			// via database patch, but not from the maintenance screen.
			model.addAttribute("optMsg", "Grace Period cannot be changed from non-zero to zero.");
			return cfgPage(model, session);
		}

		if (!nextCfg.getCloseTime().isAfter(nextCfg.getOpenTime())) {
			model.addAttribute("optMsg", "Closing time must be after opening time.");
			return cfgPage(model, session);
		}
		if (nextCfg.getHireTime().isBefore(nextCfg.getReturnTime())) {
			model.addAttribute("optMsg", "Collection time cannot be before Return time.");
			return cfgPage(model, session);
		}
		if (nextCfg.getReturnTime().isBefore(nextCfg.getOpenTime())) {
			model.addAttribute("optMsg", "Return time cannot be before Open time.");
			return cfgPage(model, session);
		}
		if (nextCfg.getHireTime().isBefore(nextCfg.getReturnTime())) {
			model.addAttribute("optMsg", "Collection time cannot be before Return time.");
			return cfgPage(model, session);
		}
		if (nextCfg.getHireTime().isAfter(nextCfg.getCloseTime())) {
			model.addAttribute("optMsg", "Collection time must not be after Closing time.");
			return cfgPage(model, session);
		}
		
		if (nextCfg.getOffsetDays() < mstrCfg.getOffsetDays()) {
			model.addAttribute("optMsg", "Days offset cannot be decremented.");
			return cfgPage(model, session);
		}
		if (nextCfg.getOffsetDays() == mstrCfg.getOffsetDays()) {
			if (nextCfg.getOffsetHours() < mstrCfg.getOffsetHours()) {
				model.addAttribute("optMsg", "Hours offset cannot be decremented.");
				return cfgPage(model, session);
			}
		}
		
		if ((mstrCfg.getOffsetDays()==0) && (mstrCfg.getOffsetHours()==0)) {
			if ((nextCfg.getOffsetDays()!=0) || (nextCfg.getOffsetHours()!=0)) {
				model.addAttribute("optMsg", "When Days and Hours offsets are both 0, they can not be changed.");
				return cfgPage(model, session);
			}
		}

		// ************************************************
		// Validation completed, proceed to update database
		if ((nextCfg.getCloseTime().equals(mstrCfg.getCloseTime())) &&
			(nextCfg.getExtraTimeFactor() == mstrCfg.getExtraTimeFactor())  &&
			(nextCfg.getGracePeriod() == mstrCfg.getGracePeriod())  &&
			(nextCfg.getHireTime().equals(mstrCfg.getHireTime()))  &&
			(nextCfg.getHourlyFactor() == mstrCfg.getHourlyFactor())  &&
			(nextCfg.getOffsetDays() == mstrCfg.getOffsetDays())  &&
			(nextCfg.getOffsetHours() == mstrCfg.getOffsetHours())  &&
			(nextCfg.getOpenTime().equals(mstrCfg.getOpenTime()))  &&
			(nextCfg.getReturnTime().equals(mstrCfg.getReturnTime())) &&
			(nextCfg.getWeekendFactor() == mstrCfg.getWeekendFactor()) ) { //no change to config
			nextCfg = null;
			model.addAttribute("nextCfg", nextCfg);
			model.addAttribute("optMsg", "Nothing has changed.");
			if (mstrCfg.getNextId() > 0) { // delete nextCfg record if any
				businessConfigDao.deleteBusinessConfigById(mstrCfg.getNextId());
				mstrCfg.setNextId(0);
				rootCfg.setNextId(0);
				businessConfigDao.saveBusinessConfig(mstrCfg);
				businessConfigDao.saveBusinessConfig(rootCfg);
				model.addAttribute("optMsg", "Next config has same setting as current, next config record deleted.");
			}
			return cfgPage(model, session);
		}

		
		businessConfigDao.saveBusinessConfig(nextCfg);

		if (mstrCfg.getNextId()!=nextCfg.getConfigId()) {
			mstrCfg.setNextId(nextCfg.getConfigId());
			rootCfg.setNextId(nextCfg.getConfigId());
			businessConfigDao.saveBusinessConfig(mstrCfg);
			businessConfigDao.saveBusinessConfig(rootCfg);
		}

		nextCfg = null;
		model.addAttribute("nextCfg", nextCfg);
		return cfgPage(model, session);
	}

	@GetMapping("/cfgDele")	
	public String cfgDele(Model model, HttpSession session) {

		if ((!home.hasRole("MANAGER")) && (!home.hasRole("ADMIN"))) {return "/403";}
//		if (!loadSessionAttributes(session)) {return "redirect:/";}

		BusinessConfig rootCfg = businessConfigDao.getBusinessConfigById(1);

		if (rootCfg.getNextId()==0) {
			model.addAttribute("optMsg", "There is nothing to delete.");
			return cfgPage(model, session);
		}

		// ************************************************
		// Validation completed, proceed to update database
		rootCfg.setNextId(0);
		BusinessConfig mstrCfg = businessConfigDao.getBusinessConfigById(rootCfg.getPrevId());
		long nextConfigId = mstrCfg.getNextId();
		mstrCfg.setNextId(0);
		businessConfigDao.deleteBusinessConfigById(nextConfigId);
		
		BusinessConfig nextCfg = null;
		model.addAttribute("nextCfg", nextCfg);
		
		if (nextConfigId==0) {
			model.addAttribute("optMsg", "Next config refreshed from current record.");
		} else {
			model.addAttribute("optMsg", "Next config deleted.");
		}

		return cfgPage(model, session);
	}

	
}
