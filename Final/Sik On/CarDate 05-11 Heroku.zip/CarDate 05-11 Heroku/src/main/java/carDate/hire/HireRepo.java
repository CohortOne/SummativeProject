package carDate.hire;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface HireRepo extends JpaRepository<Hire, Long> {

	// note that the table and column names used below should follow pojo, not database.
//    @Query("SELECT h FROM Hire h WHERE h.custId = %?1% AND (h.dtsEndActual = NULL OR %?2% = FALSE)")
    @Query("SELECT h FROM Hire h WHERE h.customer.custId = ?1 AND (h.dtsEndActual = NULL OR ?2=0)")
	public Page<Hire> search4Cust(long hireCustId, int hireActive, Pageable pageable);

//  @Query("SELECT h FROM Hire h WHERE h.vehId = %?1% AND (h.dtsEndActual = NULL OR %?2% = FALSE)")
    @Query("SELECT h FROM Hire h WHERE h.vehicle.vehId = ?1 AND (h.dtsEndActual = NULL OR ?2=0)")
	public Page<Hire> search4Veh(long hireVehId, int hireActive, Pageable pageable);

//  @Query("SELECT h FROM Hire h WHERE h.vehId = %?1% AND (h.dtsEndActual = NULL OR %?2% = FALSE)")
    @Query("SELECT h FROM Hire h WHERE ((h.empFulfill.empId = ?1) OR (h.empReturn.empId = ?1)) AND (h.dtsEndActual = NULL OR ?2=0)")
//    @Query("SELECT h FROM Hire h WHERE (h.empFulfill.empId = ?1) AND (h.dtsEndActual = NULL OR ?2=0)")
	public Page<Hire> search4Emp(long hireEmpId, int hireActive, Pageable pageable);

    @Query("SELECT h FROM Hire h WHERE h.dtsEndActual = NULL")
	public Page<Hire> search4Active(Pageable pageable);
    
	
}
