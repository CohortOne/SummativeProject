$(document).ready(function(){
    $('.payWhere').click(function() {
        $('.payWhere').not(this).prop('checked', false);
    });
});