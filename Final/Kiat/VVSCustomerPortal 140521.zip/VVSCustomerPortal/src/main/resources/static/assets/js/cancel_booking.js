$(document).ready(function () {
	$(".cancel").on('click',function(event) {
		event.preventDefault();
        var href = $(this).attr("href");
        $("#cancelConfirm").modal("show");
			

var bookingId = href.slice(href.lastIndexOf('=') + 1);


						
			var entry = document.getElementById("entry");
			entry.innerHTML ="Are you sure you want to cancel booking [Booking ID: " + bookingId + "]?";


		$("#cancelRef").attr("href",href);
		$("#cancelConfirm").modal();
		
		
	});
	
	});