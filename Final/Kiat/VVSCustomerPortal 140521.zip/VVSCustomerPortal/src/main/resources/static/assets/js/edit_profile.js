$(document).ready(function(){

   $('#edit').click(function(){

     var rBtnVal = $(this).val();

     if(rBtnVal == "yes"){
         $(".editable").attr("readonly", false);
         $("#updateProfile").removeClass('d-none');
		 $("#edit").addClass('d-none');		
     }
     else{ 
         $(".editable").attr("readonly", true);          
     }
   });
});