$(document).ready(function(){

	 $("#brand").change(function() {
      		var brand = $(this).find(":selected").val();
			console.log("clicked element");
    					
			  			
			var json = {
      			 "brand" : brand
    		};
			console.log(brand);
		    $.ajax({
                type: "POST",
                contentType: "application/json",
                url: "/loadModelsByBrand",
                data: JSON.stringify(json),
                dataType: 'json',
                cache: false,
                timeout: 600000,
                success: function(data) {
                    var html = '<option value="0">Select</option><option value="All">All</option>';					
                    var len = data.length;
					console.log(len);                    
                    for (var i = 0; i < len; i++) {
                        html += '<option value="' 
							+ data[i].model + '">'
							+ data[i].model  
							+'</option>';						
                    }               
										                    
										
					console.log(html);					
        			$('#modelOfCar').html(html);
						

                },
                error: function(e) {
                    alert("this is an error. "+ e);
                }
            });



});
});
