$(document).ready(function(){

	$(".carpics").click(function(){
    $("#carpicsModal").modal("show");
	});
	
	var ancestor = document.getElementById("vehicleList"),
    descendents = ancestor.getElementsByTagName('img');
	console.log(descendents.id);
	var i;
	for (i = 0; i < descendents.length; i++){
			descendents[i].onclick = function(){
				console.log("clicked element");
    		console.log(this);
	
			var vehicleId = this.id;
			  			
			var json = {
      			 "vehicleId" : vehicleId
    		};
			console.log(vehicleId);
		    $.ajax({
                type: "POST",
                contentType: "application/json",
                url: "/loadVehicleImages",
                data: JSON.stringify(json),
                dataType: 'json',
                cache: false,
                timeout: 600000,
                success: function(data) {
                    var html = '<div class="carousel-item active">';
					var indicators = '<li class="active" data-target="#carousel-1" data-slide-to="'
                    var len = data.length;                    
                    for (var i = 0; i < len; i++) {
                        html += '<img class="w-100 d-block" src="' 
							+ data[i].hrefLink  
							+'"/></div><div class="carousel-item">';
						indicators += i + '"></li><li data-target="#carousel-1" data-slide-to="';
                    }                  
					html = html.slice(0, html.lastIndexOf('/'));					                    
					html +='div>';
					indicators = indicators.slice(0, indicators.lastIndexOf('/'));
					indicators += '"li>"'
					console.log(html);
					console.log(indicators);
        			$('#vehicleImages').html(html);
					$('#sliderNo').html(indicators);	

                },
                error: function(e) {
                    alert("this is an error. "+ e.error);
                }
            });

};
}
});

