package com.vroomvrooms.model;

public class VehicleIdForImages {

	private Long vehicleId;

	public Long getVehicleId() {
		return vehicleId;
	}

	public void setVehicleId(Long vehicleId) {
		this.vehicleId = vehicleId;
	}
	
	
}
