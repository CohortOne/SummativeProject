package com.vroomvrooms.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.vroomvrooms.model.Invoices;

public interface InvoiceRepo extends JpaRepository<Invoices, Long> {
	
	@Query(value="select COALESCE(SUM(total_Amount),0) from invoices where status='Paid' AND EXTRACT(month FROM CURRENT_DATE)=EXTRACT(month FROM ISSUE_DATE)", nativeQuery = true)
	public double currentMonthlyAmount();

	@Query(value="select SUM(total_Amount) from invoices where status='Paid' AND EXTRACT(year FROM CURRENT_DATE)=EXTRACT(year FROM ISSUE_DATE)", nativeQuery = true)
	public double totalAnnualAmount();
	
	@Query(value="select SUM(total_Amount) from invoices where status='Paid' group by EXTRACT(month FROM ISSUE_DATE) order by EXTRACT(month FROM ISSUE_DATE) ASC", nativeQuery = true)
	public List<Integer> monthlyTotal();
	
	@Query(value="select extract(month from issue_date) from invoices where status='Paid' group by EXTRACT(month FROM ISSUE_DATE) order by EXTRACT(month FROM ISSUE_DATE) ASC", nativeQuery = true)
	public List<String> monthName();

	@Query("SELECT i FROM Invoices i inner join i.hireDetails h inner join i.customer c WHERE c.id= :custId AND CONCAT(h.id, ' ', h.vehicle.brand, ' ', h.vehicle.model) LIKE %:keyword%")
	public Page<Invoices> search(@Param("custId")long custId, @Param("keyword")String keyword, Pageable pageable);

	@Query("SELECT i FROM Invoices i WHERE i.status= :status")
	public Page<Invoices> displayWithStatus(@Param("status")String status, Pageable pageable);

	@Query("SELECT i FROM Invoices i inner join i.hireDetails h WHERE i.status= :status AND CONCAT(i.id, ' ', i.totalAmount, ' ', i.issueDate, ' ', h.id) LIKE %:keyword%")
	public Page<Invoices> searchWithStatus(@Param("status")String status, @Param("keyword")String keyword, Pageable pageable);

	@Query("SELECT i FROM Invoices i inner join i.hireDetails h inner join i.customer c WHERE c.id= :custId and h.endDateTime is not null")
	public Page<Invoices> findPastBookings(long custId, Pageable pageable);
}
