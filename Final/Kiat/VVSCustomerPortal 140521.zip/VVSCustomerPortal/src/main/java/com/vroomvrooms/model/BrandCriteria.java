package com.vroomvrooms.model;

public class BrandCriteria {
	
	private Brand brand;

	public Brand getBrand() {
		return brand;
	}

	public void setBrand(Brand brand) {
		this.brand = brand;
	}

}
