package com.vroomvrooms.model;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name = "hire_details")
public class HireDetails implements Serializable{

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "hire_id")
	private long hireDetailsId;
	@DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
	private LocalDateTime startDateTime;	
	@DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
	private LocalDateTime expectedEndDateTime;
	@DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
	private LocalDateTime endDateTime;	
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinTable(name = "cust_hire_details",
			   joinColumns = @JoinColumn(name = "hire_id"),
			   inverseJoinColumns = @JoinColumn(name = "cust_id"))
	private Customers customer;
	@OneToOne(mappedBy = "hireDetails")
	private Invoices invoice;
//	@ManyToOne(fetch = FetchType.EAGER)
//	@JoinTable(name = "user_hire_details",
//			   joinColumns = @JoinColumn(name = "hire_id"),
//			   inverseJoinColumns = @JoinColumn(name = "user_id"))
//	private Users userRent;
//	@ManyToOne(fetch = FetchType.EAGER)
//	@JoinTable(name = "user_return_details",
//			   joinColumns = @JoinColumn(name = "hire_id"),
//			   inverseJoinColumns = @JoinColumn(name = "user_id"))
//	private Users userReturn;
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinTable(name = "vehicle_hire_details",
			   joinColumns = @JoinColumn(name = "hire_id"),
			   inverseJoinColumns = @JoinColumn(name = "vehicle_id"))
	private Vehicles vehicle;
	private String status;
	
	public long getHireDetailsId() {
		return hireDetailsId;
	}
	public void setHireDetailsId(long hireDetailsId) {
		this.hireDetailsId = hireDetailsId;
	}	
	public LocalDateTime getStartDateTime() {
		return startDateTime;
	}
	public void setStartDateTime(LocalDateTime startDateTime) {
		this.startDateTime = startDateTime;
	}
	public LocalDateTime getExpectedEndDateTime() {
		return expectedEndDateTime;
	}
	public void setExpectedEndDateTime(LocalDateTime expectedEndDateTime) {
		this.expectedEndDateTime = expectedEndDateTime;
	}
	public LocalDateTime getEndDateTime() {
		return endDateTime;
	}
	public void setEndDateTime(LocalDateTime endDateTime) {
		this.endDateTime = endDateTime;
	}
	public Customers getCustomer() {
		return customer;
	}
	public void setCustomer(Customers customer) {
		this.customer = customer;
	}
	public Invoices getInvoice() {
		return invoice;
	}
	public void setInvoice(Invoices invoice) {
		this.invoice = invoice;
	}	
//	public Users getUserRent() {
//		return userRent;
//	}
//	public void setUserRent(Users userRent) {
//		this.userRent = userRent;
//	}
//	public Users getUserReturn() {
//		return userReturn;
//	}
//	public void setUserReturn(Users userReturn) {
//		this.userReturn = userReturn;
//	}
	public Vehicles getVehicle() {
		return vehicle;
	}
	public void setVehicle(Vehicles vehicle) {
		this.vehicle = vehicle;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	@Override
	public String toString() {
		return "" + hireDetailsId;
	}	
	
}
