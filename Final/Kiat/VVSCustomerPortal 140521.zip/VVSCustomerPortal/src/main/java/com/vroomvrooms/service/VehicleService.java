package com.vroomvrooms.service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Random;

import javax.transaction.Transactional;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.vroomvrooms.model.Brand;
import com.vroomvrooms.model.VehicleImages;
import com.vroomvrooms.model.Vehicles;
import com.vroomvrooms.repository.VehicleImagesRepo;
import com.vroomvrooms.repository.VehicleRepo;

@Service
public class VehicleService {
	
	@Autowired
	private VehicleRepo vehRepo;
	
	@Autowired
	private VehicleImagesRepo vehImgRepo;
	
	@Autowired
	public VehicleService(VehicleRepo vehRepo) {
		this.vehRepo = vehRepo;
	}

	public List<Vehicles> getAllVehicles(Brand brand, String modelOfCar, String startDate, String endDate){
		System.out.println("this is start "+startDate);				
		System.out.println("this is end " +endDate);
//		System.out.println(brand);
//		System.out.println(modelOfCar);
//		LocalDateTime startLdt = LocalDateTime.parse(startDate);
//		LocalDateTime endLdt = LocalDateTime.parse(endDate);		
//		String startDay = startLdt.toLocalDate().toString();
//		String startDayBefore = startLdt.plusDays(-1).toLocalDate().toString();
//		String endDay = endLdt.toLocalDate().toString();
//		String endDayBefore = endLdt.plusDays(-1).toLocalDate().toString();
//		System.out.println(endDayBefore);
		if (brand!=null)
			if (brand.toString().equals("All") && modelOfCar.equals("All")) {
				System.out.println("find all");
				return vehRepo.findAll();
			}				
			else if (modelOfCar.equals("All")) {
				System.out.println("by brand");
				return vehRepo.findModelsByBrand(brand);
//				return vehRepo.findFreeCar(endDayBefore, endDay, brand);
//				return vehRepo.findTest(brand);
			}
				
		return vehRepo.findSpecificCar(brand, modelOfCar);		
//		return vehRepo.findFreeCar(endDayBefore, endDay, brand, modelOfCar);
	}
	
	public void saveVehicle(Vehicles vehicle) {
		vehRepo.save(vehicle);
	}
	
	public void deleteVehicleById(long vehicleId) {
		vehRepo.deleteById(vehicleId);
	}
	
	public Vehicles getVehicleById(long vehicleId) {
		
		Optional<Vehicles> optional = vehRepo.findById(vehicleId);
		Vehicles vehicle = null;
		
		if(optional.isPresent())
			vehicle = optional.get();
		else
			throw new RuntimeException("Vehicle is not found in data base :: " + vehicleId);
		
		return vehicle;
	}
	
	@Transactional
	public void updateStatus(String status, long vehId) {
		vehRepo.updateVehicleStatus(status, vehId);
	}
	
	public List<VehicleImages> getAllVehicleImagesById(long vehicleId) {
		
		return vehImgRepo.findByVehicleId(vehicleId);		
	}

	public VehicleImages saveUploads(@Valid VehicleImages vehImg) {
		
		return vehImgRepo.save(vehImg);
	}
	
	public void deleteUpload(Long vehImgId) {
		vehImgRepo.deleteById(vehImgId);
	}
	
	public VehicleImages getVehicleFromImgById(Long vehImgId) {
		
		Optional<VehicleImages> optional = vehImgRepo.findById(vehImgId);
		VehicleImages vehImg = null;
		
		if(optional.isPresent())
			vehImg = optional.get();
		else
			throw new RuntimeException("Image ID is not found in data base :: " + vehImgId);
		
		return vehImg;
	}

	public List<Vehicles> getAllModelsByBrand(Brand brand) {
		if (brand.toString().equals("All"))
			return vehRepo.findAll();
		return vehRepo.findModelsByBrand(brand);
	}

	public List<VehicleImages> getRandomImages(int imagesCount) {
		List<VehicleImages> imagesList = vehImgRepo.findAll();
		List<VehicleImages> randomList = new ArrayList<VehicleImages>();
		
		Random rand = new Random();
		for (int i=0; i<imagesCount; i++) {
			int randomIndex = rand.nextInt(imagesList.size());
			randomList.add(imagesList.get(randomIndex));
			imagesList.remove(randomIndex);
		}
 		
		return randomList;
	}
}
