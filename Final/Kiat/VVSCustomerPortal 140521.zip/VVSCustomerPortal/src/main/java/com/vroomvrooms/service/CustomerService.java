package com.vroomvrooms.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.vroomvrooms.model.Customers;
import com.vroomvrooms.repository.CustomerRepo;

@Service
public class CustomerService {

	@Autowired
	private CustomerRepo custRepo;
	
	@Autowired
	public CustomerService(CustomerRepo custRepo) {
		this.custRepo = custRepo;
	}
	
	public List<Customers> getAllCustomers(){
		return custRepo.findAll();
	}
	
	public void saveCustomer(Customers customer) {
		custRepo.save(customer);
	}
	
	public void deleteCustomerById(long custId) {
		custRepo.deleteById(custId);
	}
	
	public Customers getCustomerById(long custId) {
		
		Optional<Customers> optional = custRepo.findById(custId);
		Customers customer = null;
		
		if(optional.isPresent())
			customer = optional.get();
		else
			throw new RuntimeException("Customer not found for this id :: " + custId);
		
		return customer;
	}

	public Page<Customers> findPaginated(int pageNo, int pageSize, String keyword, String sortField,
			String sortDirection) {
		Sort sort = sortDirection.equalsIgnoreCase(Sort.Direction.ASC.name()) ? Sort.by(sortField).ascending()
					: Sort.by(sortField).descending();
		Pageable pageable = PageRequest.of(pageNo - 1, pageSize, sort);
		if (keyword != null && keyword!="") {
			return custRepo.search(keyword, pageable);
		}
		return custRepo.findAll(pageable);		
	}

	public Customers getCustomerByEmail(String email) {
		Optional<Customers> optional = custRepo.findByEmail(email);
		System.out.println("this is the email" + email);
		Customers customer = null;
		if (optional.isPresent())
			customer = optional.get();
		else
			throw new RuntimeException("Customer not found for email :: " + email);
		System.out.println(customer + " in service");
		return customer;		
	}

	public void updateProfile(Customers customer) {
		String email = customer.getEmail();
		Long contactNo = customer.getContactNo();
		String address = customer.getAddress();
		custRepo.updateProfile(contactNo, address, email);
		
	}
}
