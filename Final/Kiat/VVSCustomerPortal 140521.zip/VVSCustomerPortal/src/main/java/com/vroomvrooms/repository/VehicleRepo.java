package com.vroomvrooms.repository;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.vroomvrooms.model.Brand;
import com.vroomvrooms.model.VehicleImages;
import com.vroomvrooms.model.Vehicles;

public interface VehicleRepo extends JpaRepository<Vehicles, Long> {
	
	@Modifying
	@Query("UPDATE Vehicles SET status= :status WHERE vehicleId= :vehId")
	public void updateVehicleStatus(@Param("status")String status, @Param("vehId")long vehId);
	
	@Query("SELECT count(v) from Vehicles v WHERE v.status='Hired'")
	public long hiredVehiclesCount();

	@Query(value = "SELECT count(*) from Vehicles GROUP BY status", nativeQuery = true)
	public List<Integer> getNoOfVehicles();

	@Query(value = "SELECT status from Vehicles GROUP BY status", nativeQuery = true)
	public List<String> getVehicleStatus();

	@Query("SELECT v FROM Vehicles v WHERE CONCAT(v.id, ' ', lower(v.brand), ' ', v.regNo, ' ', lower(v.model), ' ', v.rentalRate) LIKE %?1%")
	public List<Vehicles> search(String keyword);
	
	@Query("SELECT v FROM Vehicles v WHERE v.status= :status")
	public List<Vehicles> displayWithStatus(@Param("status")String status);

	@Query("SELECT v FROM Vehicles v WHERE v.status= :status AND CONCAT(v.id, ' ', lower(v.brand), ' ', v.regNo, ' ', lower(v.model), ' ', v.rentalRate) LIKE %:keyword%")
	public List<Vehicles> searchWithStatus(@Param("status")String status, @Param("keyword")String keyword);

	@Query("SELECT v FROM Vehicles v WHERE v.brand= :brand")
	public List<Vehicles> findModelsByBrand(Brand brand);
	
	@Query("SELECT v FROM Vehicles v WHERE v.brand= :brand and v.model= :modelOfCar")
	public List<Vehicles> findSpecificCar(Brand brand, String modelOfCar);
	
	//@Query("SELECT v FROM Vehicles v inner join v.hireDetails hd WHERE v.brand= :brand and to_char(hd.expectedEndDateTime, 'yyyy.MM.dd') <= :endDayBefore or to_char(hd.expectedEndDateTime, 'yyyy.MM.dd') > :endDay")
	@Query(value="select *\r\n"
			+ "from vehicles v join VEHICLE_HIRE_DETAILS vhd on (v.vehicle_id=vhd.VEHICLE_ID) join HIRE_DETAILS hd on (vhd.hire_id=hd.HIRE_ID) \r\n"
			+ "where v.BRAND = 'Honda' and \r\n"
			+ "to_char(hd.EXPECTED_END_DATE_TIME, 'DD.MM.YYYY') <= '21/04/21' OR to_char(hd.EXPECTED_END_DATE_TIME, 'DD.MM.YYYY') > '22/04/21'", nativeQuery=true)
	public List<Vehicles> findFreeCar(@Param("endDayBefore")String endDayBefore, @Param("endDay")String endDay, @Param("brand")Brand brand);
	
	@Query("SELECT v FROM Vehicles v inner join v.hireDetails hd WHERE v.brand= :brand")
	public List<Vehicles> findTest(@Param("brand")Brand brand);

	@Query("SELECT h.startDateTime FROM Vehicles v inner join v.hireDetails h WHERE v.vehicleId = :vehId and h.status = 'Confirmed'")
	public LocalDate[] getStartDates(Long vehId);

	@Query("SELECT h.expectedEndDateTime FROM Vehicles v inner join v.hireDetails h WHERE v.vehicleId = :vehId and h.status = 'Confirmed'")
	public LocalDate[] getEndDates(Long vehId);

}
