package com.vroomvrooms.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.vroomvrooms.model.HireDetails;
import com.vroomvrooms.repository.HireDetailsRepo;

@Service
public class HireDetailsService {

	@Autowired
	private HireDetailsRepo hireDetRepo;
	
	public List<HireDetails> getAllHireDetails(){
		return hireDetRepo.findAll();
	}
	
	public void saveHireDetails(HireDetails hireDetails, boolean amend, long bookingId) {
		hireDetails.setStatus("Confirmed");
		if (amend) {
			HireDetails existingBooking = getHireDetailsById(bookingId);
			existingBooking.setStatus("Cancelled");
		}
		hireDetRepo.save(hireDetails);
	}
	
	public void cancelBookingById(HireDetails booking) {
		booking.setStatus("Cancelled");
		hireDetRepo.save(booking);
	}
	
	public HireDetails getHireDetailsById(long hireDetId) {
		
		Optional<HireDetails> optional = hireDetRepo.findById(hireDetId);
		HireDetails hireDetails = null;
		
		if(optional.isPresent())
			hireDetails = optional.get();
		else
			throw new RuntimeException("Hire Details not found for this is :: " + hireDetId);
		
		return hireDetails;
	}

	public Page<HireDetails> findPaginated(int pageNo, Integer pageSize, String keyword, String sortField,
			String sortDirection, long custId) {
		Sort sort= sortDirection.equalsIgnoreCase(Sort.Direction.ASC.name()) ? Sort.by(sortField).ascending()
				: Sort.by(sortField).descending();
		Pageable pageable = PageRequest.of(pageNo - 1, pageSize, sort);
		if(keyword !=null && keyword!="") {			
			return hireDetRepo.search(keyword, pageable);
		}		
		return hireDetRepo.findUpcomingBookings(custId, pageable);		
	}
}
