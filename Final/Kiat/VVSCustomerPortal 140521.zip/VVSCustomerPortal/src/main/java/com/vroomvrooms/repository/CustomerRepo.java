package com.vroomvrooms.repository;

import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.vroomvrooms.model.Customers;

public interface CustomerRepo extends JpaRepository<Customers, Long> {

	@Query("SELECT c FROM Customers c WHERE CONCAT(c.id, ' ', c.nric, ' ', c.name, ' ', c.contactNo, ' ', c.address) LIKE %?1%")
	Page<Customers> search(String keyword, Pageable pageable);

	@Query("SELECT c FROM Customers c where email= :email")
	Optional<Customers> findByEmail(@Param("email")String email);
	
	@Transactional
	@Modifying
	@Query("UPDATE Customers SET contactNo= :contactNo, address= :address WHERE email= :email")
	void updateProfile(Long contactNo, String address, String email);

}
