package com.vroomvrooms.service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.vroomvrooms.model.HireDetails;
import com.vroomvrooms.model.Invoices;
import com.vroomvrooms.repository.InvoiceRepo;

@Service
public class InvoiceService {
	
	@Autowired
	private InvoiceRepo invoiceRepo;
	
	public List<Invoices> getAllInvoices(){
		return invoiceRepo.findAll();
	}
	
	public void saveInvoice(Invoices invoice) {
		invoiceRepo.save(invoice);
	}
	
	public void deleteInvoiceById(long invoiceId) {
		invoiceRepo.deleteById(invoiceId);
	}
	
	public Invoices getInvoiceById(long invoiceId) {
		
		Optional<Invoices> optional = invoiceRepo.findById(invoiceId);
		Invoices invoice = null;
		
		if(optional.isPresent())
			invoice = optional.get();
		else
			throw new RuntimeException("Invoice not found for this id :: " + invoiceId);
		return invoice;
	}

	public long getInvoiceAmount(HireDetails hireDetails) {
		long expectedRentDuration = ChronoUnit.DAYS.between(hireDetails.getStartDateTime(), hireDetails.getExpectedEndDateTime());			
		long totalAmount = (expectedRentDuration * hireDetails.getVehicle().getRentalRate());
		return totalAmount;
	}
	
	public long getLateFees(HireDetails hireDetails) {
		long lateFees = 0;
		long lateDuration = ChronoUnit.MINUTES.between(hireDetails.getExpectedEndDateTime(), hireDetails.getEndDateTime());
		if (lateDuration>0) {
			//first 30 mins late is $10, every 30 mins after is $15 per 30 mins round down
			long lateBlocks = (lateDuration / 30);
			lateFees = 10 + (lateBlocks*15);
		}
		return lateFees;
	}
	
	public double invoiceAmountGST(double totalAmount) {
		double GSTamount = new BigDecimal(totalAmount * 1.07).setScale(2, RoundingMode.HALF_UP).doubleValue(); 
		return GSTamount;
	}

	public Page<Invoices> findPaginated(int pageNo, Integer pageSize, String keyword, String sortField,
			String sortDirection, String status, long custId) {
		Sort sort= sortDirection.equalsIgnoreCase(Sort.Direction.ASC.name()) ? Sort.by(sortField).ascending()
				: Sort.by(sortField).descending();
		Pageable pageable = PageRequest.of(pageNo - 1, pageSize, sort);
		if(keyword !=null && keyword!="") {
			return invoiceRepo.search(custId, keyword, pageable);
		}
		return invoiceRepo.findPastBookings(custId, pageable);
	}

}
