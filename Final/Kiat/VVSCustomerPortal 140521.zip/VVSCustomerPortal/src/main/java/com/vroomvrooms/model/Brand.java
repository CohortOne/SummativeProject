package com.vroomvrooms.model;

public enum Brand {
	Select,
	All,
	Toyota,
	Honda,
	Hyundai;

}
