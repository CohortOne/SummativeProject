package com.vroomvrooms.controller;

import java.security.Principal;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.stream.Collectors;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.vroomvrooms.model.Customers;
import com.vroomvrooms.model.HireDetails;
import com.vroomvrooms.model.Invoices;
import com.vroomvrooms.service.CustomerService;
import com.vroomvrooms.service.HireDetailsService;
import com.vroomvrooms.service.InvoiceService;

@Controller
public class InvoiceController {
	
	@Autowired
	private InvoiceService invoiceService;
	
	@Autowired
	private HireDetailsService hireService;
	
	@Autowired
	private CustomerService custService;
	
	@RequestMapping("/all_bookings")
	public String viewInvoicesPage(Model model, @Param("pageSize")Integer pageSize, @Param("keyword")String keyword, @Param("status")String status, Principal principal) {
		return invoicePaginated(1, pageSize, "invoiceId", "ASC", model, keyword, status, principal);
	}
	
	@RequestMapping("/all_bookings/{pageNo}")
	private String invoicePaginated(@PathVariable(value="pageNo")int pageNo,
			   @Param("pageSize")Integer pageSize,
			   @Param("sortField") String sortField,
			   @Param("sortDirection")String sortDirection,
			   Model model,
			   @Param("keyword") String keyword,
			   @Param("status")String status,
			   Principal principal) {
		//default page size
		if(pageSize==null)
			pageSize=5;
		long custId = custService.getCustomerByEmail(principal.getName()).getCustId();
		Page<Invoices> page = invoiceService.findPaginated(pageNo, pageSize, keyword, sortField, sortDirection,status, custId);
		List<Invoices> listInvoices = page.getContent().stream()
									  .distinct()
									  .collect(Collectors.toList());
		
		model.addAttribute("pastBookings", listInvoices);
		model.addAttribute("pageSize", pageSize);
		model.addAttribute("totalPages", page.getTotalPages());
		model.addAttribute("totalItems", page.getTotalElements());
		model.addAttribute("currentItems", page.getNumberOfElements());
		model.addAttribute("currentPage", pageNo);
		model.addAttribute("sortField", sortField);
		model.addAttribute("sortDirection", sortDirection);
		model.addAttribute("reverseSortDir", sortDirection.equalsIgnoreCase("ASC") ? "DESC" : "ASC");
		model.addAttribute("keyword", keyword);
		model.addAttribute("status", status);
		model.addAttribute("urlLink", "all_bookings");
		
		return "all_bookings";
	}
		
	@GetMapping("/generate_invoice/")
	public String newInvoiceForm(Model model, @Param(value="hireId")long hireId, Principal principal) {
		Customers cust = custService.getCustomerByEmail(principal.getName());
		Invoices invoice = new Invoices();
		HireDetails hireDetails = hireService.getHireDetailsById(hireId);
		long invoiceAmount = invoiceService.getInvoiceAmount(hireDetails);
		long lateFees = invoiceService.getLateFees(hireDetails);
		double totalAmount = invoiceAmount + lateFees;		
		double totalAmountGST = invoiceService.invoiceAmountGST(totalAmount);
		LocalDateTime today = LocalDateTime.now();
		model.addAttribute("customer", cust.getCustId());
		model.addAttribute("invoice", invoice);
		model.addAttribute("amountNoGST", invoiceAmount);
		model.addAttribute("lateFees", lateFees);
		model.addAttribute("amountGST", totalAmountGST);
		model.addAttribute("hire", hireDetails);
		model.addAttribute("hireId", hireId);
		model.addAttribute("issueDate", today);
		return "invoice_loading";
	}
	
	@PostMapping("/saveInvoice")
	public String saveInvoice(@Valid @ModelAttribute("invoice")Invoices invoice, BindingResult bindingResult) {
		
		if (bindingResult.hasErrors()) {
			bindingResult.getFieldErrors().forEach(f -> System.out.println(f.getField() + ": " + f.getDefaultMessage()));
			return "index";
		}			
		invoiceService.saveInvoice(invoice);		
		return "redirect:/viewInvoice";		
	}
	
	@RequestMapping("/viewInvoice/")
	public String viewInvoice(@Param(value="invoiceId")long invoiceId, Model model) {
//		if(invoice.equals(null)) {
//			invoice = invoiceService.getInvoiceById(invoiceId);
//		}
		
		Invoices invoice = invoiceService.getInvoiceById(invoiceId);
		long lateDuration = ChronoUnit.MINUTES.between(invoice.getHireDetails().getExpectedEndDateTime(), invoice.getHireDetails().getEndDateTime());
		model.addAttribute("lateDuration", lateDuration);
		model.addAttribute("invoice", invoice);
		return "invoice";
	}

}
