package com.vroomvrooms.controller;

import java.io.IOException;
import java.security.Principal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.data.domain.Page;
import org.springframework.data.repository.query.Param;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.util.StringUtils;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.thymeleaf.util.ArrayUtils;

import com.google.gson.Gson;
import com.vroomvrooms.model.Brand;
import com.vroomvrooms.model.BrandCriteria;
import com.vroomvrooms.model.Customers;
import com.vroomvrooms.model.VehicleIdForImages;
import com.vroomvrooms.model.VehicleImages;
import com.vroomvrooms.model.Vehicles;
import com.vroomvrooms.repository.HireDetailsRepo;
import com.vroomvrooms.repository.VehicleRepo;
import com.vroomvrooms.service.CustomerService;
import com.vroomvrooms.service.HireDetailsService;
import com.vroomvrooms.service.VehicleService;
import com.vroomvrooms.model.HireDetails;

@Controller
public class BookingController {
	
	@Autowired
	private VehicleService vehService;
	
	@Autowired
	private HireDetailsService hireService;
	
	@Autowired
	private HireDetailsRepo hireRepo;
	
	@Autowired
	private VehicleRepo vehRepo;
	
	@Autowired
	private CustomerService custService;
	
	@GetMapping("/home")
	public String homePage(Model model) {
		int noOfImagesToDisplay = 3;
		List<VehicleImages> randomImages = vehService.getRandomImages(noOfImagesToDisplay);
		model.addAttribute("randomImages", randomImages);
		return "index";
	}
	
	@RequestMapping("/booking")
	public String viewVehiclePage(Model model, Brand brand, String modelOfCar, String startDate, String endDate) {
		List<Vehicles> listVehicles = vehService.getAllVehicles(brand, modelOfCar, startDate, endDate);	
		System.out.println(listVehicles.stream().distinct().count());
		model.addAttribute("listVehicles", listVehicles.stream().distinct().collect(Collectors.toList()));		
		model.addAttribute("brand", brand);
		model.addAttribute("modelOfCar", modelOfCar);
		model.addAttribute("startDate", startDate);
		model.addAttribute("endDate", endDate);

		return "booking";				
	}
	
//	@RequestMapping("/all_bookings")
//	public String allBookings(Model model, Principal principal) {
//		long custId = custService.getCustomerByEmail(principal.getName()).getCustId(); 
//		System.out.println(custId);
//		List<HireDetails> pastBookings = hireRepo.getAllBookings(custId); 
//		model.addAttribute("pastBookings", pastBookings);
//		return "all_bookings";
//	}

	@RequestMapping("/upcoming_bookings")
	public String viewHireDetailsPage(Model model, @Param("pageSize")Integer pageSize, @Param("keyword")String keyword, Principal principal) {		
		return hiresPagination(1, pageSize, "expectedEndDateTime", "DESC", model, keyword, principal);
	}
	
	@GetMapping("/upcoming_bookings/{pageNo}")
	private String hiresPagination(@PathVariable(value="pageNo")int pageNo,
									   @Param("pageSize")Integer pageSize,
									   @Param("sortField") String sortField,
									   @Param("sortDirection")String sortDirection,
									   Model model,									   
									   @Param("keyword") String keyword,
									   Principal principal) {
		if (pageSize == null)
			pageSize = 5;
		long custId = custService.getCustomerByEmail(principal.getName()).getCustId();		
		Page<HireDetails> page = hireService.findPaginated(pageNo, pageSize, keyword, sortField, sortDirection, custId);
		List<HireDetails> listHireDetails = page.getContent().stream()
										 .distinct()
										 .collect(Collectors.toList());		
		model.addAttribute("upcomingBookings", listHireDetails);
		model.addAttribute("pageSize", pageSize);
		model.addAttribute("totalPages", page.getTotalPages());
		model.addAttribute("totalItems", page.getTotalElements());
		model.addAttribute("currentItems", page.getNumberOfElements());
		model.addAttribute("currentPage", pageNo);
		model.addAttribute("sortField", sortField);
		model.addAttribute("sortDirection", sortDirection);
		model.addAttribute("reverseSortDir", sortDirection.equalsIgnoreCase("ASC") ? "DESC" : "ASC");
		model.addAttribute("keyword", keyword);	
		model.addAttribute("urlLink", "all_bookings");
		return "upcoming_bookings";
	}
	
	@GetMapping("/amend_booking/")
	public String amendHireForm(Model model, @Param(value="hireId")long hireId, Principal principal) {
		HireDetails booking = hireService.getHireDetailsById(hireId);				
		model.addAttribute("booking", booking);		
		model.addAttribute("amend", true);
		return "change_booking";
	}
	
	@RequestMapping("/payment")
	public String paymentPage(Model model, @ModelAttribute("bookingDetails")HireDetails bookingDetails, 
			@Param("startDate")String startDate, @Param("endDate")String endDate, @Param("vehId")Long vehId, 
			@Param("bookingId")Long bookingId, Principal principal, @Param("amend")boolean amend) {
		Customers cust = custService.getCustomerByEmail(principal.getName());
		System.out.println("this is customer " + custService.getCustomerByEmail(principal.getName()));		
		Vehicles vehicle = vehService.getVehicleById(vehId);
		if(bookingId!=null) {
			System.out.println(hireService.getHireDetailsById(bookingId).getInvoice().getInvoiceId());
			System.out.println("this is booking id " + bookingId);
		}
		if (bookingDetails==null) {
			bookingDetails = new HireDetails();
		}
		
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
		long expectedRentDuration = ChronoUnit.DAYS.between(LocalDateTime.parse(startDate, formatter), LocalDateTime.parse(endDate, formatter));			
		long totalAmount = (expectedRentDuration * vehicle.getRentalRate());
		model.addAttribute("custId", cust.getCustId());
		model.addAttribute("totalAmount", totalAmount);
		model.addAttribute("startDate", LocalDateTime.parse(startDate, formatter));
		model.addAttribute("endDate", LocalDateTime.parse(endDate, formatter));
		model.addAttribute("vehicle", vehicle);
		model.addAttribute("bookingDetails", bookingDetails);
		model.addAttribute("amend", amend);
		model.addAttribute("bookingId", bookingId);
		System.out.println(vehicle.getBrand());
		return "payment-page";
	}
	
	@PostMapping("/process-payment")
	public String processPayment(@Valid @ModelAttribute("bookingDetails")HireDetails bookingDetails, BindingResult bindingResult, 
								@Param("amend")boolean amend, @Param("bookingId")long bookingId) {
		if(bindingResult.hasErrors()) {
			bindingResult.getFieldErrors().forEach(f -> System.out.println(f.getField() + ": " + f.getDefaultMessage()));
			return "index";
		}		
		hireService.saveHireDetails(bookingDetails, amend, bookingId);				
		return "redirect:/success";
	}
	
	@GetMapping("/success")
	public String successBooking() {
		return "success_booking";
	}
	
	@RequestMapping("/cancel_booking")
	public String successBooking(@Param(value="bookingId")Long bookingId) {
		System.out.println("cancelling " + bookingId);
		HireDetails booking = hireService.getHireDetailsById(bookingId);		
		hireService.cancelBookingById(booking);
		return "redirect:/upcoming_bookings";
	}
	
	@RequestMapping(value = "/loadVehicleImages", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	 public @ResponseBody List<VehicleImages> loadImagesByVehicles(@RequestBody VehicleIdForImages vehicleIdForImages) {
	  List<VehicleImages> vehImgs = vehService.getAllVehicleImagesById(vehicleIdForImages.getVehicleId());
	  
	  return vehImgs;
	 }
	
	@RequestMapping(value = "/loadModelsByBrand", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	 public @ResponseBody List<Vehicles> loadModelsByBrand(@RequestBody BrandCriteria brand) {
	  List<Vehicles> models = vehService.getAllModelsByBrand(brand.getBrand());	  
	  return models;
	 }

	@RequestMapping(value = "/loadDatesByCar/{vehId}", method = RequestMethod.GET)
	@ResponseBody
	public String loadDatesByCar(@PathVariable("vehId") Long vehId) {
		LocalDate[] startDates = vehRepo.getStartDates(vehId);		
		for (LocalDate date:startDates) {
			System.out.println(vehId + "in loaddatebycar" + date);
		}
		LocalDate[] endDates = vehRepo.getEndDates(vehId);
		
		List<String> blockDates = new ArrayList<String>(); 
		for(int i=0;i<startDates.length;i++) {
			LocalDate start = startDates[i];
//			while(!start.equals(endDates[i])&& !blockDates.contains(start.toString()) && start.isAfter(LocalDate.now())) {
			while(!start.equals(endDates[i]) && !blockDates.contains(start.toString())) { //remove start.isAfter
				blockDates.add(start.toString());
				start = start.plusDays(1);
			}
			if(!blockDates.contains(endDates[i].toString()) && endDates[i].isAfter(LocalDate.now())) {
				blockDates.add(endDates[i].toString());
			}			
		}
		Gson gson = new Gson();
		return gson.toJson(blockDates);
	}
	
	@RequestMapping(value = "/amendDatesByCar/{vehId}/{bookingId}", method = RequestMethod.GET)
	@ResponseBody
	public String amendDatesByCar(@PathVariable("vehId") Long vehId, @PathVariable("bookingId") Long bookingId) {
		LocalDate[] startDates = vehRepo.getStartDates(vehId);
		LocalDate currentStartDate = hireService.getHireDetailsById(bookingId).getStartDateTime().toLocalDate();
		LocalDate[] newStartDates = updatingDates(startDates, 0, currentStartDate);
		
//		Test if dates are updated
//		for (LocalDate date:newStartDates) {
//			System.out.println(vehId + "in loaddatebycar" + date);
//		}
		LocalDate[] endDates = vehRepo.getEndDates(vehId);
		LocalDate currentEndDate = hireService.getHireDetailsById(bookingId).getExpectedEndDateTime().toLocalDate();		
		LocalDate[] newEndDates = updatingDates(endDates, 0, currentEndDate);
//		for (LocalDate date:newEndDates) {
//			System.out.println(vehId + "in loaddatebycar" + date);
//		}
		
		List<String> blockDates = new ArrayList<String>(); 
		for(int i=0;i<newStartDates.length;i++) {
			LocalDate start = newStartDates[i];
//			while(!start.equals(endDates[i])&& !blockDates.contains(start.toString()) && start.isAfter(LocalDate.now())) {
			while(!start.equals(newEndDates[i]) && !blockDates.contains(start.toString())) { //remove start.isAfter
				blockDates.add(start.toString());
				start = start.plusDays(1);
			}
			if(!blockDates.contains(newEndDates[i].toString()) && newEndDates[i].isAfter(LocalDate.now())) {
				blockDates.add(newEndDates[i].toString());
			}			
		}
		Gson gson = new Gson();
		return gson.toJson(blockDates);
	}
	
	private LocalDate[] updatingDates(LocalDate[] bookedDates, int index, LocalDate date) {
		if (bookedDates == null
	            || index < 0
	            || index >= bookedDates.length) {
	  
	            return bookedDates;
	        }
		LocalDate[] updatedDates = new LocalDate[bookedDates.length-1];
		while(index < bookedDates.length) {			
			
			if(bookedDates[index].equals(date)) {
				
				break;
			}
			index++;
		}		
		System.arraycopy(bookedDates, 0, updatedDates, 0, index);
		System.arraycopy(bookedDates, index+1, updatedDates, index, bookedDates.length-index-1);
		return updatedDates;
	}
}
