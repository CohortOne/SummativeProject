package com.vroomvrooms.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class PagesController {
	
	@GetMapping("/about_us")
	public String aboutUs() {
		return "about-us";
	}
	
	@GetMapping("/contact_us")
	public String contactUs() {
		return "contact-us";
	}
	
	@RequestMapping("/login")
	public String login() {
		return "login";
	}
}
