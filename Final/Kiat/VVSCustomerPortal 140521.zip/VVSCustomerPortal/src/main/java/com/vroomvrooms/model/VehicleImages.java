package com.vroomvrooms.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonBackReference;

@Entity
@Table(name = "vehicleimages")
public class VehicleImages {

	@Id
	@Column(name = "vehimg_id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long vehImgId;
	
	@Column(length = 45, nullable = false)
	private String name;	
	
	@JsonBackReference
	@ManyToOne 
	@JoinTable (name = "vehicles_images",
				joinColumns = @JoinColumn(name = "vehimg_id"),
				inverseJoinColumns = @JoinColumn(name = "vehicleId"))
	private Vehicles vehicle;
	
	@Transient
	private Data data;

	private String hrefLink;
	
	private String success;

	private String status;	

	public Long getVehImgId() {
		return vehImgId;
	}

	public void setVehImgId(long vehImgId) {
		this.vehImgId = vehImgId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Vehicles getVehicle() {
		return vehicle;
	}

	public void setVehicle(Vehicles vehicle) {
		this.vehicle = vehicle;
	}	
	
	@Transient
	public String getNameImagePath() {
		
		if (name == null || vehImgId == null) 
			return null;
		
		return "/vehicle-images/" + vehImgId + "/" + name;
	}

	public Data getData() {
		return data;
	}

	public void setData(Data data) {
		this.data = data;
	}

	public String getSuccess() {
		return success;
	}

	public void setSuccess(String success) {
		this.success = success;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}	
		
	public String getHrefLink() {
		return hrefLink;
	}

	public void setHrefLink(String hrefLink) {
		this.hrefLink = hrefLink;
	}

	@Override
	public String toString() {		
		return hrefLink;
	}

	public class Data {

		private String link;
		
		private String deleteHash;

		public Data() {}
		public String getLink() {
			return link;
		}

		public void setLink(String link) {
			this.link = link;
		}
		
		public String getDeleteHash() {
			return deleteHash;
		}

		public void setDeleteHash(String deleteHash) {
			this.deleteHash = deleteHash;
		}

	}
}
