package com.vroomvrooms.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.vroomvrooms.model.Customers;
import com.vroomvrooms.repository.CustomerRepo;

@Service
public class CustomerDetailService implements UserDetailsService  {
	
	@Autowired
	private CustomerRepo custRepo;	
	
	@Autowired
	private CustomerService custService;
	
	@Override
	public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException{
		
		Customers customer = custService.getCustomerByEmail(email);
		if (customer==null)
			throw new UsernameNotFoundException("Could not find email " + email);
		
//		UserDetails user = User.withUsername(customer.getEmail())
//	            .password(customer.getPassword())
//	            .authorities("USER").build();
		
		return new CustomerDetailImpl(customer);
	}

	@Transactional
	public boolean isEmailAlreadyInUse(String email) {
		
		boolean userInDB = true;
		if(custRepo.findByEmail(email) == null)
			userInDB = false;
		return userInDB;
	}

}
