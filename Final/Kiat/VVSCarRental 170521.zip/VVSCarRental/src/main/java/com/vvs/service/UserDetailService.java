package com.vvs.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.vvs.model.Users;
import com.vvs.repository.UserRepo;

@Service
public class UserDetailService implements UserDetailsService  {
	
	@Autowired
	private UserRepo userRepo;
	
	@Autowired
	private UserService userService;
	
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException{
		
		Users users = userRepo.getUserByUserName(username);
		if (users==null)
			throw new UsernameNotFoundException("Could not find user " + username);
		
		return new UserDetailImpl(users);
	}

	@Transactional
	public boolean isUsernameAlreadyInUse(String username) {
		
		boolean userInDB = true;
		if(userService.getUserByUsername(username) == null)
			userInDB = false;
		return userInDB;
	}

}
