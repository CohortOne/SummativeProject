package com.vvs.controller;

import java.io.IOException;
import java.security.Principal;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.repository.query.Param;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.vvs.error.UserAlreadyExistException;
import com.vvs.model.UserRole;
import com.vvs.model.Users;
import com.vvs.repository.UserRepo;
import com.vvs.repository.UserRoleRepo;
import com.vvs.service.UserService;

@Controller
public class UserController {

	int i=0;
	@Autowired
	private UserService userService;
	
	@Autowired
	private UserRoleRepo roleRepo;
	
	@Autowired
	private UserRepo userRepo;
	
	
	@RequestMapping("/users")
	public String viewUsersPage(Model model, @Param("pageSize")Integer pageSize, @Param("keyword")String keyword) {
		return findAdminPageinated(1, pageSize, "userId", "ASC", model, keyword);		
	}

	@GetMapping("/users/{pageNo}")
	private String findAdminPageinated(@PathVariable(value="pageNo")int pageNo,
									   @Param("pageSize")Integer pageSize,
									   @Param("sortField") String sortField,
									   @Param("sortDirection")String sortDirection,
									   Model model,
									   @Param("keyword") String keyword) {
		
		if (pageSize == null)
			pageSize = 5;		
		Page<Users> page = userService.findPageinated(pageNo, pageSize, keyword, sortField, sortDirection);
		List<Users> listUsers = page.getContent().stream()
								.distinct()
								.collect(Collectors.toList());
		int totalPages = page.getTotalPages();		
		
		model.addAttribute("listUsers", listUsers);
		model.addAttribute("pageSize", pageSize);
		model.addAttribute("totalPages", totalPages);
		model.addAttribute("totalItems", page.getTotalElements());
		model.addAttribute("currentItems", page.getNumberOfElements());
		model.addAttribute("currentPage", pageNo);
		model.addAttribute("sortField", sortField);
		model.addAttribute("sortDirection", sortDirection);
		model.addAttribute("reverseSortDir", sortDirection.equalsIgnoreCase("ASC") ? "DESC" : "ASC");
		model.addAttribute("keyword", keyword);
		model.addAttribute("urlLink", "users");
		return "users";
	}
	
	@GetMapping("/users/newUser")
	public String newUserForm(Model model, @ModelAttribute("user")Users user) {
		if(user==null) {
			user = new Users();
		}		
		model.addAttribute("user", user);
		model.addAttribute("update", false);
		List<UserRole> roles = roleRepo.findAll();
		model.addAttribute("roles", roles);
		return "user_form";
	}
	
	@PostMapping("/users/saveNewUser")
	public String saveNewUser(@Valid @ModelAttribute("user")Users user, RedirectAttributes ra, BindingResult bindingResult) {
		if (bindingResult.hasErrors())
			return "user_form";
		if (userService.saveNewUser(user)=="Failure") {
			ra.addFlashAttribute("message", "User Already Exists !");
			ra.addFlashAttribute("user", user);
			return "redirect:/users/newUser";
		}else if(userService.saveNewUser(user)=="Success")		
			ra.addFlashAttribute("message", "The Entry has been added successfully !");
		return "redirect:/users";
	}
	
	@PostMapping("/users/saveUser")
	public String saveUser(@Valid @ModelAttribute("user")Users user, RedirectAttributes ra, BindingResult bindingResult) {
		if (bindingResult.hasErrors())
			return "user_form";		
		userService.saveUser(user);
		ra.addFlashAttribute("message", "The Entry has been saved successfully !");
		return "redirect:/users";
	}
	
	@PostMapping("/saveProfile")
	public String uploadProfilePic(@RequestParam("profilePic")MultipartFile multipartFile, @ModelAttribute("user")Users user, RedirectAttributes ra) throws IOException {
		userService.saveProfilePic(user, multipartFile);
		ra.addAttribute("username",user.getUsername());
		ra.addFlashAttribute("message", "The Profile Picture has been saved successfully !");
		return "redirect:/profile/";
	}
	
	@GetMapping("/users/updateUser/{id}")
	public String updateUserForm(@PathVariable(value="id")long userId, Model model) {
		Users user = userService.getUserById(userId);
		model.addAttribute("user", user);
		model.addAttribute("update", true);
		List<UserRole> roles = roleRepo.findAll();
		model.addAttribute("roles", roles);
		return "user_form";
	}
	
	@GetMapping("/users/deleteUser/")
	public String deleteUser(@RequestParam(value="id")long userId, RedirectAttributes ra) {
		Users user = userService.getUserById(userId);
		userRepo.delete(user);
		ra.addFlashAttribute("message", "The Entry has been deleted");
		return "redirect:/users";
	}
	
	@GetMapping("/profile/")
	public String viewProfile(@RequestParam(value="username")String username, Model model, @ModelAttribute("edit")String edit) {
		i=i+1;
		System.out.println("this is before edit:: " + edit);
		Users user = userRepo.getUserByUserName(username);
		if (edit==null || edit == "")
			edit = "false";
		System.out.println("this is after edit:: " +  edit);
		System.out.println(username+" in controller" + i + edit);	
		model.addAttribute("edit", edit);
		if (user!=null)
			model.addAttribute("user", user);
		else
			model.addAttribute("user", new Users());
		List<UserRole> roles = roleRepo.findAll();
		model.addAttribute("roles", roles);
		return "profile";
	}
	
	@RequestMapping(value = "/image/{username}", produces = MediaType.IMAGE_PNG_VALUE)
    public ResponseEntity<byte[]> getImage(@PathVariable("username") String username) throws IOException {
        
    	Users user = userService.getUserByUsername(username);
		byte[] imageContent = user.getProfilePicture();
		final HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.IMAGE_PNG);
        return new ResponseEntity<byte[]>(imageContent, headers, HttpStatus.OK);
    }
    
    @RequestMapping("/profile/resetpw")
    public String resetPassword(@RequestParam(value="username")String username, Model model) {
    	
    	Users user = userRepo.getUserByUserName(username);
    	model.addAttribute("user", user);    	
    	return "reset_password";
    }
    
    @RequestMapping("/profile/savepw")
    public String saveNewPassword(@ModelAttribute("user")Users user, RedirectAttributes ra, @RequestParam("currentPw")String currentPassword, @RequestParam("newPw")String newPassword, @RequestParam(value="username")String username) {
    	    	
    	if (userService.saveNewPassword(currentPassword, newPassword, username)) {
    		ra.addFlashAttribute("message", "The Password has been reseted!");
    		return "redirect:/profile/?username="+username;
    	}else {
    		ra.addFlashAttribute("message", "Please double check your password!");
        	return "redirect:/profile/resetpw?username="+username;
    	}    	
    }    
    
    @GetMapping("/profile/edit")
    public String editProfile(@RequestParam(value="username")String username, RedirectAttributes ra) {
    	ra.addFlashAttribute("edit", "true");
    	return "redirect:/profile/?username="+username;
    }
    
    @PostMapping("/saveContact")
	public String updateContactDetails(@Valid @ModelAttribute("user")Users user, RedirectAttributes ra, BindingResult bindingResult) {
		if (bindingResult.hasErrors())
			return "redirect:/profile/edit";		
		userService.saveUser(user);
		ra.addFlashAttribute("message", "The Contact Details have been updated !");
		return "redirect:/profile/?username="+user.getUsername();
	}
}
