package com.vvs.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import com.vvs.service.UserDetailService;

@Configuration
@EnableWebSecurity
public class WebSecurityConfig extends WebSecurityConfigurerAdapter {

	@Bean
	public UserDetailsService userDetailsService() {
		return new UserDetailService();
	}
	
	@Bean
	public BCryptPasswordEncoder passwordEncoder() {
		return new BCryptPasswordEncoder();
	}
	
	@Bean
	public DaoAuthenticationProvider authenticationProvider() {
		DaoAuthenticationProvider authProvider = new DaoAuthenticationProvider();
		authProvider.setUserDetailsService(userDetailsService());
		authProvider.setPasswordEncoder(passwordEncoder());
		
		return authProvider;
	}
	
	@Override
	protected void configure(AuthenticationManagerBuilder auth) throws Exception{
		auth.authenticationProvider(authenticationProvider());
	}
	
	@Override
	protected void configure(HttpSecurity http) throws Exception{
		http.authorizeRequests()
//			.anyRequest().authenticated()
//			.and()
//			.formLogin().permitAll()
//			.and()
//			.logout().permitAll();
			.antMatchers("/login", "/forgotpassword/**").permitAll()
			.antMatchers("/").hasAnyAuthority("ADMIN", "USER", "MANAGER")
			.antMatchers("/deleteVehicle/**").hasAnyAuthority("ADMIN", "MANAGER")
			.antMatchers("/deleteHireDetails/**").hasAnyAuthority("ADMIN", "MANAGER")
			.antMatchers("/deleteInvoice/**").hasAnyAuthority("ADMIN", "MANAGER")
			.antMatchers("/users/**").hasAuthority("ADMIN")
			.anyRequest().authenticated()
			.and()
			.csrf().disable()
			.formLogin(form -> form
					.loginPage("/login")
					.defaultSuccessUrl("/", true)
					.failureUrl("/login?error=true")
			)			
			.logout().permitAll()			
			;
	}
	
	 @Override
	    public void configure(WebSecurity web) {
	        web.ignoring()
	            .antMatchers("/assets/**", "/static/**");
	    }
}
