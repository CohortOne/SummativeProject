package com.vvs.scheduling;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.vvs.model.Vehicles;
import com.vvs.repository.VehicleRepo;
import com.vvs.service.VehicleService;

@Component
public class ScheduledTasks {

	@Autowired
	private VehicleService vehService;
	
	@Autowired
	private VehicleRepo vehRepo;
	
	@Scheduled(cron = "0 0 0 * * ?")
	public void checkVehicleStatus() {
		List<Vehicles> allVehicles = vehService.getAllVehicles();
		for (Vehicles veh:allVehicles) {
			LocalDate[] startDates = vehRepo.getStartDates(veh.getVehicleId());		
			
			LocalDate[] endDates = vehRepo.getEndDates(veh.getVehicleId());
			
			List<String> blockDates = new ArrayList<String>(); 
			for(int i=0;i<startDates.length;i++) {
				LocalDate start = startDates[i];
				
				while(!start.equals(endDates[i]) && !blockDates.contains(start.toString())) { //remove start.isAfter
					blockDates.add(start.toString());
					start = start.plusDays(1);
				}
				if(!blockDates.contains(endDates[i].toString()) && endDates[i].isAfter(LocalDate.now())) {
					blockDates.add(endDates[i].toString());
				}			
			}
			for (String date:blockDates) {
				System.out.println(veh.getVehicleId() + "in loaddatebycar" + date);
			}
			if(blockDates.contains(LocalDate.now().toString())) {
				System.out.println("method at checking now date "+ LocalDate.now().toString());
				veh.setStatus("Hired");
				vehService.saveVehicle(veh);
			}
		}
	}
}
