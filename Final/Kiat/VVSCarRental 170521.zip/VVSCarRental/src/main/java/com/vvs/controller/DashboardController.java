package com.vvs.controller;

import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.vvs.model.HireDetails;
import com.vvs.repository.CustomerRepo;
import com.vvs.repository.HireDetailsRepo;
import com.vvs.repository.InvoiceRepo;
import com.vvs.repository.VehicleRepo;

@Controller
public class DashboardController {

	@Autowired
	private CustomerRepo custRepo;
	
	@Autowired
	private VehicleRepo vehRepo;
	
	@Autowired
	private InvoiceRepo invoiceRepo;
	
	@Autowired
	private HireDetailsRepo hireRepo;
	
	@RequestMapping("/")
	public String viewHomePage(Model model) {
		long totalCustomers = custRepo.count();
		long hiredVehicles = vehRepo.hiredVehiclesCount();
		double currentMonthlyAmount = invoiceRepo.currentMonthlyAmount();
		double totalAnnualAmount = invoiceRepo.totalAnnualAmount();
		List<HireDetails> listHires = hireRepo.findAll(); 
		List<HireDetails> expHires = hireRepo.expiringHire();
		
		System.out.println(listHires);
		model.addAttribute("totalCustomers", totalCustomers);
		model.addAttribute("hiredVehicles", hiredVehicles);
		model.addAttribute("currentMonthlyAmount", currentMonthlyAmount);
		model.addAttribute("totalAnnualAmount", totalAnnualAmount);
		model.addAttribute("earningsChartData", lineChartData());
		model.addAttribute("vehiclesChartData", pieChartData());
		model.addAttribute("listHires", listHires);
		model.addAttribute("expHires", expHires);
		model.addAttribute("localDateTime", LocalDateTime.now());
		return "index";
	}
	
	public Map<String, Integer> lineChartData(){
		
		Map<String, Integer>chartData = new HashMap<>();
		List<Integer> monthlyTotal = invoiceRepo.monthlyTotal();
		List<String> allMonthsName = invoiceRepo.monthName();
		Integer eachMonthAmount = 0;
		String monthName;
		for (int i=0; i<monthlyTotal.size(); i++) {
			eachMonthAmount = monthlyTotal.get(i);
			monthName = allMonthsName.get(i);
			chartData.put(monthName, eachMonthAmount);
		}
		return chartData;
	}
	
	public Map<String, Integer> pieChartData(){
		
		Map<String, Integer>chartData = new HashMap<>();
		List<Integer> totalNoOfVehicles = vehRepo.getNoOfVehicles();
		List<String> vehicleStatus = vehRepo.getVehicleStatus();
		Integer noOfVehicles = 0;
		String status;
		for (int i=0; i<totalNoOfVehicles.size(); i++) {
			noOfVehicles = totalNoOfVehicles.get(i);
			status= vehicleStatus.get(i);
			chartData.put(status, noOfVehicles);
		}
		return chartData;
	}
}
