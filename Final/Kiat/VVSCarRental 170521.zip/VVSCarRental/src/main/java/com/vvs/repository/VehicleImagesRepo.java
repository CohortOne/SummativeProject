package com.vvs.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.vvs.model.VehicleImages;

public interface VehicleImagesRepo extends JpaRepository<VehicleImages, Long> {

	@Query("SELECT vi FROM VehicleImages vi inner join vi.vehicle WHERE vi.vehicle.id = :vehicleId")
	List<VehicleImages> findByVehicleId(@Param("vehicleId")Long vehicleId);

}
