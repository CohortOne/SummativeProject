package com.vvs.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class LoginController {

	@RequestMapping("/login")
    public String login() {
    	return "login";
    }
    
    @RequestMapping("/forgotpassword")
    public String forgotPassword(Model model) {
    	model.addAttribute("emailSent", "");
    	return "forgot-password";
    }
    
    @RequestMapping("/forgotpassword/email")
    public String forgotPasswordReset(@RequestParam("email")String email, RedirectAttributes ra) {
    	
    	ra.addFlashAttribute("message", "Reset Token has been sent. Please check your email.");    	
    	return "redirect:/forgotpassword";
    }
}
