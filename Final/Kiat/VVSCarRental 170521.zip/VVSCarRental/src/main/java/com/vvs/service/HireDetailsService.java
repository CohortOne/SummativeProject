package com.vvs.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.vvs.model.HireDetails;
import com.vvs.repository.HireDetailsRepo;

@Service
public class HireDetailsService {

	@Autowired
	private HireDetailsRepo hireDetRepo;
	
	public List<HireDetails> getAllHireDetails(){
		return hireDetRepo.findAll();
	}
	
	public void saveHireDetails(HireDetails hireDetails) {
		if(hireDetails.getEndDateTime()!=null) {
			hireDetails.setStatus("Completed");
		}else if(hireDetails.getEndDateTime()==null) {
			hireDetails.setStatus("Confirmed");
		}
		hireDetRepo.save(hireDetails);
	}
	
	public void deleteHireDetailsById(long hireDetId) {
		hireDetRepo.deleteById(hireDetId);
	}
	
	public HireDetails getHireDetailsById(long hireDetId) {
		
		Optional<HireDetails> optional = hireDetRepo.findById(hireDetId);
		HireDetails hireDetails = null;
		
		if(optional.isPresent())
			hireDetails = optional.get();
		else
			throw new RuntimeException("Hire Details not found for this is :: " + hireDetId);
		
		return hireDetails;
	}

	public Page<HireDetails> findPaginated(int pageNo, Integer pageSize, String keyword, String sortField,
			String sortDirection) {
		Sort sort= sortDirection.equalsIgnoreCase(Sort.Direction.ASC.name()) ? Sort.by(sortField).ascending()
				: Sort.by(sortField).descending();
		Pageable pageable = PageRequest.of(pageNo - 1, pageSize, sort);
		if(keyword !=null && keyword!="") {			
			return hireDetRepo.search(keyword, pageable);
		}		
		return hireDetRepo.findAll(pageable);		
	}

	public void cancelHireDetailsById(long hireDetailsId) {
		HireDetails currentHire = getHireDetailsById(hireDetailsId);
		currentHire.setStatus("Cancelled");
		hireDetRepo.save(currentHire);		
	}
}
