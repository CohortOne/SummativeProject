package com.vvs.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.vvs.model.HireDetails;

public interface HireDetailsRepo extends JpaRepository<HireDetails, Long> {
	
	@Query(value="SELECT hire_id, EXPECTED_END_DATE_TIME as difference from hire_details where (extract( day from (EXPECTED_END_DATE_TIME-CURRENT_DATE) )*24*60 +\r\n"
			+ "extract( hour from (EXPECTED_END_DATE_TIME-CURRENT_DATE) )*60 +\r\n"
			+ "extract( minute from (EXPECTED_END_DATE_TIME-CURRENT_DATE) ))<60 and END_DATE_TIME is null", nativeQuery=true)
	public List<HireDetails> expiringHire();

	@Query("SELECT h FROM HireDetails h inner join h.vehicle v inner join h.invoice i inner join h.customer c inner join h.userRent uRent inner join h.userReturn uReturn WHERE CONCAT(h.id, ' ', v.regNo, ' ', c.name, ' ', uRent.fullName, ' ', h.startDateTime, ' ', h.expectedEndDateTime, ' ', uReturn.fullName, ' ', h.endDateTime, ' ', i.id) LIKE %?1%")
	public Page<HireDetails> search(String keyword, Pageable pageable);
}
