package com.vvs.model;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonManagedReference;

@Entity
@Table(name="vehicles")
public class Vehicles implements Serializable{
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long vehicleId;
	private String regNo;
	@Enumerated(EnumType.STRING)
	private Brand brand;
	private String model;
	private long rentalRate;
	private String status;
	private String mainImg;
	@JsonManagedReference
	@OneToMany(mappedBy ="vehicle")	
	private Set<VehicleImages> vehImages = new HashSet<>();
	@OneToMany(mappedBy="vehicle")
	private Set<HireDetails> hireDetails = new HashSet<>();
	
	public long getVehicleId() {
		return vehicleId;
	}
	public void setVehicleId(long vehicleId) {
		this.vehicleId = vehicleId;
	}
	public String getRegNo() {
		return regNo;
	}
	public void setRegNo(String regNo) {
		this.regNo = regNo;
	}
	public Brand getBrand() {
		return brand;
	}
	public void setBrand(Brand brand) {
		this.brand = brand;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public long getRentalRate() {
		return rentalRate;
	}
	public void setRentalRate(long rentalRate) {
		this.rentalRate = rentalRate;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}	
	public String getMainImg() {
		return mainImg;
	}
	public void setMainImg(String mainImg) {
		this.mainImg = mainImg;
	}
	public Set<VehicleImages> getVehImages() {
		return vehImages;
	}
	public void setVehImages(Set<VehicleImages> vehImages) {
		this.vehImages = vehImages;
	}
	public Set<HireDetails> getHireDetails() {
		return hireDetails;
	}
	public void setHireDetails(Set<HireDetails> hireDetails) {
		this.hireDetails = hireDetails;
	}
	@Override
	public String toString() {
		return regNo;
	}
	
	

}
