package com.vvs.repository;

import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.vvs.model.Users;

public interface UserRepo extends JpaRepository<Users, Long> {

	@Query("SELECT u FROM Users u WHERE u.username = :username")
	public Users getUserByUserName(@Param("username")String username);

	@Query("SELECT u FROM Users u inner join u.userRoles r WHERE CONCAT(u.id, ' ', u.username, ' ', u.fullName, ' ', u.contactNo, ' ', u.email, ' ', u.jobTitle, ' ', u.address, ' ', r.name) LIKE %?1%")
	public Page<Users> search(String keyword, Pageable pageable);

	public Optional<Users> findByUsername(String username);
	
	@Modifying
	@Query("UPDATE Users SET profilePicture= :pic WHERE username= :username")
	public void changeProfilePic(@Param("username")String username, @Param("pic")byte[] profilePic);

	@Modifying
	@Query("UPDATE Users SET password= :password WHERE username= :username")
	public void savePasssword(@Param("password")String encodePw, @Param("username")String username);
}
