package com.vvs.service;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Set;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import com.vvs.model.UserRole;
import com.vvs.model.Users;

public class UserDetailImpl implements UserDetails {

	private Users users;
	private String fullName;
		
	public UserDetailImpl(Users users) {
		super();
		this.users = users;
	}

	@Override
	public Collection<? extends GrantedAuthority> getAuthorities() {
		Set<UserRole> userRoles = users.getUserRoles();
		List<SimpleGrantedAuthority> authorities = new ArrayList<>();
		
		for (UserRole userRole : userRoles) {
			authorities.add(new SimpleGrantedAuthority(userRole.getName()));
		}
		return authorities;		
	}

	@Override
	public String getPassword() {		
		return users.getPassword();
	}

	@Override
	public String getUsername() {		 
		return users.getUsername();
	}
	
	public String getFullName() {
		fullName = users.getFullName();
		return fullName;
	}

	@Override
	public boolean isAccountNonExpired() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean isAccountNonLocked() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean isCredentialsNonExpired() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean isEnabled() {
		// TODO Auto-generated method stub
		return true;
	}

}
