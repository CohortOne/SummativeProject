$(document).ready(function() {
	
	var cdate = new Date();
	var result, startDate;		

			var vehId = document.getElementById("vehicle").value;
			console.log("this is vehId " + vehId);
						
			$.ajax({
				type: "GET",
				url: "/loadDatesByCar/" + vehId,
				cache: false,
				timeout: 600000,
				success: function(data) {
					result = JSON.parse(data);
					var bookedDates = result;
					console.log(bookedDates);
					function my_check(in_date) {
						var day = '' + in_date.getDate(),
							month = '' + (in_date.getMonth() + 1),
							year = in_date.getFullYear();
						if (month.length < 2)
							month = '0' + month;
						if (day.length < 2)
							day = '0' + day;
						in_date = year + '-'
							+ month + '-'
							+ day;

						if (bookedDates.indexOf(in_date) >= 0) {
							return [false, "notav", 'Not Available'];
						} else {
							false
							return [true, "av", "available"];
						}

					}
					
					$(function() {																		
						$("#startpicker" + vehId).datetimepicker({							
							dateFormat: 'yy-mm-dd',
							numberOfMonths: 2,
							minDate: cdate,
							maxDate: 60,
							defaultDate: cdate,
							beforeShowDay: my_check,
							onSelect: function() {
								startDate = $(this).datetimepicker("getDate");
								$("#endpicker" + vehId).datetimepicker("destroy");
								$("#endpicker" + vehId).datetimepicker({
									dateFormat: 'yy-mm-dd',
									numberOfMonths: 2,
									minDate: startDate,
									maxDate: 60,
									defaultDate: cdate,
									beforeShowDay: my_check
								});
							}
						});
					});
				},
				error: function(e) {
					alert("this is an error. " + e.error);
				}
			});
			console.log("end of function");
			
		
	
	$(".start").click();




});