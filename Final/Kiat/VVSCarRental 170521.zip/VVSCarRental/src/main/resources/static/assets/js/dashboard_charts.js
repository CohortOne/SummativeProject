 
        
 
        $(document).ready(function() {
            google.charts.load('current', {
                packages : [ 'corechart' ]
            });			
            google.charts.setOnLoadCallback(drawLineChart);
            google.charts.setOnLoadCallback(drawPieChart);            
        });
 
        function drawLineChart() {
			  var month = new Array();
  			  month[1] = "January";
  			  month[2] = "February";
  			  month[3] = "March";
  			  month[4] = "April";
  			  month[5] = "May";
  		  	  month[6] = "June";
			  month[7] = "July";
  			  month[8] = "August";
  			  month[9] = "September";
  			  month[10] = "October";
  			  month[11] = "November";
  			  month[12] = "December";
            var data = new google.visualization.DataTable();
            data.addColumn('string', 'Month');
            data.addColumn('number', 'Sales');
            Object.keys(earnings_data).forEach(function(key) {
                data.addRow([ month[key], earnings_data[key] ]);
            });
            var options = {                
				curveType : 'function'
            };
            var chart = new google.visualization.LineChart(document
                    .getElementById('earnings_linechart'));
            chart.draw(data, options);
        }
 
        function drawPieChart() {
            var data = new google.visualization.DataTable();
            data.addColumn('string', 'Status');
            data.addColumn('number', 'Number of Vehicles');
            Object.keys(vehicles_data).forEach(function(key) {
                data.addRow([ key, vehicles_data[key] ]);
            });
            var options = {                
				pieHole: 0.5,
            };
            var chart = new google.visualization.PieChart(document
                    .getElementById('vehicle_piechart'));
            chart.draw(data, options);
        }