$(function(){
    $('#print').on('click', function(){
var restorepage = $('body').html();
var printcontent = $('#printContent').clone();
$('body').empty().html(printcontent);
window.print();
$('body').html(restorepage);
});
});

