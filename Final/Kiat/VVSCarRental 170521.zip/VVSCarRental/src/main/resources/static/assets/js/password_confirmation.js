var password = document.getElementById("newPw")
  , currPassword = document.getElementById("currentPw")
  , confirm_password = document.getElementById("confirm_password");

function validatePassword(){
  if(password.value != confirm_password.value) {	
    $('.mismatch').show();		
  }else {
    $('.mismatch').hide();
  }
}

function validateCurrAndNew(){
  if (currPassword.value == password.value){	  
	  $('#sameAsCurrent').show();	
  }else {
      $('#sameAsCurrent').hide();
  }
}
currPassword.onchange = validateCurrAndNew;
password.onkeyup = validateCurrAndNew;
password.onchange = validatePassword;
confirm_password.onkeyup = validatePassword;
