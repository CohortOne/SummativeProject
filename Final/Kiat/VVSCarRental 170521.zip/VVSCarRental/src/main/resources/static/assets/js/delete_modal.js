$(document).ready(function () {
	$("#dataTable #delete").on('click',function(event) {
		event.preventDefault();
        var href = $(this).attr("href");
        $("#deleteConfirm").modal("show");
			

var table = document.getElementById("dataTable"),rIndex,cIndex;

for(i=0; i<table.rows.length; i++)

	for (j=0;j<table.rows[i].cells.length; j++)
	{
		table.rows[i].cells[j].onclick = function()
		{
			rIndex = this.parentElement.rowIndex;			
			var entry = document.getElementById("entry");
			entry.innerHTML = table.rows[rIndex].cells[2].innerHTML+"?";

			
		}
	}

		$("#delRef").attr("href",href);
		$("#deleteConfirm").modal();
		
		
	});
	
	});