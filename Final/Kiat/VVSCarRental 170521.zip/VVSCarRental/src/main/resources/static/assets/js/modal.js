$("#modal").click(function(){
    $("#preview").modal("show");
});