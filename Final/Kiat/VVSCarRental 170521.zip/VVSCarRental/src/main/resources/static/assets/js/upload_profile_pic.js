$(document).ready(function() {
	$("#saveProfile").hide();
	$("#profilePicChange").click(function() {
    	$("#imageUpload").click();
		
	});

	function fasterPreview( uploader ) {
    	if ( uploader.files && uploader.files[0] ){
        	  $('#profileImage').attr('src', 
            	 window.URL.createObjectURL(uploader.files[0]) );
    	}
	}

	$("#imageUpload").change(function(){
    	fasterPreview( this );
		if ($(this).val()) {
			
      		$("#profilePicChange").hide();
			$("#saveProfile").show();
   		}
   		else {
      	$("#profilePicChange").show();
		$("#saveProfile").hide();
   		}
	});	


});