package com.vvs.controller;

import java.security.Principal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.google.gson.Gson;
import com.vvs.model.Customers;
import com.vvs.model.HireDetails;
import com.vvs.model.Users;
import com.vvs.model.Vehicles;
import com.vvs.repository.VehicleRepo;
import com.vvs.service.CustomerService;
import com.vvs.service.HireDetailsService;
import com.vvs.service.UserService;
import com.vvs.service.VehicleService;

@Controller
public class HireDetailsController {
	
	@Autowired
	private HireDetailsService hireService;
	
	@Autowired
	private CustomerService custService;
	
	@Autowired
	private VehicleService vehService;
	
	@Autowired
	private UserService userService;
	
	@Autowired
	private VehicleRepo vehRepo;
	
	@RequestMapping("/hireDetails")
	public String viewHireDetailsPage(Model model, @Param("pageSize")Integer pageSize, @Param("keyword")String keyword) {		
		return hiresPagination(1, pageSize, "hireDetailsId", "DESC", model, keyword);
	}
	
	@GetMapping("/hireDetails/{pageNo}")
	private String hiresPagination(@PathVariable(value="pageNo")int pageNo,
									   @Param("pageSize")Integer pageSize,
									   @Param("sortField") String sortField,
									   @Param("sortDirection")String sortDirection,
									   Model model,
									   @Param("keyword") String keyword) {
		if (pageSize == null)
			pageSize = 5;
		Page<HireDetails> page = hireService.findPaginated(pageNo, pageSize, keyword, sortField, sortDirection);
		List<HireDetails> listHireDetails = page.getContent().stream()
										 .distinct()
										 .collect(Collectors.toList());
		
		model.addAttribute("listHireDetails", listHireDetails);
		model.addAttribute("pageSize", pageSize);
		model.addAttribute("totalPages", page.getTotalPages());
		model.addAttribute("totalItems", page.getTotalElements());
		model.addAttribute("currentItems", page.getNumberOfElements());
		model.addAttribute("currentPage", pageNo);
		model.addAttribute("sortField", sortField);
		model.addAttribute("sortDirection", sortDirection);
		model.addAttribute("reverseSortDir", sortDirection.equalsIgnoreCase("ASC") ? "DESC" : "ASC");
		model.addAttribute("keyword", keyword);	
		model.addAttribute("urlLink", "hireDetails");
		return "hire_details";
	}

	@GetMapping("/newHire/{custId}/{vehId}")
	public String newHireForm(Model model, @PathVariable(value="custId")long custId, @PathVariable(value="vehId")long vehId, 
			Principal principal, String startDate, String expectedEndDate) {
		HireDetails hireDetails = new HireDetails();
		Customers customer = custService.getCustomerById(custId);		
		Vehicles vehicle = vehService.getVehicleById(vehId);		
		vehService.updateStatus("Hold", vehId);
		Users user = userService.getUserByUsername(principal.getName());		
		model.addAttribute("update", false);
		model.addAttribute("amend", false);
		model.addAttribute("customer",customer);
		model.addAttribute("vehicle", vehicle);
		model.addAttribute("hireDetails", hireDetails);
		model.addAttribute("user", user);
		model.addAttribute("startDate", startDate);
		model.addAttribute("expectedEndDate", expectedEndDate);
		return "hiredetails_form";
	}
	
	@PostMapping("/saveHireDetails/")
	public String saveNewHireDetails(@Valid @ModelAttribute("hireDetails")HireDetails hireDetails, RedirectAttributes ra,
									 BindingResult bindingResult, @RequestParam(value = "vehId")long vehId, 
									 @Param("startDate")String startDate, @Param("expectedEndDate")String expectedEndDate) {
		if(bindingResult.hasErrors())
			return "hiredetails_form";
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
		LocalDateTime startDateTime = LocalDateTime.parse(startDate, formatter);
		LocalDateTime expectedEndDateTime = LocalDateTime.parse(expectedEndDate, formatter);
		hireDetails.setStartDateTime(startDateTime);
		hireDetails.setExpectedEndDateTime(expectedEndDateTime);
		hireService.saveHireDetails(hireDetails);
		Vehicles vehicle = vehService.getVehicleById(vehId);
		String vehStatus = vehicle.getStatus();
		if (startDateTime.isBefore(LocalDateTime.now()))
			vehService.updateStatus("Hired", vehId);
		else{
			vehService.updateStatus("Available", vehId);
		}
			
		ra.addFlashAttribute("message", "The Entry has been saved successfully!");
		return "redirect:/hireDetails";
	}
	
	@GetMapping("/returnHire/{hireId}")
	public String returnHireForm(Model model, @PathVariable(value="hireId")long hireId, Principal principal) {
		HireDetails hireDetails = hireService.getHireDetailsById(hireId);
		Users user = userService.getUserByUsername(principal.getName());
//		System.out.println(hireDetails.getUserRent().getFullName());
		model.addAttribute("hireDetails", hireDetails);
		model.addAttribute("user", user);
		model.addAttribute("update", true);
		model.addAttribute("amend", false);
		return "hiredetails_form";
	}
	
	@GetMapping("/amendHire/{hireId}")
	public String amendHireForm(Model model, @PathVariable(value="hireId")long hireId, Principal principal) {
		HireDetails hireDetails = hireService.getHireDetailsById(hireId);
		Users user = userService.getUserByUsername(principal.getName());		
		model.addAttribute("hireDetails", hireDetails);
		model.addAttribute("user", user);
		model.addAttribute("update", true);
		model.addAttribute("amend", true);
		return "hiredetails_form";
	}
	
	@GetMapping("/cancelNewHire/{vehId}")
	public String cancelCurrentHire(@PathVariable(value="vehId")long vehId, RedirectAttributes ra) {
		Vehicles vehicle = vehService.getVehicleById(vehId);
		if (vehicle.getStatus().equals("Hold"))
			vehService.updateStatus("Available", vehId);
		ra.addFlashAttribute("message", "Transaction has been cancelled.");
		return "redirect:/hireDetails";
	}
	
	@GetMapping("/cancelHireDetails/")
	public String cancelSelectedHire(@RequestParam(value="id")long hireDetailsId, RedirectAttributes ra) {		
		hireService.cancelHireDetailsById(hireDetailsId);
		ra.addFlashAttribute("message", "The Booking has been cancelled.");
		return "redirect:/hireDetails";
	}
	
	@GetMapping("/deleteHireDetails/")
	public String deleteSelectedHire(@RequestParam(value="id")long hireDetailsId, RedirectAttributes ra) {		
		hireService.cancelHireDetailsById(hireDetailsId);
		ra.addFlashAttribute("message", "The Booking has been cancelled.");
		return "redirect:/hireDetails";
	}
	
	@RequestMapping(value = "/loadDatesByCar/{vehId}", method = RequestMethod.GET)
	@ResponseBody
	public String loadDatesByCar(@PathVariable("vehId") Long vehId) {
		LocalDate[] startDates = vehRepo.getStartDates(vehId);		
		for (LocalDate date:startDates) {
			System.out.println(vehId + "in loaddatebycar" + date);
		}
		LocalDate[] endDates = vehRepo.getEndDates(vehId);
		
		List<String> blockDates = new ArrayList<String>(); 
		for(int i=0;i<startDates.length;i++) {
			LocalDate start = startDates[i];
			
			while(!start.equals(endDates[i]) && !blockDates.contains(start.toString())) { //remove start.isAfter
				blockDates.add(start.toString());
				start = start.plusDays(1);
			}
			if(!blockDates.contains(endDates[i].toString()) && endDates[i].isAfter(LocalDate.now())) {
				blockDates.add(endDates[i].toString());
			}			
		}
		Gson gson = new Gson();
		return gson.toJson(blockDates);
	}
}
