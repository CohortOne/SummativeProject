package com.vvs.model;

public enum Brand {
	Select,
	All,
	Toyota,
	Honda,
	Hyundai;

}
