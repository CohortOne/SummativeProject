package com.vvs.service;

import java.io.IOException;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import com.vvs.error.UserAlreadyExistException;
import com.vvs.model.Users;
import com.vvs.repository.UserRepo;
import com.vvs.repository.UserRoleRepo;

@Service
public class UserService {

	@Autowired
	private UserRepo userRepo;
			
	@Autowired
	public UserService(UserRepo userRepo) {
		this.userRepo = userRepo;
	}	
	
	public String saveNewUser(Users user) {
		
		if (userRepo.findByUsername(user.getUsername()).isPresent()) {
			System.out.println(userRepo.findByUsername(user.getUsername()));
			//throw new UserAlreadyExistException(" Account exist with that username: " + user.getUsername());
			return "Failure";
		}else {
			user.setEnabled(true);
			//default password for all users
			user.setPassword("password123");
			userRepo.save(user);
			return "Success";
		}
	}
	
	public void saveUser(Users user) {
		//user.setEnabled(true);		
			
		userRepo.save(user);
	}		
	
	@Transactional
	public void saveProfilePic(Users user, MultipartFile multipartFile) throws IOException {
		//user.setProfilePicture(multipartFile.getBytes());
		byte[] newProfilePic = multipartFile.getBytes();
		String username = user.getUsername();
		userRepo.changeProfilePic(username, newProfilePic);
	}
	
	public void deleteUserById(long userId) {
		userRepo.deleteById(userId);
	}
	
	public Users getUserById(long userId) {
		Optional<Users> optional = userRepo.findById(userId);
		Users user = null;
		
		if (optional.isPresent())
			user = optional.get();
		else
			throw new RuntimeException("User not found for id :: " + userId);
		return user;
	}

	public Page<Users> findPageinated(int pageNo, int pageSize, String keyword, String sortField,
			String sortDirection) {
		Sort sort= sortDirection.equalsIgnoreCase(Sort.Direction.ASC.name()) ? Sort.by(sortField).ascending()
				: Sort.by(sortField).descending();
		Pageable pageable = PageRequest.of(pageNo - 1, pageSize, sort);
		if (keyword !=null && keyword!="") {
			return userRepo.search(keyword, pageable);
		}
		return userRepo.findAll(pageable);
	}

	public Users getUserByUsername(String username) {
		Optional<Users> optional = userRepo.findByUsername(username);
		Users user = null;
//		System.out.println(optional);
		if (optional.isPresent())
			user = optional.get();
		else
			throw new RuntimeException("User not found for username :: " + username);
		System.out.println(user + " in service");
		return user;
	}

	@Transactional
	public boolean saveNewPassword(String currentPassword, String newPassword, String username) {
				
		BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
		Users user = getUserByUsername(username);
		if (passwordEncoder.matches(currentPassword, user.getPassword())) {
			String encodePw = passwordEncoder.encode(newPassword);			
			userRepo.savePasssword(encodePw, username);
			return true;
		}else {
			return false;			
		}		
	}
}
