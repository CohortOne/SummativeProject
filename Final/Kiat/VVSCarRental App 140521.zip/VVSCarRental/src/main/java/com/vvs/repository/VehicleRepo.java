package com.vvs.repository;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.vvs.model.Vehicles;

public interface VehicleRepo extends JpaRepository<Vehicles, Long> {
	
	@Modifying
	@Query("UPDATE Vehicles SET status= :status WHERE vehicleId= :vehId")
	public void updateVehicleStatus(@Param("status")String status, @Param("vehId")long vehId);
	
	@Query("SELECT count(v) from Vehicles v WHERE v.status='Hired'")
	public long hiredVehiclesCount();

	@Query(value = "SELECT count(*) from Vehicles GROUP BY status", nativeQuery = true)
	public List<Integer> getNoOfVehicles();

	@Query(value = "SELECT status from Vehicles GROUP BY status", nativeQuery = true)
	public List<String> getVehicleStatus();

	@Query("SELECT v FROM Vehicles v WHERE CONCAT(v.id, ' ', lower(v.brand), ' ', v.regNo, ' ', lower(v.model), ' ', v.rentalRate) LIKE %?1%")
	public Page<Vehicles> search(String keyword, Pageable pageable);
	
	@Query("SELECT v FROM Vehicles v WHERE v.status= :status")
	public Page<Vehicles> displayWithStatus(@Param("status")String status, Pageable pageable);

	@Query("SELECT v FROM Vehicles v WHERE v.status= :status AND CONCAT(v.id, ' ', lower(v.brand), ' ', v.regNo, ' ', lower(v.model), ' ', v.rentalRate) LIKE %:keyword%")
	public Page<Vehicles> searchWithStatus(@Param("status")String status, @Param("keyword")String keyword, Pageable pageable);
	
	@Query("SELECT h.startDateTime FROM Vehicles v inner join v.hireDetails h WHERE v.vehicleId = :vehId and h.status = 'Confirmed'")
	public LocalDate[] getStartDates(Long vehId);

	@Query("SELECT h.expectedEndDateTime FROM Vehicles v inner join v.hireDetails h WHERE v.vehicleId = :vehId and h.status = 'Confirmed'")
	public LocalDate[] getEndDates(Long vehId);

}
