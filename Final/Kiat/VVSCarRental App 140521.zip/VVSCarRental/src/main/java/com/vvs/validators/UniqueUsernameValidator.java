package com.vvs.validators;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.vvs.annotations.UniqueUsername;
import com.vvs.service.UserDetailService;

@Component
public class UniqueUsernameValidator implements ConstraintValidator<UniqueUsername, String> {

	@Autowired
	private UserDetailService userDetailService;
	
	@Override
	public void initialize(UniqueUsername constraintAnnotation) {		
	}
	
	@Override
	public boolean isValid(String username, ConstraintValidatorContext context) {
		return username != null && !userDetailService.isUsernameAlreadyInUse(username);
	}
}
