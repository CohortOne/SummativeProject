package com.vvs.model;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name = "invoices")
@SequenceGenerator(name = "invoice_id_seq", initialValue = 10000, allocationSize = 1)
public class Invoices implements Serializable {

	@Id	
	@GeneratedValue (strategy = GenerationType.IDENTITY)
	@Column(name = "invoice_id")
	private long invoiceId;
	private double totalAmount;
	private double amountBeforeGST;
	private double lateFees;
	@DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
	private LocalDateTime issueDate;
	private String status;
	@OneToOne
	@JoinTable(name = "invoice_hire_details",
	   joinColumns = @JoinColumn(name = "invoice_id"),
	   inverseJoinColumns = @JoinColumn(name = "hire_id"))
	private HireDetails hireDetails;
	@ManyToOne
	@JoinTable (name = "cust_invoices",
				joinColumns = @JoinColumn(name = "invoice_id"))
	private Customers customer;	
	
	public long getInvoiceId() {
		return invoiceId;
	}
	public void setInvoiceId(long invoiceId) {
		this.invoiceId = invoiceId;
	}
	public double getTotalAmount() {
		return totalAmount;
	}
	public void setTotalAmount(double totalAmount) {
		this.totalAmount = totalAmount;
	}
	public double getAmountBeforeGST() {
		return amountBeforeGST;
	}
	public void setAmountBeforeGST(double amountBeforeGST) {
		this.amountBeforeGST = amountBeforeGST;
	}
	public double getLateFees() {
		return lateFees;
	}
	public void setLateFees(double lateFees) {
		this.lateFees = lateFees;
	}
	public LocalDateTime getIssueDate() {
		return issueDate;
	}
	public void setIssueDate(LocalDateTime issueDate) {
		this.issueDate = issueDate;
	}	
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}	
	public HireDetails getHireDetails() {
		return hireDetails;
	}
	public void setHireDetails(HireDetails hireDetails) {
		this.hireDetails = hireDetails;
	}
	public Customers getCustomer() {
		return customer;
	}
	public void setCustomer(Customers customer) {
		this.customer = customer;
	}
	@Override
	public String toString() {
		return String.valueOf(invoiceId);
	}	
	
}
