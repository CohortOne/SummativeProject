package com.vvs.controller;

import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.stream.Collectors;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.vvs.model.HireDetails;
import com.vvs.model.Invoices;
import com.vvs.service.HireDetailsService;
import com.vvs.service.InvoiceService;

@Controller
public class InvoiceController {
	
	@Autowired
	private InvoiceService invoiceService;
	
	@Autowired
	private HireDetailsService hireService;
	
	@RequestMapping("/invoices")
	public String viewInvoicesPage(Model model, @Param("pageSize")Integer pageSize, @Param("keyword")String keyword, @Param("status")String status) {
		return invoicePaginated(1, pageSize, "invoiceId", "ASC", model, keyword, status);
	}
	
	@RequestMapping("/invoices/{pageNo}")
	private String invoicePaginated(@PathVariable(value="pageNo")int pageNo,
			   @Param("pageSize")Integer pageSize,
			   @Param("sortField") String sortField,
			   @Param("sortDirection")String sortDirection,
			   Model model,
			   @Param("keyword") String keyword,
			   @Param("status")String status) {
		//default page size
		if(pageSize==null)
			pageSize=5;
		Page<Invoices> page = invoiceService.findPaginated(pageNo, pageSize, keyword, sortField, sortDirection,status);
		List<Invoices> listInvoices = page.getContent().stream()
									  .distinct()
									  .collect(Collectors.toList());
		
		model.addAttribute("listInvoices", listInvoices);
		model.addAttribute("pageSize", pageSize);
		model.addAttribute("totalPages", page.getTotalPages());
		model.addAttribute("totalItems", page.getTotalElements());
		model.addAttribute("currentItems", page.getNumberOfElements());
		model.addAttribute("currentPage", pageNo);
		model.addAttribute("sortField", sortField);
		model.addAttribute("sortDirection", sortDirection);
		model.addAttribute("reverseSortDir", sortDirection.equalsIgnoreCase("ASC") ? "DESC" : "ASC");
		model.addAttribute("keyword", keyword);
		model.addAttribute("status", status);
		model.addAttribute("urlLink", "invoices");
		
		return "invoice_details";
	}
	
	@GetMapping("/newInvoice/")
	public String newInvoiceForm(Model model, @RequestParam(value="hireId")long hireId) {
		Invoices invoice = new Invoices();
		HireDetails hireDetails = hireService.getHireDetailsById(hireId);
		long invoiceAmount = invoiceService.getInvoiceAmount(hireDetails);
		long lateFees = invoiceService.getLateFees(hireDetails);
		double totalAmount = invoiceAmount + lateFees;		
		double totalAmountGST = invoiceService.invoiceAmountGST(totalAmount);
		model.addAttribute("update", false);
		model.addAttribute("invoice", invoice);
		model.addAttribute("amountNoGST", invoiceAmount);
		model.addAttribute("lateFees", lateFees);
		model.addAttribute("amountGST", totalAmountGST);
		model.addAttribute("hire", hireDetails);
		model.addAttribute("hireId", hireId);		
		return "invoice_form";
	}
	
	@PostMapping("/saveInvoice")
	public String saveInvoice(@Valid @ModelAttribute("invoice")Invoices invoice, RedirectAttributes ra,
							  BindingResult bindingResult) {
		if (bindingResult.hasErrors())
			return "invoice_form";
		invoiceService.saveInvoice(invoice);		
		ra.addFlashAttribute("message", "The Invoice has been saved!");
		return "redirect:/invoices";
		
	}
	
	@GetMapping("/updateInvoice/")
	public String updateInvoice(@RequestParam(value="invoiceId")long invoiceId, Model model) {
		Invoices invoice = invoiceService.getInvoiceById(invoiceId);
		model.addAttribute("invoice", invoice);
		model.addAttribute("update", true);
		return "invoice_form";
	}
	
	@GetMapping("/deleteInvoice/")
	public String deleteInvoice(@RequestParam(value="invoiceId")long invoiceId, RedirectAttributes ra) {
		invoiceService.deleteInvoiceById(invoiceId);
		ra.addFlashAttribute("message", "The Invoice has been deleted.");
		return "redirect:/invoices";
	}
	
	@RequestMapping("/viewInvoice/")
	public String viewInvoice(@RequestParam(value="invoiceId")long invoiceId, Model model) {
		Invoices invoice = invoiceService.getInvoiceById(invoiceId);
		long lateDuration = ChronoUnit.MINUTES.between(invoice.getHireDetails().getExpectedEndDateTime(), invoice.getHireDetails().getEndDateTime());
		model.addAttribute("lateDuration", lateDuration);
		model.addAttribute("invoice", invoice);
		return "invoice_page";
	}

}
