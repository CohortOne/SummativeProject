package com.vvs.controller;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.data.domain.Page;
import org.springframework.data.repository.query.Param;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.util.StringUtils;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.vvs.model.VehicleIdForImages;
import com.vvs.model.VehicleImages;
import com.vvs.model.Vehicles;
import com.vvs.service.VehicleService;

@Controller
public class VehicleController {
	
	@Autowired
	private VehicleService vehService;
	
	private String accessToken="6bdd00ddf3d4ef3c7c6139c6543d91529c18992e";
	
	private String uri = "https://api.imgur.com/3/image";
		
	@RequestMapping("/vehicles")
	public String viewVehiclePage(Model model, @Param("pageSize")Integer pageSize, @Param("keyword")String keyword, @Param("status")String status) {		
		return vehiclePagination(1, pageSize, "vehicleId", "ASC", model, keyword, "");				
	}
	
	@GetMapping("/vehicles/{pageNo}")
	private String vehiclePagination(@PathVariable(value="pageNo")int pageNo,
									   @Param("pageSize")Integer pageSize,
									   @Param("sortField") String sortField,
									   @Param("sortDirection")String sortDirection,
									   Model model,
									   @Param("keyword") String keyword,
									   @Param("status")String status) {
		
		if (pageSize == null)
			pageSize = 5;
		Page<Vehicles> page = vehService.findPaginated(pageNo, pageSize, keyword, sortField, sortDirection, status);
		List<Vehicles> listVehicles = page.getContent().stream()
									  .distinct()
									  .collect(Collectors.toList());		
		model.addAttribute("listVehicles", listVehicles);
		model.addAttribute("pageSize", pageSize);
		model.addAttribute("totalPages", page.getTotalPages());
		model.addAttribute("totalItems", page.getTotalElements());
		model.addAttribute("currentItems", page.getNumberOfElements());
		model.addAttribute("currentPage", pageNo);
		model.addAttribute("sortField", sortField);
		model.addAttribute("sortDirection", sortDirection);
		model.addAttribute("reverseSortDir", sortDirection.equalsIgnoreCase("ASC") ? "DESC" : "ASC");
		model.addAttribute("keyword", keyword);
		model.addAttribute("status", status);
		model.addAttribute("urlLink", "vehicles");
		
		return "vehicles";
	}
	
	@GetMapping("/booking/{custId}")
	public String viewVehiclePageWithCust(Model model, @PathVariable(value="custId")long custId, @Param("pageSize")Integer pageSize, @Param("keyword")String keyword) {		
		return bookingPagination(1, custId, pageSize, "vehicleId", "ASC", model, keyword, "Available");				
	}
	
	@GetMapping("/booking/{custId}/{pageNo}")
	private String bookingPagination(@PathVariable(value="pageNo")int pageNo,
									 @PathVariable(value="custId")long custId,
									   @Param("pageSize")Integer pageSize,
									   @Param("sortField") String sortField,
									   @Param("sortDirection")String sortDirection,
									   Model model,
									   @Param("keyword") String keyword,
									   @Param("status")String status) {
		
		if (pageSize == null)
			pageSize = 5;
		status="Available";
		Page<Vehicles> page = vehService.findPaginated(pageNo, pageSize, keyword, sortField, sortDirection, status);
		List<Vehicles> listVehicles = page.getContent().stream()
									  .distinct()
									  .collect(Collectors.toList());		
		model.addAttribute("listVehicles", listVehicles);
		model.addAttribute("pageSize", pageSize);
		model.addAttribute("totalPages", page.getTotalPages());
		model.addAttribute("totalItems", page.getTotalElements());
		model.addAttribute("currentItems", page.getNumberOfElements());
		model.addAttribute("currentPage", pageNo);
		model.addAttribute("sortField", sortField);
		model.addAttribute("sortDirection", sortDirection);
		model.addAttribute("reverseSortDir", sortDirection.equalsIgnoreCase("ASC") ? "DESC" : "ASC");
		model.addAttribute("keyword", keyword);
		model.addAttribute("status", status);
		model.addAttribute("custId", custId);
		model.addAttribute("urlLink", "booking/"+custId);
		
		
		return "vehicles";
	}
	
	@GetMapping("/newVehicle")
	public String newVehicleForm(Model model) {
		Vehicles vehicle = new Vehicles();
		model.addAttribute("vehicle", vehicle);
		model.addAttribute("update", false);
		return "vehicle_form";	
	}
	
	@PostMapping("/saveVehicle")
	public String saveVehicle(@Valid @ModelAttribute("vehicle")Vehicles vehicle, RedirectAttributes ra, BindingResult bindingResult) {
		if (bindingResult.hasErrors())
			return "vehicle_form";
		vehService.saveVehicle(vehicle);
		ra.addFlashAttribute("message", "The Entry has been saved successfully!");
		return "redirect:/vehicles";		
	}
	
	@GetMapping("/updateVehicle/{id}")
	public String updateVehicleForm(@PathVariable(value="id")long vehId, Model model) {
		Vehicles vehicle = vehService.getVehicleById(vehId);
		List<VehicleImages> vehImgs = vehService.getAllVehicleImagesById(vehId);
		model.addAttribute("vehicle", vehicle);
		model.addAttribute("vehImages", vehImgs);
		model.addAttribute("update", true);
		return "vehicle_form";
	}
	
	@GetMapping("/deleteVehicle/{id}")
	public String deleteVehicle(@PathVariable(value="id")long vehId, RedirectAttributes ra) {
		vehService.deleteVehicleById(vehId);
		ra.addFlashAttribute("message", "The Entry has been deleted");
		return "redirect:/vehicles";
	}
	
	@GetMapping("/uploadImages/{id}")
	public String uploadImagesForm(@PathVariable(value="id")long vehId, Model model) {
		Vehicles vehicle = vehService.getVehicleById(vehId);
		List<VehicleImages> vehImg = vehService.getAllVehicleImagesById(vehId);
		
		model.addAttribute("vehImg", vehImg);
		model.addAttribute("vehicle", vehicle);
		
		return "vehicle_images_upload";
	}
	
	@PostMapping("/saveUpload")
	public String saveUploads(@ModelAttribute("vehImg")VehicleImages vehImg, RedirectAttributes ra, @RequestParam("vehicleImage")MultipartFile multipartFile) throws IOException {
		
//		Local Storage
//		String imageName = StringUtils.cleanPath(multipartFile.getOriginalFilename());
//		vehImg.setName(imageName);
//		Long vehId = vehImg.getVehicle().getVehicleId();
//		
//		VehicleImages savedImage = vehService.saveUploads(vehImg);		
//		String uploadDir ="./vehicle-images/" + savedImage.getVehImgId();		
//		Path uploadPath = Paths.get(uploadDir);
//		
//		if(!Files.exists(uploadPath)) {
//			Files.createDirectories(uploadPath);
//		}
//		
//		try (InputStream inputStream = multipartFile.getInputStream()){
//			Path filePath = uploadPath.resolve(imageName);
//			Files.copy(inputStream, filePath, StandardCopyOption.REPLACE_EXISTING);			
//		}catch (IOException e) {
//			throw new IOException("Could not save uploaded image: " + imageName);
//		}
		
//		String clientId="c1b2a1146a74d6d";
		
		MultiValueMap<String, Object> bodyMap = new LinkedMultiValueMap<>();
		bodyMap.add("image", getUserFileResource(multipartFile.getBytes()));
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.MULTIPART_FORM_DATA);
		headers.add("Authorization", "Bearer " + accessToken);
		HttpEntity<MultiValueMap<String, Object>> requestEntity = new HttpEntity<>(bodyMap, headers);

		RestTemplate restTemplate = new RestTemplate();		
		ResponseEntity<VehicleImages> response = restTemplate.exchange(uri, HttpMethod.POST, requestEntity, VehicleImages.class);
		System.out.println("response status: " + response.getStatusCode()); // it should return 200		 
		System.out.println("response body: " + response.getBody().getData().getLink()); // it should return link of your uploaded image
		
		String imageName = StringUtils.cleanPath(multipartFile.getOriginalFilename());
		vehImg.setName(imageName);
		vehImg.setHrefLink(response.getBody().getData().getLink());
		Long vehId = vehImg.getVehicle().getVehicleId();
		vehService.saveUploads(vehImg);
		
		ra.addFlashAttribute("message", "The Image has been uploaded successfully!");
		
		return "redirect:/uploadImages/" + vehId;		
	}
	
	public static Resource getUserFileResource(byte[] bytes) throws IOException {
		return new ByteArrayResource(bytes);
	}
	
	@RequestMapping(method = {RequestMethod.DELETE, RequestMethod.GET}, value ="/deleteImage/{id}")
	public String deleteImage(@PathVariable(value="id")Long vehImgId, Model model, RedirectAttributes ra) throws IOException {
		
		Long vehId = vehService.getVehicleFromImgById(vehImgId).getVehicle().getVehicleId();

//		Local Storage
//		String deleteDir ="./vehicle-images/" + vehImgId;
//		Path deletePath = Paths.get(deleteDir);
//		Files.walk(deletePath)
//			 .sorted(Comparator.reverseOrder())
//			 .map(Path::toFile)
//			 .forEach(File::delete);

		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.MULTIPART_FORM_DATA);
		headers.add("Authorization", "Bearer " + accessToken);
		HttpEntity<MultiValueMap<String, Object>> requestEntity = new HttpEntity<>(headers);
		String hrefLink = vehService.getVehicleFromImgById(vehImgId).getHrefLink();
		String imageId = hrefLink.substring(hrefLink.lastIndexOf('/'), hrefLink.lastIndexOf('.'));
		System.out.println(imageId);
		RestTemplate restTemplate = new RestTemplate();		
		ResponseEntity<VehicleImages> response = restTemplate.exchange(uri+imageId, HttpMethod.DELETE, requestEntity, VehicleImages.class);
		System.out.println("response status: " + response.getStatusCode()); // it should return 200		 
		System.out.println("response success: " + response.getBody().getSuccess()); // it should return link of your uploaded image
		
		
		vehService.deleteUpload(vehImgId);
		
		return "redirect:/uploadImages/" + vehId;
	}
	
	@RequestMapping(value = "/loadVehicleImages", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	 public @ResponseBody List<VehicleImages> loadImagesByVehicles(@RequestBody VehicleIdForImages vehicleIdForImages) {
	  List<VehicleImages> vehImgs = vehService.getAllVehicleImagesById(vehicleIdForImages.getVehicleId());
	  
	  return vehImgs;
	 }

}
