package com.vvs.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.vvs.model.UserRole;

public interface UserRoleRepo extends JpaRepository<UserRole, Integer> {
	UserRoleRepo findByName(String name);
}
