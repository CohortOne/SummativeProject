package com.vvs.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.vvs.model.Customers;

public interface CustomerRepo extends JpaRepository<Customers, Long> {

	@Query("SELECT c FROM Customers c WHERE CONCAT(c.id, ' ', c.nric, ' ', c.name, ' ', c.contactNo, ' ', c.address) LIKE %?1%")
	Page<Customers> search(String keyword, Pageable pageable);

}
