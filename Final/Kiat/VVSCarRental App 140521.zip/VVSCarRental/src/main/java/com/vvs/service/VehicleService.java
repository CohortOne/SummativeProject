package com.vvs.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.vvs.model.VehicleImages;
import com.vvs.model.Vehicles;
import com.vvs.repository.VehicleImagesRepo;
import com.vvs.repository.VehicleRepo;

@Service
public class VehicleService {
	
	@Autowired
	private VehicleRepo vehRepo;
	
	@Autowired
	private VehicleImagesRepo vehImgRepo;
	
	@Autowired
	public VehicleService(VehicleRepo vehRepo) {
		this.vehRepo = vehRepo;
	}

	public List<Vehicles> getAllVehicles(){
		return vehRepo.findAll();
	}
	
	public void saveVehicle(Vehicles vehicle) {
		vehRepo.save(vehicle);
	}
	
	public void deleteVehicleById(long vehicleId) {
		vehRepo.deleteById(vehicleId);
	}
	
	public Vehicles getVehicleById(long vehicleId) {
		
		Optional<Vehicles> optional = vehRepo.findById(vehicleId);
		Vehicles vehicle = null;
		
		if(optional.isPresent())
			vehicle = optional.get();
		else
			throw new RuntimeException("Vehicle is not found in data base :: " + vehicleId);
		
		return vehicle;
	}
	
	@Transactional
	public void updateStatus(String status, long vehId) {
		vehRepo.updateVehicleStatus(status, vehId);
	}

	public Page<Vehicles> findPaginated(int pageNo, Integer pageSize, String keyword, String sortField,
			String sortDirection, String status) {
		Sort sort= sortDirection.equalsIgnoreCase(Sort.Direction.ASC.name()) ? Sort.by(sortField).ascending()
				: Sort.by(sortField).descending();
		Pageable pageable = PageRequest.of(pageNo - 1, pageSize, sort);
		System.out.println("status is " + status);
		System.out.println("keyword is " + keyword);
		if (keyword !=null && status==null || keyword!=null && status=="") {
			System.out.println("test1");
			return vehRepo.search(keyword.toLowerCase(), pageable);
		}else if(status!="" && keyword==null) {
			System.out.println("test2");
			return vehRepo.displayWithStatus(status, pageable);
		}else if(keyword!=null && status!="") {
			System.out.println("test3");
			return vehRepo.searchWithStatus(status, keyword.toLowerCase(), pageable);
		}
		System.out.println("test4");
		return vehRepo.findAll(pageable);		
	}
	
	public List<VehicleImages> getAllVehicleImagesById(long vehicleId) {
		
		return vehImgRepo.findByVehicleId(vehicleId);		
	}

	public VehicleImages saveUploads(@Valid VehicleImages vehImg) {
		
		return vehImgRepo.save(vehImg);
	}
	
	public void deleteUpload(Long vehImgId) {
		vehImgRepo.deleteById(vehImgId);
	}
	
	public VehicleImages getVehicleFromImgById(Long vehImgId) {
		
		Optional<VehicleImages> optional = vehImgRepo.findById(vehImgId);
		VehicleImages vehImg = null;
		
		if(optional.isPresent())
			vehImg = optional.get();
		else
			throw new RuntimeException("Image ID is not found in data base :: " + vehImgId);
		
		return vehImg;
	}
}
