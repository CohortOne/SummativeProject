$(document).ready(function () {
	$("#dataTable #nricImg").on('click',function(event) {
		$("#modalNRIC").modal("show");

var table = document.getElementById("dataTable"),rIndex,cIndex;

for(i=0; i<table.rows.length; i++)

	for (j=0;j<table.rows[i].cells.length; j++)
	{
		table.rows[i].cells[j].onclick = function()
		{
			rIndex = this.parentElement.rowIndex;			
			var nric = document.getElementById("nric");
			nric.innerHTML = "NRIC Image of " + table.rows[rIndex].cells[1].innerHTML;
			var displayNric = document.getElementById("displayNric");
			displayNric.src = "nric/" + table.rows[rIndex].cells[0].innerHTML;
//			var text = "nric/" + table.rows[rIndex].cells[0].innerHTML;
//			$("#displayNric").attr("src", text);
			
		}
	}
	
	
});
});