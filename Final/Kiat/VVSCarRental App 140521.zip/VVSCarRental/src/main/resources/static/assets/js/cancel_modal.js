$(document).ready(function () {
	$("#dataTable #cancel").on('click',function(event) {
		event.preventDefault();
        var href = $(this).attr("href");
        $("#cancelConfirm").modal("show");
			

var table = document.getElementById("dataTable"),rIndex,cIndex;

for(i=0; i<table.rows.length; i++)

	for (j=0;j<table.rows[i].cells.length; j++)
	{
		table.rows[i].cells[j].onclick = function()
		{
			rIndex = this.parentElement.rowIndex;			
			var entry = document.getElementById("entryCancel");
			entry.innerHTML = table.rows[rIndex].cells[0].innerHTML+" for "+table.rows[rIndex].cells[2].innerHTML+"?";

			
		}
	}

		$("#cancelRef").attr("href",href);
		$("#cancelConfirm").modal();
		
		
	});
	
	});