$(document).ready(function() {
  
	var today = new Date().toISOString();
	var formatToday = today.slice(0,today.lastIndexOf(':'));  

	document.getElementById("endDateTime").setAttribute("min", formatToday);	  	
  	//alert(formatToday); //test to see if it's' working  
});
