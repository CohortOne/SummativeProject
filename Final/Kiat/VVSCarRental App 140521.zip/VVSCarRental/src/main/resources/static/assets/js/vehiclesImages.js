$(document).ready(function(){
	$("#dataTable #carpics").click(function(){
    $("#modalVehicleImgs").modal("show");
	});
	
	$("#vehicleImage").change(function(){
		showImageThumbnail(this);
	});
		
	var table = document.getElementById("dataTable"),rIndex;

	for(i=0; i<table.rows.length; i++)

	for (j=0;j<table.rows[i].cells.length; j++)
	{
		table.rows[i].cells[j].onclick = function()
		{
			rIndex = this.parentElement.rowIndex;			
			var vehicleId = table.rows[rIndex].cells[0].innerHTML;
			var title = document.getElementById("title");
			title.innerHTML = "Images of Vehicle " + table.rows[rIndex].cells[2].innerHTML;   			
			var json = {
      			 "vehicleId" : vehicleId
    		};
			console.log(json);
		    $.ajax({
                type: "POST",
                contentType: "application/json",
                url: "/loadVehicleImages",
                data: JSON.stringify(json),
                dataType: 'json',
                cache: false,
                timeout: 600000,
                success: function(data) {
                    var html = '<div class="carousel-item active">';
					var indicators = '<li class="active" data-target="#carousel-1" data-slide-to="'
                    var len = data.length;                    
                    for (var i = 0; i < len; i++) {
                        html += '<img class="w-100 d-block" src="' 
							+ data[i].hrefLink  
							+'"/></div><div class="carousel-item">';
						indicators += i + '"></li><li data-target="#carousel-1" data-slide-to="';
                    }                  
					html = html.slice(0, html.lastIndexOf('/'));					                    
					html +='div>';
					indicators = indicators.slice(0, indicators.lastIndexOf('/'));
					indicators += '"li>"'
					console.log(html);
					console.log(indicators);
        			$('#vehicleImages').html(html);
					$('#sliderNo').html(indicators);	

                },
                error: function(e) {
                    alert(e);
                }
            });
		}
	}
		
    


	
	function showImageThumbnail(fileInput){
		file = fileInput.files[0];
		reader = new FileReader();
		
		reader.onload = function(e){
			$("#thumbnail").attr("src", e.target.result)
		};
		
		reader.readAsDataURL(file);
	}
});

