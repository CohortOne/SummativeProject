var currentdate = new Date(); 
		$(document).ready(function() {
			var expected_end = document.getElementsByClassName("expected_end");      
			var diff = document.getElementsByClassName("difference");
			
			for(var i = 0, j = 0; i < expected_end.length && j <diff.length; i++,j++) {
				var expected_end_datetime = expected_end[i].innerHTML;
				var enddatetime = new Date(expected_end_datetime);
				var difference = Math.round((enddatetime - currentdate)/(1000*60));
				if (difference<0)
				difference = difference * -1 + " Minutes Overtime!!"; 			    				
				diff[j].innerHTML = difference;
			}
						
        });