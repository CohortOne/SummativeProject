/**
 * 
 */
var pictModal = document.getElementById('pictModal')
pictModal.addEventListener('show.bs.modal', function (event) {
  // Button that triggered the modal
  var button = event.relatedTarget;
  // Extract info from data-bs-* attributes
  var vehDesc = button.getAttribute('data-bs-vehDesc');
  var vehLicPlate = button.getAttribute('data-bs-vehLicPlate');
  var vehId = button.getAttribute('data-bs-vehId');
  var pictId = button.getAttribute('data-bs-pictId');

  var imgDiv = document.getElementById("modalPictSrc");
  while (imgDiv.hasChildNodes()) {imgDiv.removeChild(imgDiv.firstChild);}
  var elemImg = document.createElement('img')
  if (pictId!='0') {
    elemImg.setAttribute('src', '/pictGet/' + pictId);
    elemImg.setAttribute('width', '400');
    imgDiv.appendChild(elemImg);
    document.getElementById('modalPictRmv').removeAttribute('hidden');
    document.getElementById('uploadPictBtn').innerHTML='Replace with new picture';
    document.getElementById('id').value = pictId;
    document.getElementById('entityId').value = vehId;
  }
  else {
    document.getElementById('modalPictRmv').setAttribute('hidden', 'true');
    document.getElementById('uploadPictBtn').innerHTML='Upload a picture';
    document.getElementById('id').value = "0";
    document.getElementById('entityId').value = vehId;
  }
    
  document.getElementById('modalVehDesc').innerHTML = vehDesc;
  document.getElementById('modalVehLicPlate').innerHTML = vehLicPlate;
  document.getElementById('execResult').innerHTML = '';
})




//https://o7planning.org/11813/spring-boot-file-upload-with-jquery-ajax
$(document).ready(function() {
	// Submit form to upload new picture
	$("#uploadBtn").click(function(event) {
			// Prevent the form from submitting via the browser.
			event.preventDefault();
			ajaxSubmitForm();
		});
	// Button to delete eixsting picture
	$("#deleteBtn").click(function(event) {
			// Prevent the form from submitting via the browser.
			event.preventDefault();
			ajaxDelePict();
		});
	});

function ajaxSubmitForm() {
	// Get form
	var form = $('#uploadPictForm')[0];
	var formData = new FormData(form);
	var vehId = document.getElementById('entityId').value;
	$("#uploadBtn").prop("disabled", true);

	// DO POST
	$.ajax({
		type : "POST",
		enctype : "multipart/form-data",
		url : "/vehSavePictJs",
		data : formData,
		// prevent jQuery from automatically transforming the data into a query string
        processData: false,
        contentType: false,
        cache: false,
        timeout: 1000000,
        success: function(formData, textStatus, jqXHR) {
		    document.getElementById('execResult').innerHTML='New picture uploaded successfully.';
			document.getElementById('uploadPictBtn').innerHTML='Replace with new picture';
			console.log("SUCCESS : ", formData);
			$("#uploadBtn").prop("disabled", false);
			$("#uploadPictForm")[0].reset();
		    document.getElementById('modalPictRmv').removeAttribute('hidden');
	        document.getElementById('id').value = formData;
	        document.getElementById('entityId').value = vehId;
            $("#modalPictSrc").html("<img src='/pictGet/"+ formData + "' width='400'>");
			if (document.getElementById("vehThumb"+vehId)!=null) {
	            $("#vehThumb"+vehId).html("<img src='/pictGet/"+ formData + "' width='50'>");
    	        document.getElementById("vehThumb"+vehId).setAttribute("data-bs-pictid", formData);
			}
			if (document.getElementById("pinVehThumb"+vehId)!=null) {
	            $("#pinVehThumb"+vehId).html("<img src='/pictGet/"+ formData + "' width='50'>");
    	        document.getElementById("pinVehThumb"+vehId).setAttribute("data-bs-pictid", formData);
			}
		},
		error : function(jqXHR, textStatus, errorThrown) {
		    document.getElementById('execResult').innerHTML=jqXHR.responseText;
            console.log("ERROR : ", jqXHR.responseText);
            $("#uploadBtn").prop("disabled", false);
		}
	});
}

function ajaxDelePict() {
    if (confirm('Proceed to delete this picture?')) {
		var vehId = document.getElementById('entityId').value;
		$("#modalPictRmv").prop("hidden", true);
	
		// DO GET
		$.ajax({
			type : "GET",
			url : "/vehRmvPictJs/" + vehId,
	        success: function(formData, textStatus, jqXHR) {
			    document.getElementById('execResult').innerHTML='Picture deleted successfully.';
			    document.getElementById('uploadPictBtn').innerHTML='Upload a picture';
		        document.getElementById('id').value = "0";
				console.log("SUCCESS : ", formData);
	            $("#modalPictSrc").html("");
				if (document.getElementById("vehThumb"+vehId)!=null) {
		            $("#vehThumb"+vehId).html("<span class='fa fa-picture-o'></span>");
	    	        document.getElementById("vehThumb"+vehId).setAttribute("data-bs-pictid", "0");
				}
				if (document.getElementById("pinVehThumb"+vehId)!=null) {
		            $("#pinVehThumb"+vehId).html("<span class='fa fa-id-card-o'></span>");
	    	        document.getElementById("pinVehThumb"+vehId).setAttribute("data-bs-pictid", "0");
				}
			},
			error : function(jqXHR, textStatus, errorThrown) {
				document.getElementById('modalPictRmv').setAttribute('hidden', 'false');
			    document.getElementById('execResult').innerHTML=jqXHR.responseText;
	            console.log("ERROR : ", jqXHR.responseText);
			}
		});

	}
}
