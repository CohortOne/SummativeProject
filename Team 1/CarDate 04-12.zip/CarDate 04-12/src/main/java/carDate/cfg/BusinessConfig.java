package carDate.cfg;

import java.time.LocalDate;
import java.time.LocalTime;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import org.springframework.format.annotation.DateTimeFormat;

@Entity // meaning this is linked to a table in the database
public class BusinessConfig {

	
	@Id // this is the primary key for this record
	@GeneratedValue(strategy = GenerationType.IDENTITY)  // defines how this id is to be generated....??
	private long configId;
	private long prevId;  // points to prev config; but for configId=1, it points the current config
	private long nextId;  // points to next config; but for configId=1, it points the optional future config
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private LocalDate effDate; // date this config becomes effective
	private String companyName;
	private String addr1;
	private String addr2;
	private int gracePeriod; 

	@DateTimeFormat(pattern = "HH:mm:ss")
	private LocalTime openTime; 
	
	@DateTimeFormat(pattern = "HH:mm:ss")
	private LocalTime returnTime;
	
	@DateTimeFormat(pattern = "HH:mm:ss")
	private LocalTime hireTime;
	
	@DateTimeFormat(pattern = "HH:mm:ss")
	private LocalTime closeTime;
	
	private int hourlyFactor;
	private int extraTimeFactor;
	private int weekendFactor;
	private int offsetDays;
	private int offsetHours;

	
	public long getConfigId() {
		return configId;
	}
	public void setConfigId(long configId) {
		this.configId = configId;
	}
	
	public long getPrevId() {
		return prevId;
	}
	public void setPrevId(long prevId) {
		this.prevId = prevId;
	}
	
	public long getNextId() {
		return nextId;
	}
	public void setNextId(long nextId) {
		this.nextId = nextId;
	}
	
	public LocalDate getEffDate() {
		return effDate;
	}
	public void setEffDate(LocalDate effDate) {
		this.effDate = effDate;
	}
	
	
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	
	public String getAddr1() {
		return addr1;
	}
	public void setAddr1(String addr1) {
		this.addr1 = addr1;
	}
	public String getAddr2() {
		return addr2;
	}
	public void setAddr2(String addr2) {
		this.addr2 = addr2;
	}
	
	
	public int getGracePeriod() {
		// Actual start and end time of a hire can be overrided to no more than 30 minutes before and after the clock.
		return gracePeriod;
	}
	public void setGracePeriod(int gracePeriod) {
		this.gracePeriod = gracePeriod;
	}
	
	public LocalTime getOpenTime() {
		// Office opens at, 09:00: Time.valueOf("09:00:00");
		return openTime;
	}
	public void setOpenTime(LocalTime openTime) {
		this.openTime = openTime;
	}

	public LocalTime getReturnTime() {
		// Hired cars should return by 12:00
		return returnTime;
	}
	public void setReturnTime(LocalTime returnTime) {
		this.returnTime = returnTime;
	}

	public LocalTime getHireTime() {
		// Hired cars can be collected starting 14:00
		return hireTime;
	}
	public void setHireTime(LocalTime hireTime) {
		this.hireTime = hireTime;
	}

	public LocalTime getCloseTime() {
		// office closes at 21:00
		return closeTime;
	}
	public void setCloseTime(LocalTime closeTime) {
		this.closeTime = closeTime;
	}

	public int getHourlyFactor() {
		// Extra time charged hourly at 5% of daily rate 
		return hourlyFactor;
	}
	public void setHourlyFactor(int hourlyFactor) {
		this.hourlyFactor = hourlyFactor;
	}

	public int getExtraTimeFactor() {
		// For return of vehicle beyond dtsEnd, 10% levy 
		return extraTimeFactor;
	}
	public void setExtraTimeFactor(int extraTimeFactor) {
		this.extraTimeFactor = extraTimeFactor;
	}

	public int getWeekendFactor() {
		// Weekend hires attracts 10% levy  --- not yet implemented..
		return weekendFactor;
	}
	public void setWeekendFactor(int weekendFactor) {
		this.weekendFactor = weekendFactor;
	}

	public int getOffsetDays() {
		// this is used for testing.  Allows this number of days to be applied to the clock when getting current date time.
		return offsetDays;
	}
	public void setOffsetDays(int offsetDays) {
		this.offsetDays = offsetDays;
	}

	public int getOffsetHours() {
		// this is used for testing.  Allows this number of hours to be applied to the clock when getting current date time.
		return offsetHours;
	}
	public void setOffsetHours(int offsetHours) {
		this.offsetHours = offsetHours;
	}
	/**
	 * 
	 */
	public BusinessConfig() {
		super();
	}
	@Override
	public String toString() {
		return "BusinessConfig [configId=" + configId + ", prevId=" + prevId + ", nextId=" + nextId + ", effDate="
				+ effDate + ", gracePeriod=" + gracePeriod + ", openTime=" + openTime + ", returnTime=" + returnTime
				+ ", hireTime=" + hireTime + ", closeTime=" + closeTime + ", hourlyFactor=" + hourlyFactor
				+ ", extraTimeFactor=" + extraTimeFactor + ", weekendFactor=" + weekendFactor + ", offsetDays="
				+ offsetDays + ", offsetHours=" + offsetHours + "]";
	}

	
	
}
