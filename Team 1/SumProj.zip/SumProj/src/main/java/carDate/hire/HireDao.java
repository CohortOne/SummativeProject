package carDate.hire;

import java.util.List;

public interface HireDao {
	
	public List<Hire> getAllHires();

}
