// # last ref to /mFCapStoneProj5/210113A-BankApp/
package carDate.cust;

import java.util.List;

public interface CustomerDao {
	public List<Customer> getAllCustomers();
}
