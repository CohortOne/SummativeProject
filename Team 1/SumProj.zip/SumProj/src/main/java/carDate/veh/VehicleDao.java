/* ref: 210113B-BankApp/ */

package carDate.veh;

import java.util.List;

public interface VehicleDao {
	public List<Vehicle> getAllVehicles();

}
