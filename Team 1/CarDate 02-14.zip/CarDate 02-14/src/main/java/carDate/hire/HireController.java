package carDate.hire;

import java.time.temporal.ChronoUnit;
import java.util.List;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import carDate.cust.Customer;
import carDate.cust.CustomerDao;
import carDate.emp.EmployeeDao;
import carDate.veh.Vehicle;
import carDate.veh.VehicleDao;
import carDate.veh.VehStatusRepo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

	@Api(value = "HireController", description = "Hire maintenance")
	@Controller
	public class HireController {

		@Autowired
		private HireDao hireDao;

		@Autowired
		private CustomerDao customerDao;

		@Autowired
		private EmployeeDao employeeDao;

		@Autowired
		private VehicleDao vehicleDao;

		@Autowired
		private VehStatusRepo vehStatusRepo;

		private Object principal;
		private String empName;


		int currPage;
		int totalPages;
		int pageSize;
		int nextPageSize;
		String sortField;
		String sortDirection;
		long pinCustId;
		long pinVehId;
		
		private boolean loadSessionAttributes(HttpSession session) {
			currPage = (session.getAttribute("hireCurrPage")==null)?1:(int) session.getAttribute("hireCurrPage");
			session.setAttribute("hireCurrPage", currPage);
			
			totalPages = (session.getAttribute("hireTotalPages"))==null?1:(int) session.getAttribute("hireTotalPages");
			session.setAttribute("hireTotalPages", totalPages);

			pageSize = (session.getAttribute("hirePageSize")==null)?5:(int) session.getAttribute("hirePageSize");
			session.setAttribute("hirePageSize", pageSize);

			nextPageSize = pageSize==5?10:(pageSize==10?20:5);
			session.setAttribute("hireNextPageSize", nextPageSize);

			sortField = (session.getAttribute("hireSortField")==null)?"hireId":(String) session.getAttribute("hireSortField");
			session.setAttribute("hireSortField", sortField);
			
			sortDirection = (session.getAttribute("hireSortDirection")==null)?"ASC":(String) session.getAttribute("hireSortDirection");
			session.setAttribute("hireSortDirection", sortDirection);

			pinCustId = (session.getAttribute("pinCustId")==null)?0:(long) session.getAttribute("pinCustId");
			session.setAttribute("pinCustId", pinCustId);

			pinVehId = (session.getAttribute("pinVehId")==null)?0:(long) session.getAttribute("pinVehId");
			session.setAttribute("pinVehId", pinVehId);

			return true;
		}
		
		
		public boolean hasRole(String role) {

			System.out.println("\n\t Explicit authentication begins...");
			principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
			empName = "";
			
			if (principal instanceof UserDetails) {
				empName = ((UserDetails) principal).getUsername();
				System.out.println("\t Authenticating User=" + empName + "  for Role=" + role + "...");
				System.out.println("\t authenticaed user has these roles=" + ((UserDetails) principal).getAuthorities());
				if (SecurityContextHolder.getContext().getAuthentication().getAuthorities().stream()
		          .anyMatch(r -> r.getAuthority().equals("ROLE_".concat(role)))) {
					System.out.println("\t Explicit authentication ends with true.");
					return true;
				}
				System.out.println("\t Explicit authentication ends with false due to missing required Role " + role + ".");
				return false;
			} else {
				System.out.println("\t Explicit authentication ends with false due to missing UserDetails.");
				return false;
			}
		}

		
		@GetMapping("/hirePage/{pageMvnt}")
		public String hirePaginated(@PathVariable(value="pageMvnt") int pageMvnt,
				Model model, 
				HttpSession session) {
			if ((!hasRole("MANAGER")) && (!hasRole("USER"))) {return "/403";}
			if (!loadSessionAttributes(session)) {return "redirect:/";}

			switch (pageMvnt) {
			    case -9: currPage = 1; break;                            // go to first page
			    case -1: currPage = currPage > 1? currPage - 1:1; break; // go to prev page  
			    case  0: break;                                          // stay at curr page
			    case  1: currPage = currPage < totalPages? totalPages + 1:totalPages; break;  // go to next page
			    case  9: currPage = totalPages; break;                   // go to last page
			    default: currPage = 1;
			}

			Customer pinCust = new Customer();
			if (pinCustId>0) {
				pinCust = customerDao.getCustomerById(pinCustId);
			}
			pinCustId = pinCust.getCustId();
			model.addAttribute("pinCust", pinCust);
			model.addAttribute("pinCustId", pinCustId);
			
			Vehicle pinVeh = new Vehicle();
			if (pinVehId>0) {
				pinVeh = vehicleDao.getVehicleById(pinVehId);
			}
			pinVehId = pinVeh.getVehId();
			model.addAttribute("pinVeh", pinVeh);
			model.addAttribute("pinVehId", pinVehId);
			
			Hire newHire = (Hire)model.getAttribute("newHire");
			if (newHire==null) {
				newHire = new Hire();
				if ((pinCust.getIsActive()) && (pinCust.getCustLinked()!=null) && (pinCust.getCurrHire()==null)) {newHire.setCustomer(pinCust);}
				if (pinVeh.getVehStatus()==vehStatusRepo.findByName("FREE")) {newHire.setVehicle(pinVeh);}
				newHire.setEmpFulfill(employeeDao.getEmployeeByEmpName(empName));
				newHire.setDtsStart(java.time.LocalDateTime.now());
				newHire.setDtsEnd(newHire.getDtsStart().truncatedTo(ChronoUnit.DAYS).plusDays(1).plusHours(12));
			}
			model.addAttribute("newHire", newHire);
			
			session.setAttribute("hireCurrPage", currPage);
			Page <Hire> page = hireDao.hirePaginated(currPage, pageSize, sortField, sortDirection);
			session.setAttribute("hireTotalPages", page.getTotalPages());
			if ((currPage > 1) && (currPage > page.getTotalPages())) {return hirePaginated(9, model, session);}
			List <Hire> listHires = page.getContent();
			model.addAttribute("listHires", listHires);
			session.setAttribute("hireTotalItems", page.getTotalElements());
			session.setAttribute("empName", empName);
			return "Hires";
		}
		

		@GetMapping("/hireSort/{sortField}")
		//change sortField, if same sortField given, change the sort direction
		public String hireSort(@PathVariable(value="sortField") String newSortField, 
				Model model, 
				HttpSession session) {
			
			if (!loadSessionAttributes(session)) {return "redirect:/";}

			if (newSortField.equals(sortField)) {
				// if sortDirection reversed, mirror the page number so records currently on screen continue to be visible
				currPage = (totalPages==0)?1:totalPages - currPage + 1;
				sortDirection = sortDirection.equalsIgnoreCase("ASC")?"DESC":"ASC";
			} else {  
				// if sortField is changed: go to page 1 and change sort order to  Asc
				sortField = newSortField;
				currPage = 1;
				sortDirection = "ASC";
			}
			
			session.setAttribute("hireCurrPage", currPage);
			session.setAttribute("hireSortField", sortField);
			session.setAttribute("hireSortDirection", sortDirection);
			return hirePaginated(0, model, session);
		}


		@GetMapping("/hirePageSize/{newPageSize}")
		public String hirePageSize(@PathVariable(value="newPageSize") int newPageSize,
				Model model, 
				HttpSession session) {

			if (!loadSessionAttributes(session)) {return "redirect:/";}
			// when page size is changed, current page is adjusted so that most of the 
			// records currently visible continue to appear in the new page.
			currPage = (((currPage - 1) * pageSize + 1) / newPageSize) + (((((currPage - 1) * pageSize + 1) % newPageSize)==0)?0:1);
			pageSize = newPageSize; 
			nextPageSize = pageSize==5?10:(pageSize==10?20:5);
			session.setAttribute("hireCurrPage", currPage);
			session.setAttribute("hirePageSize", pageSize);
			session.setAttribute("hireNextPageSize", nextPageSize);
			return hirePaginated(0, model, session);
		}


		@GetMapping("/hirePinCust/{theCustId}")
		public String hirePinCust(@PathVariable(value = "theCustId") long theCustId, 
	            Model model, HttpSession session) {

			if (!loadSessionAttributes(session)) {return "redirect:/";}

			Customer pinCust = new Customer();
			if (theCustId == 0) {
				// when theCustId is 0, unpin the pinned Customer
				pinCustId = 0;
				model.addAttribute("pinCust", pinCust);
				session.setAttribute("pinCustId", pinCustId);
			} 
			return hirePaginated(0, model, session);
		}


		@GetMapping("/hirePinVeh/{theVehId}")
		public String hirePinVeh(@PathVariable(value = "theVehId") long theVehId, 
	            Model model, HttpSession session) {

			if (!loadSessionAttributes(session)) {return "redirect:/";}

			Vehicle pinVeh = new Vehicle();
			if (theVehId == 0) {
				// when theVehId is 0, unpin the pinned Vehicle
				pinVehId = 0;
				model.addAttribute("pinVeh", pinVeh);
				session.setAttribute("pinVehId", pinVehId);
			} 
			return hirePaginated(0, model, session);
		}


		@ApiOperation(value="Brings high-lighted hire record to editing area for return", response=Iterable.class, tags="home")
		@GetMapping("/hireReturnOts/{hireId}")
		public String hireReturnOts(@PathVariable(value = "hireId") long hireId, 
				Model model, 
				HttpSession session) {

			if ((!hasRole("MANAGER")) && (!hasRole("USER"))) {return "/403";}
			if (!loadSessionAttributes(session)) {return "redirect:/";}

			// Get hire from the Service
			Hire newHire = new Hire();
			
			if (hireId == 0) {
				// this method is not expected to be invoked with hireId=0
			} else {
				if (hireId > 0) {  // bring details of existing hire into input area for hire return
					Hire hire = hireDao.getHireById(hireId);
					newHire.setHireId(hire.getHireId());
					newHire.setCustomer(hire.getCustomer());
					newHire.setVehicle(hire.getVehicle());
					newHire.setEmpFulfill(hire.getEmpFulfill());
					newHire.setEmpReturn(employeeDao.getEmployeeByEmpName(empName));
					newHire.setDtsStart(hire.getDtsStart());
					newHire.setDtsEnd(hire.getDtsEnd());
					newHire.setDeposit(hire.getDeposit());
					newHire.setHireFee(hire.getHireFee());
					newHire.setDtsEndActual(java.time.LocalDateTime.now());
					model.addAttribute("optMsg", "Modify hire record and then click <Save>.");
				}
			}
			model.addAttribute("newHire", newHire);
			return hirePaginated(0, model, session);
		}

		
		@PostMapping("/hireSaveOts")	
		public String hireSaveOts(@Valid @ModelAttribute("newHire")Hire newHire, BindingResult bindingResult, 
				Model model, 
				HttpSession session) {

			if ((!hasRole("MANAGER")) && (!hasRole("USER"))) {return "/403";}
			if (!loadSessionAttributes(session)) {return "redirect:/";}
			
			if (bindingResult.hasErrors()) {
				model.addAttribute("optMsg", "Please correct the validation errors.");
				return hirePaginated(0, model, session);
			}

			hireDao.saveHire (newHire);
			if (newHire.getDtsEndActual()==null) { // saving a new hire
				Vehicle myVeh = vehicleDao.getVehicleById(newHire.getVehicle().getVehId());
				myVeh.setCurrHire(newHire);
				myVeh.setVehStatus(vehStatusRepo.findByName("HIRED"));
				myVeh.addHire(newHire);
				Customer myCust = customerDao.getCustomerById(newHire.getCustomer().getCustId());
				myCust.setCurrHire(newHire);
				myCust.addHire(newHire);
			} else { // saving a hire return
				Vehicle myVeh = vehicleDao.getVehicleById(newHire.getVehicle().getVehId());
				myVeh.setCurrHire(null);
				myVeh.setVehStatus(vehStatusRepo.findByName("FREE"));
				Customer myCust = customerDao.getCustomerById(newHire.getCustomer().getCustId());
				myCust.setCurrHire(null);
			}
			model.addAttribute("newHire", null);
			return hirePaginated(0, model, session); 
		}
		

		@GetMapping("/hireDeleteOts/{hireId}")
		public String hireDeleteOts(@PathVariable(value = "hireId") long hireId,
				Model model, 
				HttpSession session) {
			if (!hasRole("MANAGER")) {return "/403";}
			if (!loadSessionAttributes(session)) {return "redirect:/";}

			// call delete hire method 
			this.hireDao.deleteHireById(hireId);
			return hirePaginated(0, model, session);
		}

	
}
