package crg.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import crg.model.Booking;
import crg.model.Customer;
import crg.model.Employee;
import crg.model.VehStatus;
import crg.model.Vehicle;
import crg.repo.BookingRepo;
import crg.repo.CustomerRepo;
import crg.repo.EmployeeRepo;
import crg.repo.VehStatusRepo;
import crg.repo.VehicleRepo;

@Controller
public class BookingController {
@Autowired
private BookingRepo bookRepo;
@Autowired
private CustomerRepo custRepo;
@Autowired
private EmployeeRepo empRepo;
@Autowired
private VehicleRepo vehRepo;
@Autowired
private VehStatusRepo vehSttsRepo;


//@GetMapping("/booking")
//public String ShowBookingList(Model model) {
//	List<Booking> listBook = bookRepo.findAll();
//	model.addAttribute("listBook",listBook);
//	return "booking";
//}

//Mapping with pagination from SpringJPAPagination CountryController.java
@GetMapping("/booking") 
public String showPage(Model model, @RequestParam(defaultValue = "0") int page) {
model.addAttribute("listBook", bookRepo.findAll(PageRequest.of(page, 4))); //correspond to html
model.addAttribute("currentPage", page); // correspond to html 
return "booking"; }

@GetMapping("/newBookingReg")
public String newBookingReg(Model model) {
	List<Customer> listCust =  custRepo.findAll();
	List<Vehicle> listVeh =  vehRepo.findAll();
	List<Employee> listEmp =  empRepo.findAll();
	model.addAttribute("booking", new Booking());
	model.addAttribute("listCust",listCust);
	model.addAttribute("listVeh",listVeh);
	model.addAttribute("listEmp",listEmp);
	return "newBookingReg";
	}


@GetMapping("/newBookingRegVeh/{vehid}")
public String newBookingRegVeh(@PathVariable("vehid") Long vehid, Model model) {
	List<Customer> listCust =  custRepo.findAll();
	Vehicle listVeh =  vehRepo.findById(vehid).get();  
	List<Employee> listEmp =  empRepo.findAll();
	model.addAttribute("booking", new Booking());
	model.addAttribute("listCust",listCust);
	model.addAttribute("listVeh",listVeh);
	model.addAttribute("listEmp",listEmp);
	return "newBookingReg";
	}

@PostMapping("/booking/save")  // Add vehRepo.save to change status
public String saveBooking(Booking booking,  HttpServletRequest request) {
	bookRepo.save(booking);
	
	//return "redirect:/booking";
	return "redirect:/vehicle";  // redirect to vehicle to change status can't work
}

@PostMapping("/booking/savevl")  // Add vehRepo.save to change status
public String saveBookingvl(Booking booking,  HttpServletRequest request) {
	bookRepo.save(booking);
	
	//return "redirect:/booking";
	return "redirect:/vehicle";  // redirect to vehicle to change status can't work
}

@GetMapping("/booking/edit/{bookId}")
public String ShowBookingEditForm(@PathVariable("bookId") Long bookId, Model model) {
	List<Customer> listCust =  custRepo.findAll();
	List<Vehicle> listVeh =  vehRepo.findAll();
	List<Employee> listEmp =  empRepo.findAll();
	model.addAttribute("listCust",listCust);
	model.addAttribute("listVeh",listVeh);
	model.addAttribute("listEmp",listEmp);
	Booking booking = bookRepo.findById(bookId).get();
	model.addAttribute("booking", booking);
	//List<Booking> listBook = bookRepo.findAll();
	//model.addAttribute("listBook", listBook);
	return "UpdateBook";
	}

@GetMapping("/booking/delete/{bookId}")
public String ShowBookingDeleteForm(@PathVariable("bookId") Long bookId, Model model) {
	bookRepo.deleteById(bookId);
	return "redirect:/booking";
	}
}


