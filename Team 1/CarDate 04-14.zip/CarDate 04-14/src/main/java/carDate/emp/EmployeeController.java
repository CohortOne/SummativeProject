package carDate.emp;

import java.util.List;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.hibernate.exception.ConstraintViolationException;
//import org.springframework.dao.ConstraintViolationException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import carDate.Home;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

	@Api(value = "EmployeeController", description = "Application user administration")
	@Controller
	public class EmployeeController {

		@Autowired
		private Home home;

		@Autowired
		private EmployeeDao employeeDao;

		@Autowired
		private RoleRepo roleRepo;

		String currFunc;
		int currPage;
		int totalPages;
		int pageSize;
		String sortField;
		String sortDirection;
		long pinCustId;
		long pinVehId;
		
		private boolean loadSessionAttributes(HttpSession session) {
			currFunc = (session.getAttribute("currFunc")==null)?"":(String) session.getAttribute("currFunc");
			if (!currFunc.equals("emp")) {
				currFunc = "emp";
				session.setAttribute("currFunc", currFunc);
			}

			currPage = (session.getAttribute("empCurrPage")==null)?1:(int) session.getAttribute("empCurrPage");
			session.setAttribute("empCurrPage", currPage);
			
			totalPages = (session.getAttribute("empTotalPages"))==null?1:(int) session.getAttribute("empTotalPages");
			session.setAttribute("empTotalPages", totalPages);

			pageSize = (session.getAttribute("empPageSize")==null)?5:(int) session.getAttribute("empPageSize");
			session.setAttribute("empPageSize", pageSize);

			sortField = (session.getAttribute("empSortField")==null)?"empId":(String) session.getAttribute("empSortField");
			session.setAttribute("empSortField", sortField);
			
			sortDirection = (session.getAttribute("empSortDirection")==null)?"ASC":(String) session.getAttribute("empSortDirection");
			session.setAttribute("empSortDirection", sortDirection);
			return true;
		}

		
		@GetMapping("/empPage/{pageMvnt}")
		public String empPaginated(@PathVariable(value="pageMvnt") int pageMvnt,
				Model model, HttpSession session) {
			if (!home.hasRole("ADMIN")) {return "/403";}
			if (!loadSessionAttributes(session)) {return "redirect:/";}

			// set-up current page number
			switch (pageMvnt) {
			    case -9: currPage = 1; break;                            // go to first page
			    case -1: currPage = currPage > 1? currPage - 1:1; break; // go to prev page  
			    case  0: break;                                          // stay at curr page
			    case  1: currPage = currPage < totalPages? currPage + 1:totalPages; break;  // go to next page
			    case  9: currPage = totalPages; break;                   // go to last page
			    default: currPage = 1;
			}

			// get a page of Employee records
			session.setAttribute("empCurrPage", currPage);
			Page <Employee> page = employeeDao.empPaginated(currPage, pageSize, sortField, sortDirection);
			session.setAttribute("empTotalPages", page.getTotalPages());
			if ((currPage > 1) && (currPage > page.getTotalPages())) {return empPaginated(9, model, session);}
			
			List <Employee> listEmps = page.getContent();
			model.addAttribute("listEmps", listEmps);
			session.setAttribute("empTotalItems", page.getTotalElements());

			// set-up the new Employee, which is a record for user to edit to create new Employee or update an existing Employee.
			Employee newEmp = (Employee)model.getAttribute("newEmp");
			if (newEmp==null) {
				newEmp = new Employee();
				newEmp.setIsActive(true);
				model.addAttribute("newEmp", newEmp);
			}
			
			// set-up list of valid employee roles for editing.
			List<Role> roles = roleRepo.findAll();
			model.addAttribute("roles", roles);
			
			// render the loaded data to Employees.html
			return "Employees";
		}
		

		@GetMapping("/empSort/{sortField}")
		//change sortField, if same sortField given, change the sort direction
		public String empSort(@PathVariable(value="sortField") String newSortField, 
				Model model, HttpSession session) {
			
			if (!loadSessionAttributes(session)) {return "redirect:/";}

			if (newSortField.equals(sortField)) {
				// if sortDirection reversed, mirror the page number so records currently on screen continue to be visible
				currPage = (totalPages==0)?1:totalPages - currPage + 1;
				sortDirection = sortDirection.equalsIgnoreCase("ASC")?"DESC":"ASC";
			} else {  
				// if sortField is changed: go to page 1 and change sort order to  Asc
				sortField = newSortField;
				currPage = 1;
				sortDirection = "ASC";
			}
			
			session.setAttribute("empCurrPage", currPage);
			session.setAttribute("empSortField", sortField);
			session.setAttribute("empSortDirection", sortDirection);
			return empPaginated(0, model, session);
		}


		@GetMapping("/empPageSize/{newPageSize}")
		public String empPageSize(@PathVariable(value="newPageSize") int newPageSize,
				Model model, HttpSession session) {

			if ((newPageSize<5) || (newPageSize>20)) {
				model.addAttribute("optMsg", "Page size can be set to between 5 and 20 only.");
				return empPaginated(0, model, session);
			}

			if (!loadSessionAttributes(session)) {return "redirect:/";}
			// when page size is changed, current page is adjusted so that most of the 
			// records currently visible continue to appear in the new page.
			currPage = (((currPage - 1) * pageSize + 1) / newPageSize) + (((((currPage - 1) * pageSize + 1) % newPageSize)==0)?0:1);
			pageSize = newPageSize; 
			session.setAttribute("empCurrPage", currPage);
			session.setAttribute("empPageSize", pageSize);
			return empPaginated(0, model, session);
		}

		
		@ApiOperation(value="Brings high-lighted user record to editing area for edit", response=Iterable.class, tags="home")
		@GetMapping("/empUpdaOts/{empId}")
		public String empUpdaOts(@PathVariable(value = "empId") long empId, 
				Model model, HttpSession session) {

			if (!home.hasRole("ADMIN")) {return "/403";}

			// Get customer from the Service
			Employee newEmp = new Employee();
			if (empId == 0) { // this method is not expected to be invoked with empId=0
				newEmp.setIsActive(true);  
				model.addAttribute("newEmp", newEmp);
				return empPaginated(0, model, session);
			}

			Employee emp = employeeDao.getEmployeeById(empId>0?empId:-empId);
			if (emp.getEmpId()==0) {
				if (empId > 0) {
					model.addAttribute("optMsg", "Employee [" + empId + "] you want to edit no longer exists.");
				} else {
					model.addAttribute("optMsg", "Employee [" + (-empId) + "] you want to clone from no longer exists.");
				}
				return empPaginated(0, model, session);
			}
			
			if (empId > 0) {  // bring details of existing Employee into input area for editing
				if (emp.getEmpName().equalsIgnoreCase(home.getEmpName())) {
					model.addAttribute("optMsg", "You are not allowed to modify your own employee record.");
					return empPaginated(0, model, session);
				}
				newEmp.setEmpId(emp.getEmpId());
				newEmp.setEmpName(emp.getEmpName());
				newEmp.setEmpFullName(emp.getEmpFullName());
				newEmp.setPhoneNo(emp.getPhoneNo());
				newEmp.setEmail(emp.getEmail());
				newEmp.setJobTitle(emp.getJobTitle());
				newEmp.setInitMenu(emp.getInitMenu());
				newEmp.setIsActive(emp.getIsActive());
				newEmp.setPswdExpiry(emp.getPswdExpiry());
				newEmp.setUserExpiry(emp.getUserExpiry());
				newEmp.setRoles(emp.getRoles());
				model.addAttribute("optMsg", "Modify employee record and then click <Save>.");
			} else { // copy details of an existing Employee into input area for editing into a new Employee
				newEmp.setEmpFullName(emp.getEmpFullName());
				newEmp.setEmail(emp.getEmail().indexOf('@')>=0?emp.getEmail().substring(emp.getEmail().indexOf('@')):"");
				newEmp.setJobTitle(emp.getJobTitle());
				newEmp.setInitMenu(emp.getInitMenu());
				newEmp.setIsActive(emp.getIsActive());
				newEmp.setPswdExpiry(emp.getPswdExpiry());
				newEmp.setUserExpiry(emp.getUserExpiry());
				newEmp.setRoles(emp.getRoles());
				model.addAttribute("optMsg", "Enter required details and then click <Save>.");
			}
			model.addAttribute("newEmp", newEmp);
			return empPaginated(0, model, session);
		}

		
		@Transactional
		@PostMapping("/empSaveOts")	
		public String empSaveOts(@Valid @ModelAttribute("newEmp")Employee newEmp, BindingResult bindingResult, 
				Model model, HttpSession session) {

			if (!home.hasRole("ADMIN")) {return "/403";}
			BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
			
			if (bindingResult.hasErrors()) {
				model.addAttribute("optMsg", "Please correct the validation errors.");
				return empPaginated(0, model, session); 
			}
				
			if (newEmp.getEmpName().equalsIgnoreCase(home.getEmpName())) {
				if (newEmp.getEmpId()==0) {
					model.addAttribute("optMsg", "You cannot create an Employee using your own empName [" + home.getEmpName() + "].");
				} else {
					model.addAttribute("optMsg", "You change an Employee name to have the same empName as your own [" + home.getEmpName() + "].");
				}
				return empPaginated(0, model, session);
			}
			
			Employee samenameEmployee = employeeDao.getEmployeeByEmpName(newEmp.getEmpName());
			if (samenameEmployee!=null) {  // there is an Employee in db with the same name
				if (newEmp.getEmpId()!=samenameEmployee.getEmpId()) {  // Savings or changing editing Employee has same name as another Employee
					model.addAttribute("optMsg", "An employee with the empName [" + newEmp.getEmpName() + "] already exists.");
					return empPaginated(0, model, session);
				}
			}

			if (newEmp.getEmpId()==0) {  // if saving a new user
				if (newEmp.getPassword().isEmpty()) {
					model.addAttribute("optMsg", "You must enter an initial password for this new user.");
					return empPaginated(0, model, session);
				}
			}

			// Validation completed successfully.  Now proceed to save the changes to database 
			if (newEmp.getEmpId()>0) {
				// update existing Employee
				Employee oldEmp = new Employee();
				oldEmp = employeeDao.getEmployeeById(newEmp.getEmpId());
				if (!newEmp.getPassword().isEmpty()) {
					oldEmp.setPassword(encoder.encode(newEmp.getPassword()));  // Update with encrypted password
				}
				if (!newEmp.getIsActive()==oldEmp.getIsActive()) {
					oldEmp.setIsActive(newEmp.getIsActive());
				}
				if (!newEmp.getEmail().equalsIgnoreCase(oldEmp.getEmail())) {
					oldEmp.setEmail(newEmp.getEmail());
				}
				if (!newEmp.getEmpFullName().equalsIgnoreCase(oldEmp.getEmpFullName())) {
					oldEmp.setEmpFullName(newEmp.getEmpFullName());
				}
				if (!newEmp.getEmpName().equalsIgnoreCase(oldEmp.getEmpName())) {
					oldEmp.setEmpName(newEmp.getEmpName());
				}
				if (!newEmp.getInitMenu().equalsIgnoreCase(oldEmp.getInitMenu())) {
					oldEmp.setInitMenu(newEmp.getInitMenu());
				}
				if (!newEmp.getJobTitle().equalsIgnoreCase(oldEmp.getJobTitle())) {
					oldEmp.setJobTitle(newEmp.getJobTitle());
				}
				if (!newEmp.getPhoneNo().equalsIgnoreCase(oldEmp.getPhoneNo())) {
					oldEmp.setPhoneNo(newEmp.getPhoneNo());
				}
				if (!newEmp.getPswdExpiry().isEqual(oldEmp.getPswdExpiry())) {
					oldEmp.setPswdExpiry(newEmp.getPswdExpiry());
				}
				oldEmp.setRoles(newEmp.getRoles());
				if (!newEmp.getUserExpiry().isEqual(oldEmp.getUserExpiry())) {
					oldEmp.setUserExpiry(newEmp.getUserExpiry());
				}
			} else {
				// Create a new Employee
				newEmp.setPassword(encoder.encode(newEmp.getPassword()));  // encrypted the password
				employeeDao.saveEmployee(newEmp);
				model.addAttribute("optMsg", "Employee " + newEmp.getEmpId() + " created.");
			}				

			newEmp = new Employee();
			model.addAttribute("newEmp", null);
			return empPaginated(0, model, session);
		}
		

		@Transactional
		@GetMapping("/empDeleOts/{empId}")
		public String empDeleOts(@PathVariable(value = "empId") long empId,
				Model model, HttpSession session) {
			if (!home.hasRole("ADMIN")) {return "/403";}
			if (!loadSessionAttributes(session)) {return "redirect:/";}

			Employee newEmp = employeeDao.getEmployeeById(empId);
			if (newEmp.getEmpName().equalsIgnoreCase(home.getEmpName())) {
				model.addAttribute("optMsg", "You should not delete your own Employee record.");
				return empPaginated(0, model, session);
			}
			// call delete customer method 
			try {
				model.addAttribute("optMsg", "Employee [" + newEmp.getEmpFullName() + "] deleted.");
				employeeDao.deleteEmployeeById(empId);
			} catch(DataIntegrityViolationException e) {
				e.printStackTrace();
				model.addAttribute("optMsg", "Employee [" + newEmp.getEmpFullName() + "] may be the handling agent of some current or historic Hires, cannot delete.");
			} catch(ConstraintViolationException e) {
				e.printStackTrace();
				model.addAttribute("optMsg", "Employee [" + newEmp.getEmpFullName() + "] may be the handling agent of some current or historic Hires, cannot delete.");
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				model.addAttribute("optMsg", e.getMessage());
			}
			return empPaginated(0, model, session);
		}

		
		@Transactional
		@GetMapping("/empAndOts/{empId}")
		public String empAndOts(@PathVariable(value = "empId") long empId,
				Model model, HttpSession session) {

			if (!home.hasRole("ADMIN")) {return "/403";}

			Boolean activate = empId > 0; // +ve id to activate, -ve to deactivate
			if (!activate) empId = - empId;
			Employee employee = employeeDao.getEmployeeById(empId);
			if (employee.getEmpId()==0) {
				model.addAttribute("optMsg", "Employee [" + empId + "] not found, unable to " + ((activate)?"":"de") + "activate.");
				return empPaginated(0, model, session);
			}
			
			employee.setIsActive(activate);
			return empPaginated(0, model, session);
		}

	
}
