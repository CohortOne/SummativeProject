package carDate.cust;

import java.util.List;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import carDate.Home;
import carDate.veh.Vehicle;
import carDate.veh.VehicleDao;
import carDate.pict.Picture;
import carDate.pict.PictureStorageService;
import carDate.pict.UploadForm;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

	@Api(value = "CustomerController", description = "Customer maintenance")
	@Controller
	@ControllerAdvice
	public class CustomerController {

		@Autowired
		private Home home;

		@Autowired
		private CustomerDao customerDao;

		@Autowired
		private VehicleDao vehicleDao;

		@Autowired
		private PictureStorageService storageService;

		String currFunc;
		int currPage;
		int totalPages;
		int pageSize;
		String sortField;
		String sortDirection;
		long pinCustId;
		long pinVehId;
		long pictCustId;
		String keyword;
		int hasHire; // 0 = show all customers (default), 1 = show only those with current Hire
		
		private boolean loadSessionAttributes(HttpSession session) {
			currFunc = (session.getAttribute("currFunc")==null)?"":(String) session.getAttribute("currFunc");
			if (!currFunc.equals("cust")) {
				currFunc = "cust";
				session.setAttribute("currFunc", currFunc);
			}
			
			currPage = (session.getAttribute("custCurrPage")==null)?1:(int) session.getAttribute("custCurrPage");
			session.setAttribute("custCurrPage", currPage);
			
			totalPages = (session.getAttribute("custTotalPages"))==null?1:(int) session.getAttribute("custTotalPages");
			session.setAttribute("custTotalPages", totalPages);

			pageSize = (session.getAttribute("custPageSize")==null)?5:(int) session.getAttribute("custPageSize");
			session.setAttribute("custPageSize", pageSize);

			sortField = (session.getAttribute("custSortField")==null)?"custId":(String) session.getAttribute("custSortField");
			session.setAttribute("custSortField", sortField);
			
			sortDirection = (session.getAttribute("custSortDirection")==null)?"ASC":(String) session.getAttribute("custSortDirection");
			session.setAttribute("custSortDirection", sortDirection);

			pinCustId = (session.getAttribute("pinCustId")==null)?0:(long) session.getAttribute("pinCustId");
			session.setAttribute("pinCustId", pinCustId);

			pictCustId = (session.getAttribute("pictCustId")==null)?0:(long) session.getAttribute("pictCustId");
			session.setAttribute("pictCustId", pictCustId);

			pinVehId = (session.getAttribute("pinVehId")==null)?0:(long) session.getAttribute("pinVehId");
			session.setAttribute("pinVehId", pinVehId);

			keyword = (session.getAttribute("custKeyword")==null)?"":(String) session.getAttribute("custKeyword");
			session.setAttribute("custKeyword", keyword);

			hasHire = (session.getAttribute("hasHire")==null)?0:(int) session.getAttribute("hasHire");
			session.setAttribute("hasHire", hasHire);

			return true;
		}
		
		
		@GetMapping("/custPage/{pageMvnt}")
		public String custPaginated(@PathVariable(value="pageMvnt") int pageMvnt,
				Model model, HttpSession session) {
			if ((!home.hasRole("MANAGER")) && (!home.hasRole("USER"))) {return "/403";}
			if (!loadSessionAttributes(session)) {return "redirect:/";}

			// set-up current page number
			switch (pageMvnt) {
			    case -9: currPage = 1; break;                            // go to first page
			    case -1: currPage = currPage > 1? currPage - 1:1; break; // go to prev page  
			    case  0: break;                                          // stay at curr page
			    case  1: currPage = currPage < totalPages? currPage + 1:totalPages; break;  // go to next page
			    case  9: currPage = totalPages; break;                   // go to last page
			    default: currPage = 1;
			}

			// get a page of Customer records
			session.setAttribute("custCurrPage", currPage);
			Page <Customer> page = customerDao.custPaginated(currPage, pageSize, keyword, hasHire, sortField, sortDirection);
			session.setAttribute("custTotalPages", page.getTotalPages());
			if ((currPage > 1) && (currPage > page.getTotalPages())) {return custPaginated(9, model, session);}
			
			List <Customer> listCusts = page.getContent();
			model.addAttribute("listCusts", listCusts);
			session.setAttribute("custTotalItems", page.getTotalElements());

			// set-up the pinned Customer.
			Customer pinCust = new Customer();
			if (pinCustId>0) {
				pinCust = customerDao.getCustomerById(pinCustId);
				pinCustId = pinCust.getCustId();
			}
			model.addAttribute("pinCust", pinCust);
			session.setAttribute("pinCustId", pinCustId);
			
			// set-up the pinned Vehicle.
			Vehicle pinVeh = new Vehicle();
			if (pinVehId>0) {
				pinVeh = vehicleDao.getVehicleById(pinVehId);
				pinVehId = pinVeh.getVehId();
			}
			model.addAttribute("pinVeh", pinVeh);
			session.setAttribute("pinVehId", pinVehId);

			// set-up the new Customer, which is a record for user to edit to create new Customer or update an existing Customer.
			Customer newCust = (Customer)model.getAttribute("newCust");
			if (newCust==null) {
				newCust = new Customer();
				newCust.setIsActive(false);
				if (pinCust.getIsActive()) {newCust.setCustLinked(pinCust);}
			}
			newCust.setDateUpd(home.homeClock().toLocalDate());
			model.addAttribute("newCust", newCust);

			// set-up the pictured Customer.  This pictured Customer is loaded so that the Picture of that Customer can be edited on a Modal.
			Customer pictCust = new Customer();
			if (pictCustId>0) {
				pictCust = customerDao.getCustomerById(pictCustId);
				pictCustId = pictCust.getCustId();
			}
			model.addAttribute("pictCust", pictCust);
			session.setAttribute("pictCustId", pictCustId);
			
			// render the loaded data to Customers.html
			return "Customers";
		}
		
		
		@GetMapping("/custFilter") // set-up a session.keyword to filter Customers
		public String custFilter(
				@RequestParam("keyword") String keyword, 
				Model model, HttpSession session) {
			
			session.setAttribute("custKeyword", keyword);
			return custPaginated(0, model, session);
		}

		
		@GetMapping("/custHasHire/{showHired}") // set-up a session.indicator to show only Customers with current Hire, or show all Customers
		public String hireVeh(@PathVariable(value = "showHired") int showHired, 
	            Model model, HttpSession session) {

			if ((showHired<0) || (showHired>1)) {
				model.addAttribute("optMsg", "/custHasHire/x, only 0 and 1 allowed for x.");
			} else {
				session.setAttribute("hasHire", showHired);
			}
			return custPaginated(0, model, session);
		}

		
		@GetMapping("/custSort/{newSortField}")
		//change sortField, if same sortField given, change the sort direction
		public String custSort(@PathVariable(value="newSortField") String newSortField, 
				Model model, HttpSession session) {
			
			if (!loadSessionAttributes(session)) {return "redirect:/";}

			if (newSortField.equals(sortField)) {
				// if sortDirection reversed, mirror the page number so records currently on screen continue to be visible
				currPage = (totalPages==0)?1:totalPages - currPage + 1;
				sortDirection = sortDirection.equalsIgnoreCase("ASC")?"DESC":"ASC";
			} else {  
				// if sortField is changed: go to page 1 and change sort order to  Asc
				sortField = newSortField;
				currPage = 1;
				sortDirection = "ASC";
			}
			
			session.setAttribute("custCurrPage", currPage);
			session.setAttribute("custSortField", sortField);
			session.setAttribute("custSortDirection", sortDirection);
			return custPaginated(0, model, session);
		}


		@GetMapping("/custPageSize/{newPageSize}")
		public String custPageSize(@PathVariable(value="newPageSize") int newPageSize,
				Model model, HttpSession session) {

			if ((newPageSize<5) || (newPageSize>20)) {
				model.addAttribute("optMsg", "Page size can be set to between 5 and 20 only.");
				return custPaginated(0, model, session);
			}

			if (!loadSessionAttributes(session)) {return "redirect:/";}
			// when page size is changed, current page is adjusted so that most of the 
			// records currently visible continue to appear in the new page.
			currPage = (((currPage - 1) * pageSize + 1) / newPageSize) + (((((currPage - 1) * pageSize + 1) % newPageSize)==0)?0:1);
			pageSize = newPageSize; 
			session.setAttribute("custCurrPage", currPage);
			session.setAttribute("custPageSize", pageSize);
			return custPaginated(0, model, session);
		}

		
		@GetMapping("/custPin/{theCustId}")
		// pin (non-zero) a Customer, or un-pin (zero) the pinned Customer, and render the result on Customers.html
		public String custPin(@PathVariable(value = "theCustId") long theCustId, 
	            Model model, HttpSession session) {

			if (theCustId<0) {
				model.addAttribute("optMsg", "Invalid Customer id [" + theCustId + "] to pin.");
			} else {
				session.setAttribute("pinCustId", theCustId);
			}
			return custPaginated(0, model, session);
		}

		
		@GetMapping("/custPict/{theCustId}")
		// this method is to store custId of nominated Customer, so that its picture will be retrieved
		// to be loaded onto a modal on Customer.html.
		// Once on Customer.html, the pictures can be presented on a modal where 
		// user can add, replace, delete pictures.
		public String custPict(@PathVariable(value = "theCustId") long theCustId, 
	            Model model, HttpSession session) {

			if (theCustId<0) {
				model.addAttribute("optMsg", "Invalid Customer id [" + theCustId + "] to show pictures.");
				return custPaginated(0, model, session);
			}

			session.setAttribute("pictCustId", theCustId);
			return custPaginated(0, model, session);
		}

		
		@GetMapping("/custPinVeh/{theVehId}")
		// pin (non-zero) a Vehicle, or un-pin (zero) the pinned Vehicle, and render the result on Customers.html
		public String custPinVeh(@PathVariable(value = "theVehId") long theVehId, 
	            Model model, HttpSession session) {

			if (theVehId<0) {
				model.addAttribute("optMsg", "Invalid Vehicle id [" + theVehId + "] to pin.");
				return custPaginated(0, model, session);
			}
			session.setAttribute("pinVehId", theVehId);
			return custPaginated(0, model, session);
		}

		
		@Transactional
		@GetMapping("/custLink/{theCustId}")
		public String custLink(@PathVariable(value = "theCustId") long theCustId, 
	            Model model, HttpSession session) {
			// link theCustId to become the alternate contact of the pinned Customer

			if ((!home.hasRole("MANAGER")) && (!home.hasRole("USER"))) {return "/403";}
			if (!loadSessionAttributes(session)) {return "redirect:/";}

			if (theCustId == 0) {  // this should not have happened
				return custPaginated(0, model, session);
			}

			Customer myCust = customerDao.getCustomerById((theCustId>0)?theCustId:-theCustId);
			if (myCust.getCustId()==0) {
				if (theCustId > 0) {
					model.addAttribute("optMsg", "Cannot find Customer [" + theCustId + "] to be used as alternate-contact.");
				} else {
					model.addAttribute("optMsg", "Cannot find Customer [" + (-theCustId) + "] to erase its alternate-contact.");
				}
				return custPaginated(0, model, session);
			}

			if (theCustId < 0) {
				if (myCust.getCustLinked()==null) {
					model.addAttribute("optMsg", "Customer [" + (-theCustId) + "] has no alternate-contact to erase.");
				} else {
					myCust.setCustLinked(null);
					model.addAttribute("optMsg", "Alternate-contact of Customer [" + (-theCustId) + "] has been erased.");
				}
				return custPaginated(0, model, session);
			}

			Customer pinCust = new Customer();
			if (pinCustId > 0) {pinCust = customerDao.getCustomerById(pinCustId);}

			if (pinCust.getCustId() == 0) {
				model.addAttribute("optMsg", "Pinned Customer [" + pinCustId + "] does not exist, unable to link Customer [" + theCustId + "] as its alternate-contact.");
				return custPaginated(0, model, session);
			}
			
			// when theCustId is >0, link theCustId to pinCustId
			if (myCust.getCustId() == pinCust.getCustId()) {
				model.addAttribute("optMsg", "You cannot nominate a Customer [" + theCustId + "] to be his/her own alternate-contact.");
				return custPaginated(0, model, session);
			}
			
			pinCust.setCustLinked(myCust);
			return custPaginated(0, model, session);
		}

		
		@ApiOperation(value="Brings high-lighted Customer record to editing area for edit", response=Iterable.class, tags="home")
		@GetMapping("/custUpdaOts/{custId}")
		public String custUpdaOts(@PathVariable(value = "custId") long custId, 
				Model model, HttpSession session) {

			if ((!home.hasRole("MANAGER")) && (!home.hasRole("USER"))) {return "/403";}

			// Get customer from the Service
			Customer newCust = new Customer();
			if (custId == 0) { // this method is not expected to be invoked with custId=0
				model.addAttribute("newCust", newCust);
				return custPaginated(0, model, session);
			}

			Customer cust = customerDao.getCustomerById(custId>0?custId:-custId);
			if (cust.getCustId()==0) {
				if (custId > 0) {
					model.addAttribute("optMsg", "Customer [" + custId + "] you want to edit no longer exists.");
				} else {
					model.addAttribute("optMsg", "Customer [" + (-custId) + "] you want to clone from no longer exists.");
				}
				return custPaginated(0, model, session);
			}
			
			if (custId > 0) {  // bring details of existing Customer into input area for editing
				newCust.setCustId(cust.getCustId());
				newCust.setCustName(cust.getCustName());
				newCust.setNric(cust.getNric());
				newCust.setEmail(cust.getEmail());
				newCust.setPhoneNo(cust.getPhoneNo());
				newCust.setAddr1(cust.getAddr1());
				newCust.setAddr2(cust.getAddr2());
				newCust.setCity(cust.getCity());
				newCust.setDob(cust.getDob());
				newCust.setIsActive(cust.getIsActive());
				newCust.setDateUpd(home.homeClock().toLocalDate());
				newCust.setCustLinked(cust.getCustLinked());
				newCust.setCurrHire(cust.getCurrHire());
				newCust.setHires(cust.getHires());
				model.addAttribute("optMsg", "Modify Customer record and then click <Save>.");
			} else { // copy details of an existing Customer into input area for editing into a new Customer
				newCust.setCustName(cust.getCustName());
				newCust.setNric(cust.getNric().substring(0, 7));
				newCust.setEmail("@"+cust.getEmail().split("@")[1]);
				newCust.setAddr1(cust.getAddr1());
				newCust.setAddr2(cust.getAddr2());
				newCust.setCity(cust.getCity());
				newCust.setIsActive(cust.getIsActive() && home.hasRole("MANAGER"));
				newCust.setDateUpd(home.homeClock().toLocalDate());
				newCust.setCustLinked(cust.getCustLinked());
				model.addAttribute("optMsg", "Enter required details and then click <Save>.");
			}
			model.addAttribute("newCust", newCust);
			return custPaginated(0, model, session);
		}

		
		@Transactional
		@PostMapping("/custSaveOts")	
		public String custSaveOts(@Valid @ModelAttribute("newCust")Customer newCust, BindingResult bindingResult, 
				Model model, HttpSession session) {

			if ((!home.hasRole("MANAGER")) && (!home.hasRole("USER"))) {return "/403";}
			
			if (bindingResult.hasErrors()) {
				model.addAttribute("optMsg", "Please correct the validation errors.");
				return custPaginated(0, model, session);
			}

			Customer oldCust = new Customer();
			if (newCust.getCustId() > 0) {
				oldCust = customerDao.getCustomerById(newCust.getCustId());
			}

			if (newCust.getCustId()==0) {
				// saving a new Customer
				if ((newCust.getIsActive()) && (!home.hasRole("MANAGER"))) {
					model.addAttribute("optMsg", "You are not allowed to create Customer at Active status.");
					return custPaginated(0, model, session);
				} 
			} else {
				// saving a updated version of an existing Customer
				if ((!oldCust.getIsActive()) && newCust.getIsActive() && (!home.hasRole("MANAGER"))) {
					model.addAttribute("optMsg", "You are not allowed to reactivate an inactive Customer.");
					return custPaginated(0, model, session);
				}
			}

			// Validation completed successfully.  Now proceed to save the changes to database 
			if (newCust.getCustId()>0) {
				// update existing Customer
				if (!newCust.getCustName().equals(oldCust.getCustName())) {
					oldCust.setCustName(newCust.getCustName());
				};
				if (!newCust.getNric().equals(oldCust.getNric())) {
					oldCust.setNric(newCust.getNric());
				};
				if (!newCust.getEmail().equals(oldCust.getEmail())) {
					oldCust.setEmail(newCust.getEmail());
				};
				if (!newCust.getPhoneNo().equals(oldCust.getPhoneNo())) {
					oldCust.setPhoneNo(newCust.getPhoneNo());
				};
				if (!newCust.getAddr1().equals(oldCust.getAddr1())) {
					oldCust.setAddr1(newCust.getAddr1());
				};
				if (!newCust.getAddr2().equals(oldCust.getAddr2())) {
					oldCust.setAddr2(newCust.getAddr2());
				};
				if (!newCust.getCity().equals(oldCust.getCity())) {
					oldCust.setCity(newCust.getCity());
				};
				if (newCust.getDob()!=(oldCust.getDob())) {
					oldCust.setDob(newCust.getDob());
				};
				if (newCust.getIsActive()!=(oldCust.getIsActive())) {
					oldCust.setIsActive(newCust.getIsActive());
				};
				oldCust.setDateUpd(home.homeClock().toLocalDate());
			} else {
				// saving a new Customer
				newCust.setDateUpd(home.homeClock().toLocalDate());
				try {
					customerDao.saveCustomer (newCust);
				} catch(DataIntegrityViolationException e) {
					e.printStackTrace();
					model.addAttribute("optMsg", "There is another customer with same NRIC or Email, or other problem, please correct the data and retry.");
					model.addAttribute("newCust", newCust);
					return custPaginated(0, model, session);
				} catch(Exception e) {
					e.printStackTrace();
					model.addAttribute("optMsg", "There is an unexpected error, please report to IT supoprt.");
					model.addAttribute("newCust", newCust);
					return custPaginated(0, model, session);
				}
			}
				
			newCust = new Customer();
			model.addAttribute("newCust", null);
			return custPaginated(0, model, session); 
		}

		
		@Transactional
		@GetMapping("/custDeleOts/{custId}")
		public String custDeleOts(@PathVariable(value = "custId") long custId,
				Model model, HttpSession session) {
			if (!home.hasRole("MANAGER")) {return "/403";}
			if (!loadSessionAttributes(session)) {return "redirect:/";}

			Customer myCust = customerDao.getCustomerById(custId);
			if (myCust.getCustId()==0) {
				model.addAttribute("optMsg", "Customer [" + custId + "] not found, unable to delete.");
				return custPaginated(0, model, session);
			}
			if (myCust.getCurrHire()!=null) {
				model.addAttribute("optMsg", "Customer [" + custId + "] has current Hire, record cannot be deleted.");
				return custPaginated(0, model, session);
			}
			if (myCust.getHires().size()>0) {
				model.addAttribute("optMsg", "Customer [" + custId + "] has associated Hire history, they must be removed before the Customer can be deleted.");
				return custPaginated(0, model, session);
			}
			if (myCust.getDrLic()!=null) {
				model.addAttribute("optMsg", "Customer [" + custId + "] has associated driving license picture, it must be removed before the Customer can be deleted.");
				return custPaginated(0, model, session);
			}
			// Validation completed, can proceed to delete Customer
			try {
				model.addAttribute("optMsg", "Customer [" + myCust.getCustName() + "] deleted.");
				customerDao.deleteCustomerById(custId);
			} catch(DataIntegrityViolationException e) {
				e.printStackTrace();
				model.addAttribute("optMsg", "Customer [" + custId + "] may be the alt-contact of other customers, or has current hiring or hiring history, cannot delete.");
			} catch(Exception e) {
				e.printStackTrace();
				model.addAttribute("optMsg", e.getMessage());
			}
			return custPaginated(0, model, session);
		}

		
		@Transactional
		@GetMapping("/custAndOts/{custId}")
		public String custAndOts(@PathVariable(value = "custId") long custId,
				Model model, HttpSession session) {

			if ((!home.hasRole("MANAGER")) && (!home.hasRole("USER"))) {return "/403";}

			Boolean activate = custId > 0; // +ve id to activate, -ve to deactivate
			if (activate && !home.hasRole("MANAGER")) {
				model.addAttribute("optMsg", "You are not allowed to re-activate a Customer.");
				return custPaginated(0, model, session);
			}

			if (!activate) {custId = -custId;}
			Customer customer = customerDao.getCustomerById(custId);
			if (customer.getCustId()==0) {
				model.addAttribute("optMsg", "Customer [" + custId + "] not found, unable to " + ((activate)?"":"de") + "activate.");
				return custPaginated(0, model, session);
			}
			
			customer.setDateUpd(home.homeClock().toLocalDate());
			customer.setIsActive(activate);
			return custPaginated(0, model, session);
		}

		
		@Transactional
		@PostMapping("/custSavePictJs")
		// save a new picture for the customer
		// delete the old picture if any
		public ResponseEntity<?> custSavePictJs(@ModelAttribute UploadForm form) {

			long custId = form.getEntityId();
			
			if ((!home.hasRole("MANAGER")) && (!home.hasRole("USER"))) {
				return new ResponseEntity<>("You are not authorised to upload pictures.", HttpStatus.UNAUTHORIZED);
			}

			if ((form.getFile()==null) || (form.getFile().getOriginalFilename().isEmpty())) {
			    return new ResponseEntity<>("No file selected.", HttpStatus.BAD_REQUEST);
			}

			if (form.getFile().getSize()==0) {
			    return new ResponseEntity<>("Uploaded file has no data.", HttpStatus.BAD_REQUEST);
			}

			Customer myCust = customerDao.getCustomerById(custId);
			if (myCust.getCustId()==0) {
			    return new ResponseEntity<>("Customer [" + custId + "] does not exist.", HttpStatus.BAD_REQUEST);
			}

			Picture newPict = new Picture();
			
			try {
				newPict = storageService.store(form.getFile(),form.getId(),true);
		    } catch (Exception e) {
				e.printStackTrace();
			    return new ResponseEntity<>("Could not upload the file: " + form.getFile().getOriginalFilename() + "!", HttpStatus.BAD_REQUEST);
		    }

			myCust.setDrLic(newPict);
			
			myCust.setDateUpd(home.homeClock().toLocalDate());

			return new ResponseEntity<String>("" + newPict.getPictId(), HttpStatus.OK);
			
		}

		
		@Transactional
		@GetMapping("/custRmvPictJs/{custId}")
		public ResponseEntity<?> custRmvPictJs(@PathVariable long custId) {

			if ((!home.hasRole("MANAGER")) && (!home.hasRole("USER"))) {
				return new ResponseEntity<>("You are not authorised to delete pictures.", HttpStatus.UNAUTHORIZED);
			}
			
			Customer myCust = customerDao.getCustomerById(custId);
			if (myCust.getCustId()==0) {
			    return new ResponseEntity<>("Customer [" + custId + "] does not exist.", HttpStatus.BAD_REQUEST);
			}

			Picture myPict = myCust.getDrLic();
			if (myPict==null) {
			    return new ResponseEntity<>("Customer [" + custId + "] has no uploaded driving license picture.", HttpStatus.BAD_REQUEST);
			}

			// Database update starts here 
			myCust.setDrLic(null);
			storageService.delPicture(myPict.getPictId());
		    return new ResponseEntity<>("Customer [" + myCust.getCustName() + "] has driving license picture deleted.", HttpStatus.OK);
		}

}
