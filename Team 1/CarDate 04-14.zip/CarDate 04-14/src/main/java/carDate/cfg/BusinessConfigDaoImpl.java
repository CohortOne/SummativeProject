package carDate.cfg;

import java.util.Optional;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class BusinessConfigDaoImpl implements BusinessConfigDao {

	@Autowired
	private BusinessConfigRepo businessConfigRepo;
		
	@Override
	public void saveBusinessConfig(BusinessConfig businessConfig) {
		businessConfigRepo.save(businessConfig);
		
	}

	@Override
	public BusinessConfig getBusinessConfigById(long configId) {
		Optional <BusinessConfig> optional = businessConfigRepo.findById(configId);
		BusinessConfig businessConfig = new BusinessConfig();
		if (optional.isPresent()) businessConfig = optional.get();
		return businessConfig;
	}

	@Override
	public void deleteBusinessConfigById(long configId) {
		businessConfigRepo.deleteById(configId);
		
	}
}
