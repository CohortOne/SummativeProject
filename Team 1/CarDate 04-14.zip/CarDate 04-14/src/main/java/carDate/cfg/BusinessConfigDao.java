package carDate.cfg;

import org.springframework.stereotype.Component;

@Component
public interface BusinessConfigDao {

	public void saveBusinessConfig(BusinessConfig businessConfig);
	public BusinessConfig getBusinessConfigById(long configId);
	public void deleteBusinessConfigById(long configId);

}
