package carDate.pict;
import java.io.IOException;
import java.util.stream.Stream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

@Service
public class PictureStorageService {

	  @Autowired
	  private PictureRepo pictureRepo;

	  @Autowired
	  private PictureDao pictureDao;

	  public Picture store(MultipartFile file) throws IOException {
	    String fileName = StringUtils.cleanPath(file.getOriginalFilename());
	    Picture pict = new Picture(fileName, file.getContentType(), file.getBytes());

	    return pictureRepo.save(pict);
	  }

	  public Picture getPicture(long pictId) {
	    return pictureDao.getPictureByPictId(pictId);
	  }

	  public void delPicture(long pictId) {
	    pictureDao.deletePictureByPictId(pictId);
	  }
//	  
//	  public Stream<Picture> getAllPictures() {
//	    return pictureRepo.findAll().stream();
//	  }
	}
