package carDate.pict;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.ResponseBody;

import io.swagger.annotations.Api;

import carDate.Home;

@Api(value = "PictureController", description = "Picture controllers")
@Controller
@ControllerAdvice
public class PictureController {

	@Autowired
	private Home home;
	
	@Autowired
	private PictureStorageService storageService;
	
	@GetMapping("/pictGet/{pictId}")
	@ResponseBody
	void pictGetPict(@PathVariable("pictId") Long pictId, HttpServletResponse response)
			throws ServletException, IOException {

		if ((!home.hasRole("MANAGER")) && (!home.hasRole("USER"))) {
			response.getOutputStream().close();
		} else {
			Picture myPict = storageService.getPicture(pictId);
			response.setContentType("image/jpeg, image/jpg, image/png, image/gif");
			response.getOutputStream().write(myPict.getData());
			response.getOutputStream().close();
		}
	}

}
