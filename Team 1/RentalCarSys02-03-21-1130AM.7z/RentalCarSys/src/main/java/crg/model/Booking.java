package crg.model;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name = "Bookings")
public class Booking {
	
	@Id
	@Column(name = "BOOKID")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long bookId;
	
	@Column(name = "STARTTIME")
	@NotNull
	@DateTimeFormat(pattern = "yyyy-MM-dd'T'HH:mm")

    private LocalDateTime startTime;

	@Column(name = "ENDTIME")
	@NotNull
	@DateTimeFormat(pattern = "yyyy-MM-dd'T'HH:mm")

	private LocalDateTime endTime;
	
    
	@Column(name = "BDAILYRATE")
	@NotNull
	private double dailyRate;  // daily rate of this Vehicle as at time of hire,
    // rate will be used through out this Hire.
	
	@Column(name = "DEPOSIT")
	@NotNull
	private double deposit;
	
	@Column(name = "BOOKINGFEE")
	@NotNull
	private double bookingFee;

	@Column(name = "ACTUALENDTIME")
	@DateTimeFormat(pattern = "yyyy-MM-dd'T'HH:mm")

	private LocalDateTime actualEndTime;
	
	private double totalCost;
	
	@ManyToOne(fetch = FetchType.EAGER, optional = false)
    @JoinColumn(name = "CUSTID", nullable = true)
	private Customer customer;
	
    @ManyToOne(fetch = FetchType.EAGER, optional = false)
    @JoinColumn(name = "VEHID", nullable = false)
	private Vehicle vehicle;

    @ManyToOne(fetch = FetchType.EAGER, optional = false)
    @JoinColumn(name = "EMP_ID", nullable = false)
	private Employee employee;
 
//    @OneToMany
//	@JoinColumn(name = "VEHBOOKID")
//    private Set<Vehicle> Vehicles;
//	//private List<Vehicle> vehicles = new ArrayList<>();
    
//    @OneToMany
//   	@JoinColumn(name = "CUSTBOOKID")
//   	private List<Customer> customers = new ArrayList<>();
    
	public Booking() {	}

	public Long getBookId() {
		return bookId;
	}

	public void setBookId(Long bookId) {
		this.bookId = bookId;
	}

		public double getDailyRate() {
		return dailyRate;
	}

	public void setDailyRate(double dailyRate) {
		this.dailyRate = dailyRate;
	}

	public double getDeposit() {
		return deposit;
	}

	public void setDeposit(double deposit) {
		this.deposit = deposit;
	}

	public double getBookingFee() {
		return bookingFee;
	}

	public void setBookingFee(double bookingFee) {
		this.bookingFee = bookingFee;
	}

	public double getTotalCost() {
		return totalCost;
	}

	public void setTotalCost(double totalCost) {
		this.totalCost = totalCost;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public Vehicle getVehicle() {
		return vehicle;
	}

	public void setVehicle(Vehicle vehicle) {
		this.vehicle = vehicle;
	}

	public Employee getEmployee() {
		return employee;
	}

	public void setEmployee(Employee employee) {
		this.employee = employee;
	}

	public LocalDateTime getStartTime() {
		return startTime;
	}

	public void setStartTime(LocalDateTime startTime) {
		this.startTime = startTime;
	}

	public LocalDateTime getEndTime() {
		return endTime;
	}

	public void setEndTime(LocalDateTime endTime) {
		this.endTime = endTime;
	}

	public LocalDateTime getActualEndTime() {
		return actualEndTime;
	}

	public void setActualEndTime(LocalDateTime actualEndTime) {
		this.actualEndTime = actualEndTime;
	}

	
	
}
