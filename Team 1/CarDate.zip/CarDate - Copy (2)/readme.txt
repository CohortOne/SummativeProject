2021-02-12:
Hi all, the previous version was not tested and have errors.  Please use this version:

Added common.html, which contain declaration of common header, navivation bar, and footer to be included in selected pages.
Added home.html as the landing page for all users.
Revised table ROLE so as to make use of spring security5 tags on html pages to selectively show shortcuts base on user roles.
- all roles must be renamed to ROLE_xxxxx for the framework to work.

Added thymeleaf navigation bar to home and Employee pages, show and hide base on user ROLES.

Revised sql_scipts.

Coded Customer and Vehicle POJO

Coded CustomerController and Customers.html.

Encountered one problem:
Customer.class uses custId as @Id, and it store customer contact details.
To capture an alternate contact for each customer, the attribute "private Customer custLinked;" is added to "public class Customer", 
with these code:
    @ManyToOne(fetch = FetchType.LAZY, optional = true)
    @JoinColumn(name = "CUSTIDLINK", nullable = true)
    private Customer custLinked;
which resulted in the column CUSTIDLINK created in Oracle table CUSTOMER.

Let's say custA has custB as custLinked, and custB have custC as custLinked, then when custC is to be updated with custA as custLinked,
the app will cash with a stack overflow.  That is because the update will create a closed ring structure.

I checked the FetchType, you only have EAGER and LAZY.  Even after I changed it to LAZY, the same problem presists.

Will be bringing up this to Simon.

In the meantime, may proceed to code Vehicle.html and VehicleController.java similar to Customer.



