2021-02-12:
Added common.html, which contain declaration of common header, navivation bar, and footer to be included in selected pages.
Added home.html as the landing page for all users.
Revised table ROLE so as to make use of spring security5 tags on html pages to selectively show shortcuts base on user roles.
Added thymeleaf navigation bar to home and Employee pages.
Revised sql_scipts.

