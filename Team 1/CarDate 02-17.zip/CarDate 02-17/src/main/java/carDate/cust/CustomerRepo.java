package carDate.cust;

import java.util.List;

import org.springframework.data.jdbc.repository.query.Query;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CustomerRepo extends JpaRepository<Customer, Long> {
	Customer findByCustName(String custName);
	
//    @Query("SELECT p FROM Customer p WHERE CONCAT(p.CUSTID, ' ', p.ADDR1, ' ', p.ADDR2, ' ', p.CITY, ' ', p.CUSTNAME, ' ', p.EMAIL, ' ', p.NRIC, ' ', p.PHONENO) LIKE %?1%")
//    public List<Customer> findAllFiltered(String keyword);
}
