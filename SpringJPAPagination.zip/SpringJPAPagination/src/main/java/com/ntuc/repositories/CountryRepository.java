package com.ntuc.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ntuc.entities.Country;

public interface CountryRepository extends JpaRepository<Country, Long> {
}
