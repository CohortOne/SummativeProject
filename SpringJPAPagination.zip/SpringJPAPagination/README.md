### Features
- Java 11
- Springboot 2.2.0.M2
- Thymeleaf 3.0
- bootstrap 4.3.1
- JQuery 3.3.1
- H2﻿

### Video
https://www.youtube.com/watch?v=lIgFe20dYq4